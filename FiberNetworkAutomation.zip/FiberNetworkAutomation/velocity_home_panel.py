"""Velocity Fibre — branded home dock panel.

A clean, friendly control panel that fronts the plugin's tools so QGIS feels like a
Velocity Fibre product, not raw QGIS. Header shows the VELOCITY FIBRE wordmark (or a
logo.png if present in the plugin folder) + live bridge status; below are numbered
workflow step buttons and a tools row. Each button just triggers the plugin's existing
actions/callbacks — no logic is duplicated here.

Brand palette (from the VF identity): navy #14213D, blue #3B6FE0 → magenta #C2255C
gradient accent, teal #2ABFCC, white text.
"""
import os

from qgis.PyQt.QtCore import Qt
from qgis.PyQt.QtGui import QPixmap
from qgis.PyQt.QtWidgets import (
    QDockWidget, QWidget, QVBoxLayout, QHBoxLayout, QLabel, QPushButton,
)

_QSS = """
#vfRoot { background:#0F1A30; }
#vfHeader { background: qlineargradient(x1:0,y1:0,x2:1,y2:1,
            stop:0 #14213D, stop:0.7 #1A2440, stop:1 #3A1733); }
#vfWordTop   { color:#FFFFFF; font-size:20px; font-weight:800; letter-spacing:3px; }
#vfWordBot   { color:#9FB0D0; font-size:11px; font-weight:600; letter-spacing:6px; }
#vfTagline   { color:#7E8DB0; font-size:10px; }
#vfStatus    { color:#9FB0D0; font-size:10px; }
#vfSection   { color:#5E6E92; font-size:10px; font-weight:700; letter-spacing:2px; }
#vfVmark     { background: qlineargradient(x1:0,y1:0,x2:1,y2:1,
               stop:0 #3B6FE0, stop:1 #C2255C); border-radius:9px; }
#vfVmark QLabel { color:#FFFFFF; font-size:20px; font-weight:900; }

QPushButton#vfStep {
    text-align:left; padding:11px 12px; border:1px solid #222F4E;
    border-radius:10px; background:#18233E; color:#EAF0FF;
    font-size:13px; font-weight:600;
}
QPushButton#vfStep:hover { background:#1F2C4C; border:1px solid #3B6FE0; }
QPushButton#vfStep:pressed { background:#16203a; }

QPushButton#vfTool {
    padding:8px 6px; border:1px solid #222F4E; border-radius:9px;
    background:#141E36; color:#B8C6E6; font-size:11px; font-weight:600;
}
QPushButton#vfTool:hover { background:#1d2949; border:1px solid #2ABFCC; color:#FFFFFF; }
"""

_STEP_NUM_QSS = (
    "background: qlineargradient(x1:0,y1:0,x2:1,y2:1, stop:0 #3B6FE0, stop:1 #C2255C);"
    "color:#FFFFFF; font-weight:900; font-size:13px; border-radius:13px;"
)


class VelocityHomePanel(QDockWidget):
    """Branded dock. steps = [(title, subtitle, callable)], tools = [(label, callable)]."""

    def __init__(self, iface, steps, tools, logo_path=None, parent=None):
        super().__init__("Velocity Fibre", parent or iface.mainWindow())
        self.setObjectName("VelocityHomePanel")
        self.iface = iface
        self._status = None

        root = QWidget()
        root.setObjectName("vfRoot")
        root.setStyleSheet(_QSS)
        v = QVBoxLayout(root)
        v.setContentsMargins(0, 0, 0, 0)
        v.setSpacing(0)

        v.addWidget(self._build_header(logo_path))

        body = QVBoxLayout()
        body.setContentsMargins(12, 12, 12, 12)
        body.setSpacing(8)
        body.addWidget(self._label("WORKFLOW", "vfSection"))
        for i, (title, sub, cb) in enumerate(steps, 1):
            body.addWidget(self._step_card(i, title, sub, cb))
        body.addSpacing(8)
        body.addWidget(self._label("TOOLS", "vfSection"))
        trow = QHBoxLayout()
        trow.setSpacing(6)
        for label, cb in tools:
            trow.addWidget(self._tool_button(label, cb))
        body.addLayout(trow)
        body.addStretch(1)
        v.addLayout(body)

        self.setWidget(root)
        self.setMinimumWidth(248)

    # ── header ──
    def _build_header(self, logo_path):
        h = QWidget()
        h.setObjectName("vfHeader")
        lay = QVBoxLayout(h)
        lay.setContentsMargins(14, 14, 14, 12)
        lay.setSpacing(2)

        top = QHBoxLayout()
        top.setSpacing(10)
        if logo_path and os.path.exists(logo_path):
            mark = QLabel()
            pm = QPixmap(logo_path).scaledToHeight(34, Qt.SmoothTransformation)
            mark.setPixmap(pm)
            top.addWidget(mark)
        else:
            mark = QWidget()
            mark.setObjectName("vfVmark")
            mark.setFixedSize(34, 34)
            ml = QVBoxLayout(mark)
            ml.setContentsMargins(0, 0, 0, 0)
            vlab = QLabel("V")
            vlab.setAlignment(Qt.AlignCenter)
            ml.addWidget(vlab)
            top.addWidget(mark)
        words = QVBoxLayout()
        words.setSpacing(0)
        words.addWidget(self._label("VELOCITY", "vfWordTop"))
        words.addWidget(self._label("FIBRE", "vfWordBot"))
        top.addLayout(words)
        top.addStretch(1)
        lay.addLayout(top)
        lay.addWidget(self._label("Network Planner", "vfTagline"))
        self._status = self._label("●  Bridge: checking…", "vfStatus")
        lay.addWidget(self._status)
        return h

    # ── widgets ──
    def _label(self, text, obj):
        lab = QLabel(text)
        lab.setObjectName(obj)
        return lab

    def _step_card(self, n, title, sub, cb):
        btn = QPushButton()
        btn.setObjectName("vfStep")
        btn.setCursor(Qt.PointingHandCursor)
        lay = QHBoxLayout(btn)
        lay.setContentsMargins(8, 6, 10, 6)
        lay.setSpacing(11)
        num = QLabel(str(n))
        num.setFixedSize(26, 26)
        num.setAlignment(Qt.AlignCenter)
        num.setStyleSheet(_STEP_NUM_QSS)
        lay.addWidget(num)
        txt = QVBoxLayout()
        txt.setSpacing(0)
        t = QLabel(title)
        t.setStyleSheet("color:#EAF0FF; font-size:13px; font-weight:700;")
        s = QLabel(sub)
        s.setStyleSheet("color:#8294B8; font-size:10px;")
        txt.addWidget(t)
        txt.addWidget(s)
        lay.addLayout(txt)
        lay.addStretch(1)
        chev = QLabel("›")
        chev.setStyleSheet("color:#5E6E92; font-size:18px; font-weight:800;")
        lay.addWidget(chev)
        if cb:
            btn.clicked.connect(lambda _=False, f=cb: self._safe(f))
        return btn

    def _tool_button(self, label, cb):
        b = QPushButton(label)
        b.setObjectName("vfTool")
        b.setCursor(Qt.PointingHandCursor)
        if cb:
            b.clicked.connect(lambda _=False, f=cb: self._safe(f))
        return b

    def _safe(self, fn):
        try:
            fn()
        except Exception as e:  # never let a panel click raise into the UI
            try:
                self.iface.messageBar().pushWarning("Velocity Fibre", str(e)[:200])
            except Exception:
                pass

    # ── public ──
    def set_bridge(self, online, port=None):
        if not self._status:
            return
        if online:
            self._status.setText("●  Bridge online" + (f" · {port}" if port else ""))
            self._status.setStyleSheet("color:#2ABFCC; font-size:10px;")
        else:
            self._status.setText("●  Bridge offline")
            self._status.setStyleSheet("color:#E0607A; font-size:10px;")
