"""demand_points_per_erf — exactly ONE Demand Point per surveyed erf (stand).

Each stand gets a single point: on its main building's representative point if a building was
detected there (structure=1), otherwise at the erf centroid (structure=0, vacant). Clipped to the
AOI. Output carries the core Vuma Demand-Point fields so it drops into the existing schema.

Usage (qgis-venv):
  python demand_points_per_erf.py \
    --erven C:/Temp/_erven_detect.geojson \
    --buildings C:/Temp/buildings_primary.geojson \
    --aoi C:/Temp/_aoi_detect.geojson \
    --out C:/Temp/demand_points_per_erf.geojson [--stand-min 20] [--stand-max 2000]
"""
import argparse
import sys

import geopandas as gpd

UTM = 32735


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--erven", required=True)
    ap.add_argument("--buildings", required=True)
    ap.add_argument("--aoi")
    ap.add_argument("--out", default="C:/Temp/demand_points_per_erf.geojson")
    ap.add_argument("--stand-min", type=float, default=20.0)
    ap.add_argument("--stand-max", type=float, default=2000.0)
    args = ap.parse_args()

    e = gpd.read_file(args.erven).to_crs(UTM)
    b = gpd.read_file(args.buildings).to_crs(UTM)
    e = e[e.geometry.notna() & ~e.geometry.is_empty].copy()
    b = b[b.geometry.notna() & ~b.geometry.is_empty].reset_index(drop=True)
    e["_area"] = e.geometry.area

    # restrict to residential STANDS
    stands = e[(e["_area"] >= args.stand_min) & (e["_area"] <= args.stand_max)].copy().reset_index(drop=True)
    # clip to AOI
    if args.aoi:
        aoi = gpd.read_file(args.aoi).to_crs(UTM)
        ageom = aoi.geometry.union_all()
        stands = stands[stands.intersects(ageom)].copy()
    stands = stands.reset_index(drop=True)
    stands["_sid"] = stands.index
    print(f"[dp] {len(stands)} stands (in [{args.stand_min:.0f},{args.stand_max:.0f}] m^2, AOI-clipped)")

    # erf number/label field — try common names
    label_field = next((f for f in ("Label", "Geo Erf Nu", "erf", "PRCL_KEY") if f in stands.columns), None)

    # match buildings to their smallest containing stand
    b["_bid"] = b.index
    b["_barea"] = b.geometry.area
    pts = b.copy(); pts["geometry"] = b.geometry.representative_point()
    j = gpd.sjoin(pts[["_bid", "geometry"]], stands[["_sid", "_area", "geometry"]],
                  how="inner", predicate="within")
    j = j.merge(b[["_bid", "_barea"]], on="_bid")
    j = j.sort_values("_area").drop_duplicates("_bid", keep="first")     # smallest stand
    # largest building per stand = the demand-point host
    host = j.loc[j.groupby("_sid")["_barea"].idxmax()][["_sid", "_bid"]]
    host = host.merge(pts[["_bid", "geometry"]], on="_bid").set_index("_sid")

    rows = []
    for _, s in stands.iterrows():
        sid = s["_sid"]
        if sid in host.index:
            pt = host.loc[sid, "geometry"]; structure = 1
        else:
            pt = s.geometry.representative_point(); structure = 0
        erf = str(s[label_field]) if label_field else str(sid)
        rows.append({"geometry": pt, "Name": erf, "Geo Erf Nu": erf, "structure": structure})

    dp = gpd.GeoDataFrame(rows, crs=UTM).to_crs(4326)
    dp["Geo Latitu"] = dp.geometry.y
    dp["Geo Longit"] = dp.geometry.x
    dp["Type"] = "SDU"
    dp["Status"] = "planned"
    dp["Premises T"] = dp["structure"].map({1: "SDU", 0: "Vacant"})
    dp["Geo Countr"] = "South Africa"
    have = int(dp["structure"].sum())
    print(f"[dp] {len(dp)} demand points: {have} on a building, {len(dp)-have} vacant-erf centroids")
    if len(dp) == 0:
        print("[dp] nothing to write"); sys.exit(2)
    dp.to_file(args.out, driver="GeoJSON")
    print(f"[dp] WROTE {args.out}  ({len(dp)} points — one per erf)")


if __name__ == "__main__":
    main()
