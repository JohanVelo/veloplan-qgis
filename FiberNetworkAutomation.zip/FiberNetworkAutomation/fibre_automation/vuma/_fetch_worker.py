"""Vuma data fetch worker — runs in venv subprocess.

Reads  C:/Temp/_vuma_fetch_cfg.json
Writes C:/Temp/vuma_erven.geojson
       C:/Temp/vuma_buildings.geojson
"""
import json
import sys
import time
from pathlib import Path

try:
    sys.stdout.reconfigure(encoding="utf-8")
except Exception:
    pass

import ssl
import geopandas as gpd
from shapely.geometry import Polygon, MultiPolygon, mapping

CFG_FILE = Path(r"C:/Temp/_vuma_fetch_cfg.json")
ERVEN_OUT = Path(r"C:/Temp/vuma_erven.geojson")
BUILDINGS_OUT = Path(r"C:/Temp/vuma_buildings.geojson")

CSG_URL = (
    "https://csggis.drdlr.gov.za/server/rest/services"
    "/CSGSearch/MapServer/2/query"
)
PAGE_SIZE = 1000
MAX_PAGES = 80  # 80k cap

# DRDLR certificate not trusted by default — disable verification
_SSL_CTX = ssl.create_default_context()
_SSL_CTX.check_hostname = False
_SSL_CTX.verify_mode = ssl.CERT_NONE


def log(msg):
    print(msg, flush=True)


# ── CSG erven fetch ───────────────────────────────────────────────────────────

def _signed_area(coords):
    s = 0.0
    for i in range(len(coords) - 1):
        x1, y1 = coords[i][:2]
        x2, y2 = coords[i + 1][:2]
        s += (x2 - x1) * (y2 + y1)
    return s


def _esri_rings_to_shapely(rings):
    """Esri JSON rings → Shapely (Multi)Polygon."""
    if not rings:
        return None
    polys, outer, holes = [], None, []
    for ring in rings:
        coords = [tuple(c[:2]) for c in ring]
        if len(coords) < 4:
            continue
        if _signed_area(coords) > 0:
            if outer is not None:
                polys.append(Polygon(outer, holes))
            outer, holes = coords, []
        else:
            if outer is not None:
                holes.append(coords)
    if outer is not None:
        polys.append(Polygon(outer, holes))
    if not polys:
        return None
    return polys[0] if len(polys) == 1 else MultiPolygon(polys)


def _csg_get(params):
    """HTTP GET to CSG endpoint with SSL verification disabled."""
    import urllib.parse
    import urllib.request
    url = CSG_URL + "?" + urllib.parse.urlencode(params)
    req = urllib.request.Request(url, headers={"User-Agent": "fiber-hld/1.0"})
    with urllib.request.urlopen(req, context=_SSL_CTX, timeout=60) as resp:
        return json.loads(resp.read().decode("utf-8"))


def fetch_csg_erven(bbox):
    """Download CSG erven for bbox=[minx,miny,maxx,maxy] in EPSG:4326."""
    log(f"[CSG] Fetching erven for bbox {bbox} ...")
    all_feats = []
    for page in range(MAX_PAGES):
        params = {
            "where": "LSTATUS IN ('R','S')",
            "geometry": f"{bbox[0]},{bbox[1]},{bbox[2]},{bbox[3]}",
            "geometryType": "esriGeometryEnvelope",
            "inSR": "4326",
            "outSR": "4326",
            "spatialRel": "esriSpatialRelIntersects",
            "returnGeometry": "true",
            "outFields": "PRCL_KEY,LSTATUS,WSTATUS,GEOM_AREA,TAG_VALUE",
            "f": "json",
            "resultRecordCount": PAGE_SIZE,
            "resultOffset": page * PAGE_SIZE,
        }
        for attempt in range(3):
            try:
                data = _csg_get(params)
                break
            except Exception as e:
                log(f"  [CSG] attempt {attempt+1} failed: {e}")
                time.sleep(2 ** attempt)
        else:
            raise RuntimeError("CSG fetch failed after 3 attempts")

        if "error" in data:
            raise RuntimeError(f"CSG server error: {data['error']}")

        esri_feats = data.get("features", [])
        for ef in esri_feats:
            rings = ef.get("geometry", {}).get("rings")
            geom = _esri_rings_to_shapely(rings)
            if geom is None:
                continue
            attr = ef.get("attributes", {})
            all_feats.append({
                "type": "Feature",
                "geometry": mapping(geom),
                "properties": {
                    "PRCL_KEY": str(attr.get("PRCL_KEY") or ""),
                    "Label": str(attr.get("TAG_VALUE") or ""),
                    "Area": float(attr.get("GEOM_AREA") or 0),
                    "LSTATUS": str(attr.get("LSTATUS") or ""),
                    "WSTATUS": str(attr.get("WSTATUS") or ""),
                },
            })
        log(f"  [CSG] page {page+1}: +{len(esri_feats)}  total={len(all_feats)}")
        if len(esri_feats) < PAGE_SIZE:
            break
        if not data.get("exceededTransferLimit", False):
            break

    log(f"[CSG] Done — {len(all_feats)} erven")
    return all_feats


# ── Overture buildings fetch ──────────────────────────────────────────────────

def fetch_overture_buildings(bbox):
    """Download Overture building footprints for bbox=[minx,miny,maxx,maxy].

    Retries up to 3 times — first connection to AWS S3 often fails with a
    timeout on fresh environments.
    """
    log(f"[Overture] Fetching buildings for bbox {bbox} ...")
    import overturemaps
    last_err = None
    for attempt in range(1, 4):
        try:
            reader = overturemaps.record_batch_reader(
                "building",
                bbox=(bbox[0], bbox[1], bbox[2], bbox[3]),
            )
            table = reader.read_all()
            gdf = gpd.GeoDataFrame.from_arrow(table)
            if gdf.crs is None:
                gdf = gdf.set_crs(4326)
            log(f"[Overture] Got {len(gdf)} buildings")
            return gdf
        except Exception as e:
            last_err = e
            log(f"[Overture] attempt {attempt} failed: {e}")
            if attempt < 3:
                time.sleep(5 * attempt)
    log(f"[Overture] All attempts failed — {last_err}")
    return gpd.GeoDataFrame()


# ── One-per-erven primary selection ──────────────────────────────────────────

def assign_primary(buildings_gdf, erven_gdf):
    """Spatial join buildings → erven. Mark is_primary=1 for the largest
    building (by footprint area) within each erven. All others = 0."""
    if erven_gdf is None or len(erven_gdf) == 0:
        buildings_gdf["is_primary"] = 1
        return buildings_gdf

    # Work in a metric CRS for area comparisons (EPSG:32735 UTM 35S)
    b = buildings_gdf.copy().to_crs(32735)
    e = erven_gdf.copy().to_crs(32735)
    b["_area_m2"] = b.geometry.area

    joined = gpd.sjoin(b, e[["geometry"]], how="left", predicate="within")

    b["is_primary"] = 0
    b["area_m2"] = b["_area_m2"].round(2)

    # For each erven, pick the building with the largest footprint
    erven_groups = joined.groupby("index_right")
    for _, group in erven_groups:
        if len(group) == 0:
            continue
        primary_idx = group["_area_m2"].idxmax()
        b.at[primary_idx, "is_primary"] = 1

    # Buildings not within any erven: still give them is_primary=1
    # (they're genuine buildings, just outside cadastral coverage)
    no_erven = joined[joined["index_right"].isna()].index
    b.loc[no_erven, "is_primary"] = 1

    log(f"[Primary] {int(b['is_primary'].sum())} primary / {len(b)} total buildings")
    return b.to_crs(4326)


# ── AOI clip helper ───────────────────────────────────────────────────────────

def _load_aoi_geom(aoi_geojson: str | None):
    """Parse AOI GeoJSON string → Shapely geometry, or None if not provided."""
    if not aoi_geojson:
        return None
    try:
        from shapely.geometry import shape
        fc = json.loads(aoi_geojson)
        # Accept FeatureCollection, Feature, or bare geometry
        if fc.get("type") == "FeatureCollection":
            geoms = [shape(f["geometry"]) for f in fc.get("features", [])
                     if f.get("geometry")]
            if not geoms:
                return None
            from shapely.ops import unary_union
            return unary_union(geoms)
        if fc.get("type") == "Feature":
            return shape(fc["geometry"])
        return shape(fc)
    except Exception as e:
        log(f"[AOI] Could not parse AOI geometry: {e}")
        return None


def _clip_gdf_to_aoi(gdf: gpd.GeoDataFrame, aoi_geom) -> gpd.GeoDataFrame:
    """Keep only rows whose geometry intersects the AOI polygon."""
    if aoi_geom is None or len(gdf) == 0:
        return gdf
    mask = gdf.geometry.intersects(aoi_geom)
    clipped = gdf[mask].copy()
    log(f"[AOI clip] {len(gdf)} → {len(clipped)} features within AOI")
    return clipped


# ── Main ──────────────────────────────────────────────────────────────────────

def main():
    with open(CFG_FILE) as f:
        cfg = json.load(f)
    bbox = cfg["bbox_4326"]  # [minx, miny, maxx, maxy]
    fetch_erven = cfg.get("fetch_erven", True)
    fetch_buildings = cfg.get("fetch_buildings", True)
    aoi_geom = _load_aoi_geom(cfg.get("aoi_geojson"))

    if aoi_geom is not None:
        log("[AOI] polygon loaded — will clip results to AOI boundary")
    else:
        log("[AOI] no polygon provided — keeping full bbox results")

    if not fetch_erven:
        log("[CSG] Erven already loaded — skipping fetch")
    if not fetch_buildings:
        log("[Overture] Buildings already loaded — skipping fetch")
        if not fetch_erven:
            return

    # Run CSG + Overture in parallel to cut total time
    import concurrent.futures
    erven_future = bld_future = None
    with concurrent.futures.ThreadPoolExecutor(max_workers=2) as ex:
        if fetch_erven:
            erven_future = ex.submit(fetch_csg_erven, bbox)
        if fetch_buildings:
            bld_future = ex.submit(fetch_overture_buildings, bbox)
        erven_feats = erven_future.result() if erven_future else []
        bld_gdf = bld_future.result() if bld_future else None

    # Clip erven to AOI polygon before writing
    if fetch_erven:
        if aoi_geom is not None and erven_feats:
            erven_gdf_raw = gpd.GeoDataFrame.from_features(erven_feats, crs=4326)
            erven_gdf_raw = _clip_gdf_to_aoi(erven_gdf_raw, aoi_geom)
            erven_feats = list(json.loads(erven_gdf_raw.to_json())["features"])
        erven_fc = {"type": "FeatureCollection", "features": erven_feats}
        ERVEN_OUT.write_text(json.dumps(erven_fc), encoding="utf-8")
        log(f"[out] erven → {ERVEN_OUT}")

    if not fetch_buildings:
        return

    erven_gdf = gpd.GeoDataFrame.from_features(erven_feats, crs=4326) if erven_feats else None

    if bld_gdf is None or len(bld_gdf) == 0:
        log("[Overture] No buildings — writing empty file")
        BUILDINGS_OUT.write_text('{"type":"FeatureCollection","features":[]}', encoding="utf-8")
        return

    # Clip buildings to AOI before further processing
    if aoi_geom is not None:
        bld_gdf = _clip_gdf_to_aoi(bld_gdf, aoi_geom)
        if len(bld_gdf) == 0:
            log("[Overture] No buildings remain after AOI clip")
            BUILDINGS_OUT.write_text('{"type":"FeatureCollection","features":[]}', encoding="utf-8")
            return

    # Assign is_primary (one per erven)
    bld_gdf = assign_primary(bld_gdf, erven_gdf)

    # Pick only the geometry + fields we need for the Buildings layer
    keep = gpd.GeoDataFrame(geometry=bld_gdf.geometry, crs=bld_gdf.crs)
    keep["id"] = [str(i + 1) for i in range(len(bld_gdf))]
    keep["Name"] = ""
    keep["Discriptio"] = ""
    # Classify building_t from Overture 'class' if available, else SDU
    if "class" in bld_gdf.columns:
        def _btype(cls):
            cls = str(cls or "").lower()
            if "apartment" in cls or "residential" in cls:
                return "SDU"
            if "industrial" in cls or "commercial" in cls:
                return "MDU"
            return "SDU"
        keep["building_t"] = bld_gdf["class"].apply(_btype)
    else:
        keep["building_t"] = "SDU"
    keep["area_m2"] = (bld_gdf["area_m2"] if "area_m2" in bld_gdf.columns
                       else bld_gdf.geometry.to_crs(32735).area.round(2))
    keep["is_primary"] = bld_gdf["is_primary"].astype(int)

    keep.to_file(BUILDINGS_OUT, driver="GeoJSON")
    log(f"[out] buildings → {BUILDINGS_OUT}  ({len(keep)} features)")


if __name__ == "__main__":
    main()
