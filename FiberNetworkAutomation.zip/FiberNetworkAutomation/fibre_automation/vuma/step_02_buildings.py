"""Vuma Step 2 — Tag and clean the Buildings layer.

STATUS: [x] BUILT
"""

# claude:approved-destructive

from qgis.core import QgsProject

from fibre_automation.shared.geometry_utils import (
    build_spatial_index,
    classify_building,
    compute_area_m2,
    overlaps_significantly,
    polsby_popper,
)


def _get(name):
    layers = QgsProject.instance().mapLayersByName(name)
    return layers[0] if layers else None


def vuma_step_02_buildings():
    """Tag Buildings layer with building_t, area_m2, is_primary.

    STATUS: [x] BUILT
    Safe to re-run — only processes untagged buildings (building_t IS NULL).

    building_t values:
      SDU    — single standalone house (largest per erf, or only building)
      BY     — secondary structure on same erf (backyard/outbuilding)
      MDU    — multi-dwelling unit (large footprint, low compactness)
      SHACK  — informal structure (small + low compactness)
      SLIVER — noise polygon (< 15 m²), skip for demand points

    is_primary:
      1 = primary building on erf (drives demand point placement)
      0 = secondary / non-primary
    """
    print(f"\n{'═' * 50}")
    print("  VUMA STEP 2 — Building Classification")
    print(f"{'═' * 50}")

    bld_layer = _get("Buildings")
    if bld_layer is None:
        print("  ✗ 'Buildings' layer not found.")
        return

    # Ensure required fields exist
    fields = bld_layer.fields()
    btype_idx  = fields.indexOf("building_t")
    area_idx   = fields.indexOf("area_m2")
    prim_idx   = fields.indexOf("is_primary")

    if btype_idx < 0 or area_idx < 0 or prim_idx < 0:
        print("  ✗ Buildings layer missing required fields — run Step 1 first.")
        return

    # Collect all features
    all_feats = {f.id(): f for f in bld_layer.getFeatures()}
    if not all_feats:
        print("  (no buildings found)")
        return

    # Only process untagged buildings
    untagged = {
        fid: f for fid, f in all_feats.items()
        if (f[btype_idx] is None or str(f[btype_idx]).strip() == "")
        and f.hasGeometry()
    }
    if not untagged:
        print("  (all buildings already tagged — nothing to do)")
        print(f"{'═' * 50}\n")
        return

    print(f"  Classifying {len(untagged):,} untagged buildings …")

    bld_crs = bld_layer.crs()

    # Phase 1: per-building classification (SDU/SHACK/SLIVER/MDU)
    classifications = {}
    area_m2_vals = {}
    for fid, feat in untagged.items():
        geom = feat.geometry()
        area = compute_area_m2(geom, bld_crs)
        area_m2_vals[fid] = area

        btype = classify_building(geom, crs=bld_crs)
        if btype == "SDU" and area > 200 and polsby_popper(geom) < 0.55:
            btype = "MDU"
        classifications[fid] = btype

    # Phase 2: spatial grouping — find overlapping buildings on same erf
    # Build spatial index over ALL buildings (tagged + untagged) for overlap check
    index, feat_map = build_spatial_index(bld_layer)

    # Group untagged buildings that overlap each other
    visited = set()
    groups = []

    for fid, feat in untagged.items():
        if fid in visited:
            continue
        geom = feat.geometry()
        bbox = geom.boundingBox()
        candidates = index.intersects(bbox)
        group = [fid]
        visited.add(fid)
        for cid in candidates:
            if cid == fid or cid in visited or cid not in untagged:
                continue
            other = feat_map[cid]
            if overlaps_significantly(geom, other.geometry(), threshold=0.1):
                group.append(cid)
                visited.add(cid)
        groups.append(group)

    # Phase 3: within each overlapping group, largest non-SLIVER = SDU primary,
    # rest get BY tag
    is_primary = {}
    final_type = dict(classifications)

    for group in groups:
        non_slivers = [fid for fid in group if classifications[fid] != "SLIVER"]
        if not non_slivers:
            for fid in group:
                is_primary[fid] = 0
            continue

        if len(non_slivers) == 1:
            is_primary[non_slivers[0]] = 1
            continue

        # Multiple buildings on same erf — largest is primary
        sorted_group = sorted(non_slivers, key=lambda x: area_m2_vals[x], reverse=True)
        primary_fid = sorted_group[0]
        is_primary[primary_fid] = 1

        for fid in sorted_group[1:]:
            if final_type[fid] in ("SDU", "MDU"):
                final_type[fid] = "BY"
            is_primary[fid] = 0

        for fid in group:
            if fid not in is_primary:
                is_primary[fid] = 0

    # Default: lone buildings are primary
    for fid in untagged:
        if fid not in is_primary:
            is_primary[fid] = 1

    # Phase 4: bulk write  # claude:approved-destructive
    attr_changes = {}
    for fid in untagged:
        attr_changes[fid] = {
            btype_idx: final_type[fid],
            area_idx:  round(area_m2_vals[fid], 2),
            prim_idx:  is_primary.get(fid, 1),
        }

    bld_layer.dataProvider().changeAttributeValues(attr_changes)
    bld_layer.triggerRepaint()

    # Summary
    counts = {}
    for t in final_type.values():
        counts[t] = counts.get(t, 0) + 1

    print("\n  ══ CLASSIFICATION ══")
    for tag in ("SDU", "BY", "MDU", "SHACK", "SLIVER"):
        n = counts.get(tag, 0)
        if n:
            print(f"  {tag:<8} {n:>6,}")
    primary_count = sum(1 for v in is_primary.values() if v == 1)
    print(f"\n  Primary buildings (is_primary=1): {primary_count:,}")
    print(f"  Total tagged this run:            {len(untagged):,}")
    print(f"{'═' * 50}\n")
