"""HeroTel pipeline — run_all and per-step stubs."""



def herotel_run_all():
    """Run all HeroTel steps in sequence (placeholder until schemas are supplied)."""
    from fibre_automation.herotel.step_01_setup import herotel_step_01_setup
    herotel_step_01_setup()


def _stub(step_name):
    def _fn():
        print(f"\n  ⏳ {step_name}: not yet implemented — schema pending from JJ.\n")
    _fn.__name__ = step_name
    return _fn


herotel_step_02 = _stub("herotel_step_02 (Fetch Data)")
herotel_step_03 = _stub("herotel_step_03 (Place ONTs)")
herotel_step_04 = _stub("herotel_step_04 (Design Network)")
herotel_step_05 = _stub("herotel_step_05 (QA Check)")
herotel_step_06 = _stub("herotel_step_06 (Export)")
