"""HeroTel Step 1 — Create project layers, groups, and apply styles.

STATUS: PENDING SCHEMA
Required from JJ before this can be built:
  1. Layer names used in HeroTel QGIS projects (exact strings)
  2. Field schemas for each layer (field name, type, length)
  3. QML style files or at least symbology rules
  4. Label format conventions (e.g. HRT.P.001 or similar)
  5. BOM field names (part numbers, quantities, categories)

What we already know from the TSD (Fibre Aerial Deployment 2025-09-01):
  Poles:      5.4m (100-120mm straight / 120-140mm corner) | 7.2m (road cross) | 9m (exception)
              Standard: CCA H4 SANS 754 — hole depths 800/1000/1200 mm
  Cables:     12/18/24/36/48/72/96/144/288F SSA (CFS); Drop = 4F Dual Drop 3.8mm
  Splitters:  1:2, 1:4, 1:8, 1:16, 1:32 (bare)
  Enclosures: LightSpeed Dome 5+1 MS 1C 24F | Dome 3+1P 48F | Dome 4+1P 72F | Dome 6+1P 144F
  Spans:      midblock ≤ 50m; long-haul dead-end every 500m

Placeholder: herotel_step_01_setup() prints what's needed so JJ gets a clear prompt.
"""

from fibre_automation.startup import SESSION


def herotel_step_01_setup():
    """Placeholder: prints what schema information is still needed from JJ."""
    area = SESSION.get("area_code") or "HRT"
    print(f"\n{'═' * 60}")
    print("  HEROTEL STEP 1 — Layer Setup  [SCHEMA PENDING]")
    print(f"  Area: {area}")
    print(f"{'═' * 60}")
    print()
    print("  ⏳ Layer setup is not yet implemented.")
    print("  Supply the following to complete this step:")
    print()
    print("  1. Layer names (exact QGIS strings for each layer)")
    print("     e.g. 'Poles v1', 'Drop Cable v1', 'Splitters v1', ...")
    print()
    print("  2. Field schemas per layer:")
    print("     - Pole layer: label format, pole_type, thickness class,")
    print("       height, hole_depth, hardware slots, lat/lon, admin fields")
    print("     - Cable layers: label format, fibre count, cable type,")
    print("       length fields, start/end feature refs")
    print("     - Splitter layers: ratio, label, enclosure ref")
    print("     - Enclosure layers: type, product code, capacity")
    print("     - ONT / Home Connection: label format, DR number range")
    print()
    print("  3. QML style files OR symbology description for each layer")
    print()
    print("  4. Label conventions, e.g.:")
    print("     Poles:  HRT.P.001  — or local format?")
    print("     ONT:    HRT.ONT.001  — or DR-number style?")
    print("     Cables: HRT.DC.001  — or per-block naming?")
    print()
    print("  5. PON / splitter cascade used:")
    print("     Current material list shows 1:2 – 1:32 ratios.")
    print("     What is the standard cascade (e.g. 1:4 + 1:32 = 128)?")
    print()
    print(f"{'═' * 60}\n")
