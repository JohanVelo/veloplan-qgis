"""HeroTel FTTH aerial pipeline (MEGAnet / CFS component stack)."""
