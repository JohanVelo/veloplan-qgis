"""Wire STEP_MAP in startup.py to the Vuma and Fibre Time pipelines.

Import this module once (e.g. from fiber_network_plugin.py) to register
all step handlers. After import, route_step('vuma_step_01') and
route_step('ft_step_03') etc. will dispatch correctly.
"""

from fibre_automation.startup import STEP_MAP

from fibre_automation.vuma.pipeline import vuma_run_all
from fibre_automation.vuma.step_01_setup import vuma_step_01_setup
from fibre_automation.vuma.step_01b_fetch import vuma_step_01b_fetch
from fibre_automation.vuma.step_01c_centroids import vuma_step_01c_centroids
from fibre_automation.vuma.step_02_buildings import vuma_step_02_buildings
from fibre_automation.vuma.step_03_demand import vuma_step_03_demand
from fibre_automation.vuma.step_04_pon import vuma_step_04_pon
from fibre_automation.vuma.step_05_nodes import vuma_step_05_nodes
from fibre_automation.vuma.step_06_cables import vuma_step_06_cables
from fibre_automation.vuma.step_07_naming import vuma_step_07_naming
from fibre_automation.vuma.step_08_attributes import vuma_step_08_attributes
from fibre_automation.vuma.step_09_qa import vuma_step_09_qa
from fibre_automation.vuma.step_10_output import vuma_step_10_output


from fibre_automation.fibretime.step_01_setup import ft_step_01_setup
from fibre_automation.fibretime.pipeline import (
    ft_run_all,
    ft_step_01_poles,
    ft_step_02_distribution,
    ft_step_03_secondary,
    ft_step_04_enclosure,
    ft_step_05_pon,
    ft_step_06_pon_order,
    ft_step_07_thickness,
    ft_step_08_rc_update,
    ft_step_09_qa,
    ft_step_10_output,
)

# ── Vuma steps ────────────────────────────────────────────────────────────────
STEP_MAP["vuma_step_01"] = vuma_step_01_setup
STEP_MAP["vuma_step_01b"] = vuma_step_01b_fetch
STEP_MAP["vuma_step_01c"] = vuma_step_01c_centroids
STEP_MAP["vuma_step_02"] = vuma_step_02_buildings
STEP_MAP["vuma_step_03"] = vuma_step_03_demand
STEP_MAP["vuma_step_04"] = vuma_step_04_pon
STEP_MAP["vuma_step_05"] = vuma_step_05_nodes
STEP_MAP["vuma_step_06"] = vuma_step_06_cables
STEP_MAP["vuma_step_07"] = vuma_step_07_naming
STEP_MAP["vuma_step_08"] = vuma_step_08_attributes
STEP_MAP["vuma_step_09"] = vuma_step_09_qa
STEP_MAP["vuma_step_10"] = vuma_step_10_output
STEP_MAP["vuma_run_all"] = vuma_run_all

# ── Fibre Time steps ──────────────────────────────────────────────────────────
STEP_MAP["ft_step_01_setup"] = ft_step_01_setup
STEP_MAP["ft_step_01"] = ft_step_01_poles
STEP_MAP["ft_step_02"] = ft_step_02_distribution
STEP_MAP["ft_step_03"] = ft_step_03_secondary
STEP_MAP["ft_step_04"] = ft_step_04_enclosure
STEP_MAP["ft_step_05"] = ft_step_05_pon
STEP_MAP["ft_step_06"] = ft_step_06_pon_order
STEP_MAP["ft_step_07"] = ft_step_07_thickness
STEP_MAP["ft_step_08"] = ft_step_08_rc_update
STEP_MAP["ft_step_09"] = ft_step_09_qa
STEP_MAP["ft_step_10"] = ft_step_10_output
STEP_MAP["ft_run_all"] = ft_run_all

# ── HeroTel steps ─────────────────────────────────────────────────────────────
from fibre_automation.herotel.step_01_setup import herotel_step_01_setup
from fibre_automation.herotel.pipeline import (
    herotel_run_all,
    herotel_step_02,
    herotel_step_03,
    herotel_step_04,
    herotel_step_05,
    herotel_step_06,
)

STEP_MAP["herotel_step_01"] = herotel_step_01_setup
STEP_MAP["herotel_step_02"] = herotel_step_02
STEP_MAP["herotel_step_03"] = herotel_step_03
STEP_MAP["herotel_step_04"] = herotel_step_04
STEP_MAP["herotel_step_05"] = herotel_step_05
STEP_MAP["herotel_step_06"] = herotel_step_06
STEP_MAP["herotel_run_all"] = herotel_run_all
