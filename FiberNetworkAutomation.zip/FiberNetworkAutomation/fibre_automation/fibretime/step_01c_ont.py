"""Fibre Time Step 1c — Place ONT + Home Connection centroids from buildings.

Runs automatically at the end of Step 1b when the project is FibreTime.
Also callable standalone after Step 1b has populated Buildings + Erven.

STATUS: [x] BUILT
"""

from qgis.core import (
    QgsFeature,
    QgsGeometry,
    QgsPointXY,
    QgsProject,
    QgsSpatialIndex,
)


def _get(name):
    layers = QgsProject.instance().mapLayersByName(name)
    return layers[0] if layers else None


def ft_step_01c_ont():
    """Place one ONT + Home Connection centroid per primary building.

    Safe to re-run — skips buildings already represented in ONT v1.
    Uses pointOnSurface() so the point always lands inside the footprint.
    Erven fallback: any erf with no Overture building still gets a centroid.
    """
    print(f"\n{'═' * 55}")
    print("  FT STEP 1c — ONT / Home Connection Centroids")
    print(f"{'═' * 55}")

    bld_lyr   = _get("Buildings")
    ont_lyr   = _get("ONT v1")
    hc_lyr    = _get("Home Connection v1")
    erven_lyr = _get("Erven")

    if bld_lyr is None:
        print("  ✗ 'Buildings' layer not found — run Step 1 first.")
        return
    if ont_lyr is None:
        print("  ✗ 'ONT v1' layer not found — run Step 1 first.")
        return
    has_buildings = bld_lyr is not None and bld_lyr.featureCount() > 0
    has_erven     = erven_lyr is not None and erven_lyr.featureCount() > 0
    if not has_buildings and not has_erven:
        print("  ✗ No buildings or erven yet — run Step 1b first.")
        return
    if not has_buildings:
        print("  ℹ  No Overture buildings — using erven centroids as fallback.")

    try:
        from fibre_automation.startup import SESSION
        area = SESSION.get("area_code") or "ONT"
    except Exception:
        area = "ONT"

    prim_idx = bld_lyr.fields().indexOf("is_primary")

    # Build spatial index on erven
    erven_by_fid    = {}
    erven_index     = None
    erven_label_idx = -1
    if erven_lyr and erven_lyr.featureCount() > 0:
        erven_label_idx = erven_lyr.fields().indexOf("Label")
        erven_by_fid    = {f.id(): f for f in erven_lyr.getFeatures()}
        erven_index     = QgsSpatialIndex()
        for f in erven_by_fid.values():
            erven_index.addFeature(f)

    # Build set of positions already in ONT v1 (re-run guard)
    existing_pts: set = set()
    ont_lat_idx = ont_lyr.fields().indexOf("lat")
    ont_lon_idx = ont_lyr.fields().indexOf("lon")
    for feat in ont_lyr.getFeatures():
        lat = feat[ont_lat_idx] if ont_lat_idx >= 0 else None
        lon = feat[ont_lon_idx] if ont_lon_idx >= 0 else None
        if lat is not None and lon is not None:
            try:
                existing_pts.add((round(float(lon), 5), round(float(lat), 5)))
            except (TypeError, ValueError):
                pass

    # Collect building centroids not yet placed
    to_add = []  # list of (QgsPointXY, erf_label_or_None)
    for feat in bld_lyr.getFeatures():
        if not feat.hasGeometry():
            continue
        if prim_idx >= 0 and feat[prim_idx] != 1:
            continue
        pt  = feat.geometry().pointOnSurface().asPoint()
        key = (round(pt.x(), 5), round(pt.y(), 5))
        if key in existing_pts:
            continue

        erf_label = None
        if erven_index is not None:
            pt_geom    = QgsGeometry.fromPointXY(pt)
            candidates = erven_index.intersects(pt_geom.boundingBox())
            for fid in candidates:
                if erven_by_fid[fid].geometry().contains(pt_geom):
                    raw = erven_by_fid[fid][erven_label_idx] if erven_label_idx >= 0 else None
                    erf_label = str(raw) if raw is not None else None
                    break

        to_add.append((pt, erf_label))

    # Erven fallback: any erf with no Overture building gets a centroid
    if erven_lyr and erven_index is not None:
        covered: set = {erf for _, erf in to_add if erf}
        for feat in ont_lyr.getFeatures():
            pass  # covered set already built from existing_pts check above

        for fid, erf_feat in erven_by_fid.items():
            if not erf_feat.hasGeometry():
                continue
            raw_label = erf_feat[erven_label_idx] if erven_label_idx >= 0 else None
            erf_label = str(raw_label) if raw_label is not None else None
            if erf_label and erf_label in covered:
                continue
            pt  = erf_feat.geometry().pointOnSurface().asPoint()
            key = (round(pt.x(), 5), round(pt.y(), 5))
            if key in existing_pts:
                continue
            to_add.append((pt, erf_label))

    if not to_add:
        n = ont_lyr.featureCount()
        print(f"  (all {n:,} ONT centroids already placed — nothing to do)")
        print(f"{'═' * 55}\n")
        return

    # Sort north → south for deterministic output order
    to_add.sort(key=lambda x: (-x[0].y(), x[0].x()))

    next_seq = ont_lyr.featureCount() + 1

    def _make_feat(lyr, pt, label, seq):
        nf = QgsFeature(lyr.fields())
        nf.setGeometry(QgsGeometry.fromPointXY(QgsPointXY(pt.x(), pt.y())))
        fields = lyr.fields()

        def _set(name, val):
            idx = fields.indexOf(name)
            if idx >= 0:
                nf.setAttribute(idx, val)

        _set("label",   label)
        _set("type",    "Home Connection")
        _set("subtyp",  "ONT")
        _set("spec",    "Nokia ONT G-2425G-A")
        _set("lat",     round(pt.y(), 8))
        _set("lon",     round(pt.x(), 8))
        _set("status",  "planned")
        return nf

    ont_feats = []
    hc_feats  = []

    for pt, erf_label in to_add:
        label = f"{area}.ONT.{next_seq:05d}"
        next_seq += 1
        ont_feats.append(_make_feat(ont_lyr, pt, label, next_seq))
        if hc_lyr is not None:
            hc_feats.append(_make_feat(hc_lyr, pt, label, next_seq))

    BATCH = 2000
    for i in range(0, len(ont_feats), BATCH):
        ont_lyr.dataProvider().addFeatures(ont_feats[i:i + BATCH])
    ont_lyr.updateExtents()
    ont_lyr.triggerRepaint()

    if hc_lyr is not None and hc_feats:
        for i in range(0, len(hc_feats), BATCH):
            hc_lyr.dataProvider().addFeatures(hc_feats[i:i + BATCH])
        hc_lyr.updateExtents()
        hc_lyr.triggerRepaint()

    print("\n  ══ ONT CENTROIDS ══")
    print(f"  ONT v1 added:              {len(ont_feats):,}")
    if hc_lyr is not None:
        print(f"  Home Connection v1 added:  {len(hc_feats):,}")
    print(f"  Total ONT v1:              {ont_lyr.featureCount():,}")
    print(f"{'═' * 55}\n")
