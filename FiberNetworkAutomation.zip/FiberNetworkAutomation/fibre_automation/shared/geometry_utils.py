"""Building cleanup, area/compactness, clustering helpers."""

import math

from qgis.core import (
    QgsSpatialIndex,
    QgsGeometry,
)


# ---------------------------------------------------------------------------
# Building classification
# ---------------------------------------------------------------------------

MIN_BUILDING_AREA_M2 = 15
MAX_SHACK_AREA_M2 = 45
MIN_HOUSE_AREA_M2 = 45
COMPACTNESS_THRESHOLD = 0.3


def compute_area_m2(geom: QgsGeometry, crs=None) -> float:
    """Return geometry area in square metres regardless of CRS.

    For geographic CRS (degrees), uses QgsDistanceArea on the WGS84 ellipsoid.
    For projected CRS (metres), returns geom.area() directly.
    """
    if crs is not None and hasattr(crs, "isGeographic") and crs.isGeographic():
        from qgis.core import QgsDistanceArea, QgsProject
        da = QgsDistanceArea()
        da.setSourceCrs(crs, QgsProject.instance().transformContext())
        da.setEllipsoid(crs.ellipsoidAcronym())
        return da.measureArea(geom)
    return geom.area()


def polsby_popper(geom: QgsGeometry) -> float:
    """Polsby-Popper compactness ratio: 4π·area / perimeter²  (0–1, 1 = circle)."""
    area = geom.area()
    perim = geom.length()
    if perim == 0:
        return 0.0
    return (4 * math.pi * area) / (perim ** 2)


def classify_building(geom: QgsGeometry, crs=None) -> str:
    """Return 'SDU' | 'SHACK' based on area and compactness.

    Pass the layer CRS so area thresholds are correctly applied regardless of
    whether the layer is geographic (degrees) or projected (metres).
    """
    area = compute_area_m2(geom, crs)
    if area < MIN_BUILDING_AREA_M2:
        return "SLIVER"
    compact = polsby_popper(geom)
    if area >= MIN_HOUSE_AREA_M2:
        return "SDU"
    if compact < COMPACTNESS_THRESHOLD:
        return "SHACK"
    return "SDU"


def overlaps_significantly(geom_a: QgsGeometry, geom_b: QgsGeometry, threshold: float = 0.5) -> bool:
    """True if intersection > threshold × area of smaller polygon."""
    intersection = geom_a.intersection(geom_b)
    if intersection.isEmpty():
        return False
    smaller = min(geom_a.area(), geom_b.area())
    if smaller == 0:
        return False
    return intersection.area() / smaller > threshold


# ---------------------------------------------------------------------------
# Spatial index helpers
# ---------------------------------------------------------------------------

def build_spatial_index(layer) -> tuple:
    """Build a QgsSpatialIndex for a layer. Returns (index, {fid: feature})."""
    index = QgsSpatialIndex()
    feat_map = {}
    for feat in layer.getFeatures():
        if feat.hasGeometry():
            index.insertFeature(feat)
            feat_map[feat.id()] = feat
    return index, feat_map


def nearest_feature(point_geom: QgsGeometry, index: QgsSpatialIndex, feat_map: dict, max_distance: float = None):
    """Return the nearest feature from index/feat_map, or None if beyond max_distance."""
    candidates = index.nearestNeighbor(point_geom.asPoint(), 1)
    if not candidates:
        return None
    fid = candidates[0]
    feat = feat_map[fid]
    if max_distance is not None:
        dist = point_geom.distance(feat.geometry())
        if dist > max_distance:
            return None
    return feat


# ---------------------------------------------------------------------------
# K-means clustering (uses scipy if available, falls back to simple version)
# ---------------------------------------------------------------------------

def kmeans_cluster_points(features, n_clusters: int) -> list:
    """Cluster point features using K-means. Returns list of cluster_id per feature.

    Tries scipy first (available in QGIS venv), falls back to simple Lloyd's algorithm.
    """
    coords = []
    for feat in features:
        pt = feat.geometry().asPoint()
        coords.append((pt.x(), pt.y()))

    if not coords:
        return []

    try:
        from scipy.cluster.vq import kmeans2
        import numpy as np

        data = np.array(coords)
        _, labels = kmeans2(data, min(n_clusters, len(coords)), minit="points", seed=42)
        return labels.tolist()
    except ImportError:
        return _simple_kmeans(coords, n_clusters)


def kmeans_cluster_points_balanced(features, n_clusters: int, max_per_cluster: int) -> list:
    """Capacity-constrained K-means. No cluster will exceed max_per_cluster.

    Algorithm:
      1. Run standard K-means to get spatially-optimal initial centroids.
      2. Re-assign every point to its nearest centroid that still has capacity,
         processing points in order of their distance to the closest centroid
         (most-constrained points get first pick).

    Falls back to unconstrained K-means if scipy is unavailable.
    """
    coords = []
    for feat in features:
        pt = feat.geometry().asPoint()
        coords.append((pt.x(), pt.y()))

    if not coords:
        return []

    n = len(coords)
    k = min(n_clusters, n)

    try:
        import numpy as np
        from scipy.cluster.vq import kmeans2
        from scipy.spatial.distance import cdist

        data = np.array(coords, dtype=float)

        # Step 1 — get good initial centroids from standard K-means
        centroids, _ = kmeans2(data, k, minit="points", seed=42)

        # Step 2 — capacity-constrained assignment
        D = cdist(data, centroids)          # shape (n, k)
        cap = np.zeros(k, dtype=int)
        assignments = np.full(n, -1, dtype=int)

        # Process points whose nearest centroid is closest first
        order = np.argsort(D.min(axis=1))
        cluster_pref = np.argsort(D, axis=1)  # (n, k) — preferred cluster order per point

        for idx in order:
            assigned = False
            for j in cluster_pref[idx]:
                if cap[j] < max_per_cluster:
                    assignments[idx] = int(j)
                    cap[j] += 1
                    assigned = True
                    break
            if not assigned:
                # All clusters at capacity — assign to least-full (overflow guard)
                j = int(np.argmin(cap))
                assignments[idx] = j
                cap[j] += 1

        return assignments.tolist()

    except ImportError:
        return _simple_kmeans(coords, k)


def _simple_kmeans(coords: list, k: int, max_iter: int = 100) -> list:
    """Fallback Lloyd's algorithm K-means."""
    import random

    random.seed(42)
    k = min(k, len(coords))
    centroids = random.sample(coords, k)

    labels = [0] * len(coords)
    for _ in range(max_iter):
        # Assign
        new_labels = []
        for x, y in coords:
            dists = [math.hypot(x - cx, y - cy) for cx, cy in centroids]
            new_labels.append(dists.index(min(dists)))
        if new_labels == labels:
            break
        labels = new_labels
        # Update centroids
        for ci in range(k):
            members = [(x, y) for (x, y), lbl in zip(coords, labels) if lbl == ci]
            if members:
                centroids[ci] = (
                    sum(m[0] for m in members) / len(members),
                    sum(m[1] for m in members) / len(members),
                )
    return labels
