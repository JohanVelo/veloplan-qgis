import json
from qgis.core import QgsVectorLayer

def layer_to_list(name, fields_to_get):
    matches = QgsProject.instance().mapLayersByName(name)
    if not matches:
        print(f"[MISSING] {name}")
        return []
    lyr = matches[0]
    if not isinstance(lyr, QgsVectorLayer):
        return []
    out = []
    for feat in lyr.getFeatures():
        row = {}
        for f in fields_to_get:
            val = feat[f] if f in [x.name() for x in lyr.fields()] else None
            row[f] = str(val) if val is not None and str(val) != 'NULL' else None
        out.append(row)
    return out

# Primary cables
primary = layer_to_list('Primary Cable v1',
    ['label','cblcpty','ntwrkptn','strtfeat','endfeat','dim2','pon_no','zone_no'])
print(f"Primary cables: {len(primary)}")

# Secondary cables
secondary = layer_to_list('Secondary Cable v1',
    ['label','cblcpty','ntwrkptn','strtfeat','endfeat','dim2','pon_no','zone_no'])
print(f"Secondary cables: {len(secondary)}")

# Distribution cables
distribution = layer_to_list('Distribution Cable v1',
    ['label','cblcpty','ntwrkptn','strtfeat','endfeat','dim2','pon_no','zone_no'])
print(f"Distribution cables: {len(distribution)}")

# FTS splitters v1
fts = layer_to_list('FTS Splitters v1',
    ['label','cblcpty','strtfeat','endfeat','pon_no','zone_no','lat','lon'])
print(f"FTS splitters: {len(fts)}")

# STS splitters v1 - get full fields
matches = QgsProject.instance().mapLayersByName('STS Splitters v1')
lyr = matches[0]
sts_fields = [f.name() for f in lyr.fields()]
print(f"STS fields: {sts_fields}")
sts = layer_to_list('STS Splitters v1',
    ['label','cblcpty','strtfeat','endfeat','pon_no','zone_no','lat','lon'])
print(f"STS splitters: {len(sts)}")
if sts:
    print(f"STS sample: {sts[0]}")

# Enclosures Splice v1 (AGG domes = FTS housings)
agg_domes = layer_to_list('Enclosures Splice v1',
    ['label_1','spec_1','cblcpty1','strtfeat','pon_no','zone_no','lat','lon'])
print(f"AGG domes (FTS enclosures): {len(agg_domes)}")

# Enclosures Connectorised v1 (DIS domes = STS housings)
dis_domes = layer_to_list('Enclosures Connectorised v1',
    ['label_1','spec_1','cblcpty1','strtfeat','pon_no','zone_no','lat','lon'])
print(f"DIS domes (STS enclosures): {len(dis_domes)}")

# Drop cables - sample only (6335 rows)
drops_raw = layer_to_list('Drop Cable v1',
    ['label','cblcpty','strtfeat','endfeat','pon_no','zone_no','dim2'])
print(f"Drop cables: {len(drops_raw)}")

# ONTs - pon_no summary
ont_layer = QgsProject.instance().mapLayersByName('ONT v1')[0]
pon_counts = {}
for feat in ont_layer.getFeatures():
    pon = str(feat['pon_no']) if feat['pon_no'] else 'NULL'
    pon_counts[pon] = pon_counts.get(pon, 0) + 1
print(f"PON counts (sample): {dict(sorted(pon_counts.items())[:5])}")

# Save all data to JSON
data = {
    'primary': primary,
    'secondary': secondary,
    'distribution': distribution,
    'fts': fts,
    'sts': sts,
    'agg_domes': agg_domes,
    'dis_domes': dis_domes,
    'drops': drops_raw,
    'pon_ont_counts': pon_counts,
}

with open('C:/Temp/splice_data.json', 'w') as f:
    json.dump(data, f, indent=2)

print("\nSaved to C:/Temp/splice_data.json")
print(f"Total features: {len(primary)+len(secondary)+len(distribution)+len(fts)+len(sts)+len(drops_raw)}")
