"""
MOA Phase 2 Splice Plan Generator
Generates a 5-sheet Excel splice plan from the exported QGIS data.
"""
import json
import os
from openpyxl import Workbook
from openpyxl.styles import (PatternFill, Font, Alignment, Border, Side,
                              GradientFill)
from openpyxl.utils import get_column_letter
from openpyxl.styles.numbers import FORMAT_NUMBER_00

# ── Load data ──────────────────────────────────────────────────────────────
with open('C:/Temp/splice_data.json') as f:
    data = json.load(f)

primary     = data['primary']
secondary   = data['secondary']
distribution = data['distribution']
fts         = data['fts']
sts         = data['sts']
agg_domes   = data['agg_domes']
dis_domes   = data['dis_domes']
drops       = data['drops']
pon_counts  = data['pon_ont_counts']

# ── TIA-598-C 12-colour sequence ──────────────────────────────────────────
TUBE_COLORS = [
    (1,  'Blue',   '2E75B6'),
    (2,  'Orange', 'FF7F00'),
    (3,  'Green',  '70AD47'),
    (4,  'Brown',  '7B3F00'),
    (5,  'Slate',  '808080'),
    (6,  'White',  'FFFFFF'),
    (7,  'Red',    'FF0000'),
    (8,  'Black',  '000000'),
    (9,  'Yellow', 'FFFF00'),
    (10, 'Violet', '7030A0'),
    (11, 'Rose',   'FF66CC'),
    (12, 'Aqua',   '00B0F0'),
]

def tube_for_fiber(fiber_num):
    """Return (tube_no, tube_name, hex_color) for 1-based fiber number."""
    idx = (fiber_num - 1) // 12
    t_no, color_name, hex_col = TUBE_COLORS[idx % 12]
    return t_no, color_name, hex_col

def fibers_for_capacity(cblcpty):
    """Return int fiber count from '24F', '48F', '144F', '1F' etc."""
    try:
        return int(str(cblcpty).replace('F','').strip())
    except:
        return 0

# ── Zone colour palette (zone 17–20) ──────────────────────────────────────
ZONE_BG = {'17': 'DDEEFF', '18': 'DFFFD6', '19': 'FFF2CC', '20': 'FFE0E0'}
ZONE_HDR = {'17': '1F4E79', '18': '375623', '19': '7B5A00', '20': '832323'}
ZONE_FONT_COLORS = {'17': 'FFFFFF', '18': 'FFFFFF', '19': 'FFFFFF', '20': 'FFFFFF'}

def zone_fill(zone_no):
    c = ZONE_BG.get(str(zone_no), 'F2F2F2')
    return PatternFill('solid', fgColor=c)

def header_fill(zone_no):
    c = ZONE_HDR.get(str(zone_no), '404040')
    return PatternFill('solid', fgColor=c)

# ── Styling helpers ───────────────────────────────────────────────────────
THIN = Side(style='thin', color='AAAAAA')
THIN_BORDER = Border(left=THIN, right=THIN, top=THIN, bottom=THIN)
HEADER_FONT = Font(bold=True, color='FFFFFF', size=9)
BODY_FONT   = Font(size=9)
MONO_FONT   = Font(name='Courier New', size=8)
TITLE_FONT  = Font(bold=True, size=11)

def style_cell(cell, font=None, fill=None, align=None, border=True, number_format=None):
    if font:   cell.font   = font
    if fill:   cell.fill   = fill
    if align:  cell.alignment = align
    if border: cell.border = THIN_BORDER
    if number_format: cell.number_format = number_format

def set_row(ws, row_idx, values, font=None, fill=None, align_center=False):
    for col, val in enumerate(values, 1):
        c = ws.cell(row=row_idx, column=col, value=val)
        if font:  c.font = font
        if fill:  c.fill = fill
        c.border = THIN_BORDER
        if align_center:
            c.alignment = Alignment(horizontal='center', vertical='center', wrap_text=True)
        else:
            c.alignment = Alignment(vertical='center', wrap_text=True)

# ── Tube colour fill ──────────────────────────────────────────────────────
def tube_fill(hex_col):
    if hex_col == 'FFFFFF':
        return PatternFill('solid', fgColor='F0F0F0')  # white → light grey
    if hex_col == '000000':
        return PatternFill('solid', fgColor='333333')
    return PatternFill('solid', fgColor=hex_col)

def tube_font(hex_col):
    dark = hex_col in ('000000', '7B3F00', '7030A0', '2E75B6', '375623')
    return Font(size=9, color='FFFFFF' if dark else '000000', bold=True)

# ── Build workbook ────────────────────────────────────────────────────────
wb = Workbook()

# ════════════════════════════════════════════════════════════════════════════
# SHEET 1: COVER / SUMMARY
# ════════════════════════════════════════════════════════════════════════════
ws_cover = wb.active
ws_cover.title = '1. Summary'
ws_cover.column_dimensions['A'].width = 30
ws_cover.column_dimensions['B'].width = 40

# Title block
ws_cover.merge_cells('A1:B1')
c = ws_cover['A1']
c.value = 'SPLICE PLAN — MOHADIN PHASE 2 (MOA)'
c.font  = Font(bold=True, size=14, color='FFFFFF')
c.fill  = PatternFill('solid', fgColor='1F4E79')
c.alignment = Alignment(horizontal='center', vertical='center')
ws_cover.row_dimensions[1].height = 28

def info_row(ws, r, label, value):
    a = ws.cell(row=r, column=1, value=label)
    b = ws.cell(row=r, column=2, value=value)
    a.font = Font(bold=True, size=9)
    b.font = Font(size=9)
    a.fill = PatternFill('solid', fgColor='D6E4F0')
    a.border = THIN_BORDER; b.border = THIN_BORDER
    a.alignment = Alignment(vertical='center')
    b.alignment = Alignment(vertical='center')

total_onts = sum(int(v) for v in pon_counts.values() if str(v).isdigit())

info_rows = [
    ('Project', 'Potch – Mohadin Phase 2'),
    ('Operator', 'VelocityFibre / Fibertime'),
    ('Municipality', 'JB Marks Local Municipality'),
    ('Technology', 'GPON FTTH — Aerial'),
    ('Date', '2026-05-21'),
    ('', ''),
    ('PON Range', '235 – 298 (64 PONs)'),
    ('Zone Range', '17 – 20 (4 zones, 16 PONs/zone)'),
    ('OLT Ports', 'C15P11 – C19P10'),
    ('', ''),
    ('Total ONTs', f'{total_onts:,}'),
    ('Total Drop Cables', f'{len(drops):,}'),
    ('Primary Cables', str(len(primary))),
    ('Secondary Cables', str(len(secondary))),
    ('Distribution Cables', str(len(distribution))),
    ('FTS Splitters (1:8)', str(len(fts))),
    ('STS Splitters (1:16)', str(len(sts))),
    ('AGG Domes (FTS enclosures)', str(len(agg_domes))),
    ('DIS Domes (STS enclosures)', str(len(dis_domes))),
    ('', ''),
    ('Cable Specs', ''),
    ('  Primary Feeder', '144F / 48F ADSS SM/G657A1'),
    ('  Secondary Feeder', '48F Mini-ADSS SM/G657A1'),
    ('  Distribution', '24F Mini-ADSS SM/G657A1'),
    ('  Drop', '1F SM/G657A2 — LC/APC to SC/APC'),
    ('', ''),
    ('Splitter Cascade', '1:8 FTS → 1:16 STS = max 128 ONTs/PON'),
    ('Power Budget', 'B+ OLT (28 dB). Cascade loss ≈24.5 dB. Margin ~3.5 dB'),
    ('Max Cable Span', '70 m (feeder/dist ADSS), 50 m (drops)'),
    ('Fusion Splice Loss', '≤0.1 dB target per TIA-568.3-D'),
]

for i, (lbl, val) in enumerate(info_rows, 2):
    info_row(ws_cover, i, lbl, val)

# Colour legend
r_start = len(info_rows) + 4
ws_cover.cell(row=r_start, column=1, value='Zone Colour Key').font = Font(bold=True, size=9)
for i, (zone, col) in enumerate(ZONE_BG.items()):
    r = r_start + 1 + i
    c = ws_cover.cell(row=r, column=1, value=f'Zone {zone}')
    c.fill = PatternFill('solid', fgColor=col)
    c.border = THIN_BORDER
    c.font = Font(size=9, bold=True)
    c.alignment = Alignment(horizontal='center')

# TIA-598-C legend
r_tube = r_start + 7
ws_cover.cell(row=r_tube, column=1, value='Tube Colour Code (TIA-598-C)').font = Font(bold=True, size=9)
for i, (t_no_i, name, hex_col) in enumerate(TUBE_COLORS):
    r = r_tube + 1 + i
    c1 = ws_cover.cell(row=r, column=1, value=f'Tube {i+1}')
    c2 = ws_cover.cell(row=r, column=2, value=name)
    c1.border = THIN_BORDER; c2.border = THIN_BORDER
    c1.fill = tube_fill(hex_col); c2.fill = tube_fill(hex_col)
    c1.font = tube_font(hex_col); c2.font = tube_font(hex_col)
    c1.alignment = Alignment(horizontal='center')


# ════════════════════════════════════════════════════════════════════════════
# SHEET 2: FEEDER CABLES (Primary + Secondary)
# ════════════════════════════════════════════════════════════════════════════
ws_feed = wb.create_sheet('2. Feeder Cables')

feed_headers = [
    'Cable Label', 'Network Part', 'Cable Size', 'From Pole', 'To Pole',
    'Length (m)', 'Zone', 'PON', 'Tube No.', 'Tube Colour', 'Fiber Range',
    'Notes / Splice Points',
]
col_widths_feed = [35, 18, 10, 18, 18, 10, 6, 6, 8, 12, 14, 30]

# Header
for col, (h, w) in enumerate(zip(feed_headers, col_widths_feed), 1):
    ws_feed.column_dimensions[get_column_letter(col)].width = w
    c = ws_feed.cell(row=1, column=col, value=h)
    c.font = HEADER_FONT
    c.fill = PatternFill('solid', fgColor='1F4E79')
    c.alignment = Alignment(horizontal='center', vertical='center', wrap_text=True)
    c.border = THIN_BORDER
ws_feed.row_dimensions[1].height = 30
ws_feed.freeze_panes = 'A2'

row = 2
all_feeders = (
    [('Primary Feeder', c) for c in sorted(primary, key=lambda x: x.get('pon_no') or '')] +
    [('Secondary', c)      for c in sorted(secondary, key=lambda x: x.get('pon_no') or '')]
)

for net_type, cable in all_feeders:
    fiber_count = fibers_for_capacity(cable.get('cblcpty',''))
    zone_no = cable.get('zone_no', '')

    # Auto-assign tubes: sequential within cable (each cable starts at tube 1)
    n_tubes = max(1, fiber_count // 12)
    for tube_idx in range(n_tubes):
        t_no, t_name, t_hex = TUBE_COLORS[tube_idx % 12]
        f_start = tube_idx * 12 + 1
        f_end   = min(f_start + 11, fiber_count)
        fiber_range = f'{f_start}–{f_end}'

        values = [
            cable.get('label',''),
            cable.get('ntwrkptn', net_type),
            cable.get('cblcpty',''),
            cable.get('strtfeat',''),
            cable.get('endfeat',''),
            cable.get('dim2','') if tube_idx == 0 else '',
            zone_no if tube_idx == 0 else '',
            cable.get('pon_no','') if tube_idx == 0 else '',
            t_no,
            t_name,
            fiber_range,
            '',
        ]
        bg = zone_fill(zone_no) if tube_idx == 0 else PatternFill('solid', fgColor='F7FBFF')
        tube_c_fill = tube_fill(t_hex)
        tube_c_font = tube_font(t_hex)

        for col, val in enumerate(values, 1):
            c = ws_feed.cell(row=row, column=col, value=val)
            c.border = THIN_BORDER
            c.font = BODY_FONT
            c.alignment = Alignment(vertical='center', wrap_text=True)
            if col in (9, 10):  # tube columns
                c.fill = tube_c_fill
                c.font = tube_c_font
                c.alignment = Alignment(horizontal='center', vertical='center')
            elif col in (7, 8):
                c.alignment = Alignment(horizontal='center', vertical='center')
                c.fill = bg
            else:
                c.fill = bg
        row += 1

ws_feed.auto_filter.ref = f'A1:{get_column_letter(len(feed_headers))}1'


# ════════════════════════════════════════════════════════════════════════════
# SHEET 3: DISTRIBUTION CABLES
# ════════════════════════════════════════════════════════════════════════════
ws_dist = wb.create_sheet('3. Distribution')

dist_headers = [
    'Cable Label', 'Cable Size', 'From Pole', 'To Pole',
    'Length (m)', 'Zone', 'PON', 'Tube No.', 'Tube Colour', 'Fiber Range',
]
col_widths_dist = [38, 10, 18, 18, 10, 6, 6, 8, 12, 14]

for col, (h, w) in enumerate(zip(dist_headers, col_widths_dist), 1):
    ws_dist.column_dimensions[get_column_letter(col)].width = w
    c = ws_dist.cell(row=1, column=col, value=h)
    c.font = HEADER_FONT
    c.fill = PatternFill('solid', fgColor='375623')
    c.alignment = Alignment(horizontal='center', vertical='center', wrap_text=True)
    c.border = THIN_BORDER
ws_dist.row_dimensions[1].height = 30
ws_dist.freeze_panes = 'A2'

# Sort distribution cables by zone, pon, label
dist_sorted = sorted(distribution, key=lambda x: (x.get('zone_no') or '', x.get('pon_no') or '', x.get('label') or ''))

row = 2
for cable in dist_sorted:
    fiber_count = fibers_for_capacity(cable.get('cblcpty',''))
    zone_no = cable.get('zone_no', '')
    n_tubes = max(1, fiber_count // 12)
    for tube_idx in range(n_tubes):
        t_no, t_name, t_hex = TUBE_COLORS[tube_idx % 12]
        f_start = tube_idx * 12 + 1
        f_end   = min(f_start + 11, fiber_count)
        values = [
            cable.get('label','') if tube_idx == 0 else '',
            cable.get('cblcpty','') if tube_idx == 0 else '',
            cable.get('strtfeat','') if tube_idx == 0 else '',
            cable.get('endfeat','') if tube_idx == 0 else '',
            cable.get('dim2','') if tube_idx == 0 else '',
            zone_no if tube_idx == 0 else '',
            cable.get('pon_no','') if tube_idx == 0 else '',
            t_no, t_name, f'{f_start}–{f_end}',
        ]
        bg = zone_fill(zone_no) if tube_idx == 0 else PatternFill('solid', fgColor='F7FFF5')
        tube_c_fill = tube_fill(t_hex)
        tube_c_font = tube_font(t_hex)

        for col, val in enumerate(values, 1):
            c = ws_dist.cell(row=row, column=col, value=val)
            c.border = THIN_BORDER
            c.font = BODY_FONT
            c.alignment = Alignment(vertical='center', wrap_text=True)
            if col in (8, 9):
                c.fill = tube_c_fill; c.font = tube_c_font
                c.alignment = Alignment(horizontal='center', vertical='center')
            elif col in (6, 7):
                c.alignment = Alignment(horizontal='center', vertical='center')
                c.fill = bg
            else:
                c.fill = bg
        row += 1

ws_dist.auto_filter.ref = f'A1:{get_column_letter(len(dist_headers))}1'


# ════════════════════════════════════════════════════════════════════════════
# SHEET 4: FTS & STS SPLITTERS
# ════════════════════════════════════════════════════════════════════════════
ws_split = wb.create_sheet('4. Splitter Register')

split_headers = [
    'Splitter Label', 'Type', 'Split Ratio', 'Dome / Location',
    'OLT / FTS Port', 'Zone', 'PON', 'Lat', 'Lon',
    'ONT Count (from drops)',
]
col_widths_split = [50, 8, 10, 25, 18, 6, 6, 14, 14, 14]

for col, (h, w) in enumerate(zip(split_headers, col_widths_split), 1):
    ws_split.column_dimensions[get_column_letter(col)].width = w
    c = ws_split.cell(row=1, column=col, value=h)
    c.font = HEADER_FONT
    c.fill = PatternFill('solid', fgColor='7B3F00')
    c.alignment = Alignment(horizontal='center', vertical='center', wrap_text=True)
    c.border = THIN_BORDER
ws_split.row_dimensions[1].height = 30
ws_split.freeze_panes = 'A2'

# Count ONTs per DIS dome (from drop strtfeat)
dome_ont_count = {}
for drop in drops:
    sf = drop.get('strtfeat','')
    if sf:
        dome_ont_count[sf] = dome_ont_count.get(sf, 0) + 1

def parse_fts_label(label):
    """Extract dome pole ref and OLT port from FTS label.
    Example: MOA.FTS.8.AGG.DM.P.G348-OLT.01.C16P01
    """
    try:
        parts = label.split('-')
        dome_part = parts[0]  # MOA.FTS.8.AGG.DM.P.G348
        olt_part  = '-'.join(parts[1:])  # OLT.01.C16P01
        # Extract dome pole: last segment after last '.'P.
        pole = '.'.join(dome_part.split('.')[-2:])  # P.G348
        return dome_part, olt_part
    except:
        return label, ''

def parse_sts_label(label):
    """Extract dome and FTS port from STS label.
    Example: MOA.STS.16.DIS.DM.P.F446.C16P02.L1
    """
    try:
        parts = label.split('.')
        # Find DIS.DM.P.XXXX pattern
        dome_parts = []
        port_parts = []
        in_dome = False
        for i, p in enumerate(parts):
            if p == 'DIS':
                in_dome = True
            if in_dome:
                dome_parts.append(p)
            else:
                continue
            # After 4 segments (DIS.DM.P.XXXX), rest is port
            if len(dome_parts) == 4:
                port_parts = parts[i+1:]
                break
        dome = '.'.join(dome_parts)
        port = '.'.join(port_parts)
        return dome, port
    except:
        return label, ''

row = 2
# FTS first (sorted by zone, pon)
fts_sorted = sorted(fts, key=lambda x: (x.get('zone_no') or '', x.get('pon_no') or '', x.get('label') or ''))
for sp in fts_sorted:
    label = sp.get('label','')
    dome_ref, olt_port = parse_fts_label(label)
    zone_no = sp.get('zone_no','')
    values = [
        label, 'FTS', '1:8',
        dome_ref, olt_port,
        zone_no, sp.get('pon_no',''),
        sp.get('lat',''), sp.get('lon',''),
        '',  # FTS doesn't connect directly to ONTs
    ]
    bg = zone_fill(zone_no)
    for col, val in enumerate(values, 1):
        c = ws_split.cell(row=row, column=col, value=val)
        c.border = THIN_BORDER; c.font = Font(bold=True, size=9)
        c.fill = bg
        c.alignment = Alignment(vertical='center', wrap_text=True)
        if col in (6, 7): c.alignment = Alignment(horizontal='center', vertical='center')
    row += 1

# STS (sorted by zone, pon, label)
sts_sorted = sorted(sts, key=lambda x: (x.get('zone_no') or '', x.get('pon_no') or '', x.get('label') or ''))
for sp in sts_sorted:
    label = sp.get('label','')
    dome_ref, fts_port = parse_sts_label(label)
    zone_no = sp.get('zone_no','')
    # Map DIS dome label to count
    # DIS dome label format: MOA.DIS.DM.P.F446 → strtfeat in drops
    dis_label = 'MOA.' + dome_ref  # reconstruct
    cnt = dome_ont_count.get(dis_label, '')
    values = [
        label, 'STS', '1:16',
        dome_ref, fts_port,
        zone_no, sp.get('pon_no',''),
        sp.get('lat',''), sp.get('lon',''),
        cnt,
    ]
    bg = zone_fill(zone_no)
    for col, val in enumerate(values, 1):
        c = ws_split.cell(row=row, column=col, value=val)
        c.border = THIN_BORDER; c.font = BODY_FONT
        c.fill = bg
        c.alignment = Alignment(vertical='center', wrap_text=True)
        if col in (6, 7, 10): c.alignment = Alignment(horizontal='center', vertical='center')
    row += 1

ws_split.auto_filter.ref = f'A1:{get_column_letter(len(split_headers))}1'


# ════════════════════════════════════════════════════════════════════════════
# SHEET 5: DROP / ONT REGISTER
# ════════════════════════════════════════════════════════════════════════════
ws_drop = wb.create_sheet('5. Drop Register')

drop_headers = [
    'Drop Cable (DR#)', 'From STS Dome', 'To ONT', 'Cable Size',
    'Length (m)', 'Zone', 'PON',
]
col_widths_drop = [20, 30, 28, 10, 10, 6, 6]

for col, (h, w) in enumerate(zip(drop_headers, col_widths_drop), 1):
    ws_drop.column_dimensions[get_column_letter(col)].width = w
    c = ws_drop.cell(row=1, column=col, value=h)
    c.font = HEADER_FONT
    c.fill = PatternFill('solid', fgColor='375623')
    c.alignment = Alignment(horizontal='center', vertical='center', wrap_text=True)
    c.border = THIN_BORDER
ws_drop.row_dimensions[1].height = 25
ws_drop.freeze_panes = 'A2'

drops_sorted = sorted(drops, key=lambda x: (x.get('zone_no') or '', x.get('pon_no') or '', x.get('strtfeat') or '', x.get('label') or ''))

row = 2
for drop in drops_sorted:
    zone_no = drop.get('zone_no','')
    bg = zone_fill(zone_no)
    values = [
        drop.get('label',''),
        drop.get('strtfeat',''),
        drop.get('endfeat',''),
        drop.get('cblcpty',''),
        drop.get('dim2',''),
        zone_no,
        drop.get('pon_no',''),
    ]
    for col, val in enumerate(values, 1):
        c = ws_drop.cell(row=row, column=col, value=val)
        c.border = THIN_BORDER; c.font = BODY_FONT
        c.fill = bg
        c.alignment = Alignment(vertical='center')
        if col in (6, 7): c.alignment = Alignment(horizontal='center', vertical='center')
    row += 1

ws_drop.auto_filter.ref = f'A1:{get_column_letter(len(drop_headers))}1'

# ── Save ──────────────────────────────────────────────────────────────────
out_path = r'C:/Users/jjsch/OneDrive/ON LAPTOP FIBRE/QGIS test/MOA_Splice_Plan_2026.xlsx'
os.makedirs(os.path.dirname(out_path), exist_ok=True)
wb.save(out_path)
print(f"Saved: {out_path}")
print(f"Sheets: {[ws.title for ws in wb.worksheets]}")
print(f"Rows: Feeder={ws_feed.max_row-1}, Dist={ws_dist.max_row-1}, Splitters={ws_split.max_row-1}, Drops={ws_drop.max_row-1}")
