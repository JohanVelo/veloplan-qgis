# MOA Phase 2 — Splice Plan Generators

Auto-generation of the Mohadin Phase 2 FTTH splice plan (Excel workbook + per-closure
A4 PDF field cards) from QGIS layer data, using the **label hierarchy** (OLT-port /
FTS↔STS / dome labels) rather than pole-adjacency geometry.

## Pipeline

| Step | Script | Output |
|---|---|---|
| 1. Extract layer data from QGIS | `splice_export.py` (run inside QGIS) | `splice_data.json` |
| 2. Build the workbook (v8, LAW/ETW format) | `build_splice_v3.py` | `MOA_Splice_Plan_v8.xlsx` |
| 3. Build per-closure field cards | `build_field_cards.py` | `MOA_Splice_FieldCards.pdf` |

Supporting / earlier iterations: `build_splice_v2.py`, `build_splice_excel.py`,
`build_splice_html.py`, `splice_inspect.py`, and `build_route_graph.py` (networkx
route-graph proof-of-concept — superseded by the label-hierarchy method).

## Data files (point-in-time extract, 2026-05-21)
- `splice_data.json` — all splice-relevant layers (primary/secondary/distribution
  cables, FTS/STS splitters, AGG/DIS domes, drops).
- `fts_cable_map.json` — FTS→feeder-cable map from a QGIS vertex analysis.
- `splice_poc_crossconnect.json` — sample cross-connect output for one AGG dome.

## Standards applied
TIA-598-C fibre colour code · TIA-568.3-D (fusion splice ≤0.10 dB workmanship /
≤0.30 dB max, ORL ≥26 dB) · ISO/IEC 14763-3:2024 Ed 3.0 (bi-directional OTDR).

## ⚠️ Notes for another machine
- Paths are currently **hardcoded** (`C:/Temp/...`, `C:/Users/jjsch/OneDrive/ON LAPTOP
  FIBRE/QGIS test/...`). Adjust the `DATA` / `OUT*` constants at the top of each script.
- `splice_export.py` must run **inside a QGIS Python console** (needs `QgsProject`);
  the other scripts run standalone (need `openpyxl`, `reportlab`, `qrcode`, `networkx`).
- Known open item: the FTS splitter points and the Enclosures-Splice dome features are
  offset (median ~427 m) — a position-snapping issue in the source layers. The splice
  *logic* is correct; the field-card GPS needs the layers re-snapped + a re-extract.
