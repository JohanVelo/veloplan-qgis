"""Phase 4 — learn erven parameters from a few user-drawn example parcels (NO deep learning).

fit_params(example_erven) -> {stand_W, stand_depth, orient, merge_m}:
  stand_W   = median short side of the examples' minimum rotated rectangles
  stand_depth = median long side
  orient    = circular median (mod 180) of the long-side azimuths
  merge_m   = kept at default (block-detection knob, not a parcel-shape property)
Feed the result straight into erven.generate_erven(..., params) to reproduce that look everywhere.
"""
import math

import numpy as np

UTM = 32735


def _rect_dims(poly):
    """(short_side_m, long_side_m, long_side_azimuth_deg in [0,180))."""
    mrr = poly.minimum_rotated_rectangle
    cc = list(mrr.exterior.coords)
    sides = []
    for i in range(4):
        dx = cc[i + 1][0] - cc[i][0]; dy = cc[i + 1][1] - cc[i][1]
        sides.append((math.hypot(dx, dy), math.degrees(math.atan2(dy, dx)) % 180.0))
    sides.sort()                              # ascending length
    short = sides[0][0]
    long_len, long_az = sides[-1][0], sides[-1][1]
    return short, long_len, long_az


def _circular_median_deg(azs):
    """Median direction on a 180-deg axis (orientation, not heading)."""
    a = np.radians(np.array(azs) * 2.0)       # double -> full circle
    s, c = np.sin(a).mean(), np.cos(a).mean()
    return (math.degrees(math.atan2(s, c)) / 2.0) % 180.0


def fit_params(example_gdf, defaults=None):
    g = example_gdf.to_crs(UTM)
    g = g[g.geometry.notna() & ~g.geometry.is_empty]
    dims = [_rect_dims(geom) for geom in g.geometry]
    if not dims:
        return dict(defaults or {})
    shorts = [d[0] for d in dims]; longs = [d[1] for d in dims]
    # The examples teach LOT SIZE/SHAPE (width, depth) — these transfer everywhere. ORIENTATION is
    # NOT global: each block follows its own street, so we leave orient per-block (orient_snap) rather
    # than forcing one angle (an area can have several street directions). merge_m is a block-detection
    # knob, kept at default.
    out = {
        "stand_W": float(np.median(shorts)),
        "stand_depth": float(np.median(longs)),
        "orient": None,
        "merge_m": float((defaults or {}).get("merge_m", 12.0)),
        "orient_snap": True,
        "min_area": float((defaults or {}).get("min_area", 60.0)),
        "max_area": float((defaults or {}).get("max_area", 1300.0)),
    }
    return out
