"""Phase 2 gate: example-driven selection. Pick a RED-roof example -> set A; a different (grey/dark)
example -> set B. PASS if both non-empty, runtime < 15 s, and the two sets differ (membership) -> the
result genuinely reflects the example you give it."""
import time
import numpy as np
import cv2
from similar import candidate_masks, descriptor, find_similar

TILE_NPZ = "C:/Temp/erven_work/bld_g/mosaic/mohadin.npz"


def tile_and_transform(size=512):
    z = np.load(TILE_NPZ); mos = z["mos"]; a, b, c, d, e, f = z["transform"]
    y0, x0 = mos.shape[0] // 2 - size // 2, mos.shape[1] // 2 - size // 2
    img = np.ascontiguousarray(mos[y0:y0 + size, x0:x0 + size])
    return img, [a, b, c, d, e, f * 1.0 if False else d * x0 + e * y0 + f], (a * x0 + b * y0 + c)


def main():
    z = np.load(TILE_NPZ); mos = z["mos"]; a, b, c, d, e, f = z["transform"]
    size = 512; y0, x0 = mos.shape[0] // 2 - size // 2, mos.shape[1] // 2 - size // 2
    img = np.ascontiguousarray(mos[y0:y0 + size, x0:x0 + size])
    tr = [a, b, a * x0 + b * y0 + c, d, e, d * x0 + e * y0 + f]

    t0 = time.time()
    cands = candidate_masks(img)                       # generate once, reuse for both examples
    print(f"candidates={len(cands)} ({time.time()-t0:.1f}s)")
    if len(cands) < 4:
        print("GATE: FAIL (too few candidates)"); return

    # descriptor[1] = LAB 'a' (red-green). Highest a = reddest roof; lowest = greenest/grey.
    desc = np.array([descriptor(img, m) for m in cands])
    red_ex = cands[int(np.argmax(desc[:, 1]))]
    grey_ex = cands[int(np.argmin(desc[:, 1]))]

    gA, _ = find_similar(img, tr, [red_ex], {"strictness": 0.4}, candidates=cands)
    gB, _ = find_similar(img, tr, [grey_ex], {"strictness": 0.4}, candidates=cands)
    dt = time.time() - t0
    nA, nB = len(gA), len(gB)
    # membership overlap via centroid sets
    ca = {(round(p.x, 1), round(p.y, 1)) for p in gA.geometry.centroid}
    cb = {(round(p.x, 1), round(p.y, 1)) for p in gB.geometry.centroid}
    jacc = len(ca & cb) / max(len(ca | cb), 1)
    print(f"red-example -> {nA}  | grey-example -> {nB}  | overlap(Jaccard)={jacc:.2f}  ({dt:.1f}s)")

    ok = nA > 0 and nB > 0 and dt < 15 and jacc < 0.8   # sets differ = example-driven
    print("GATE:", "PASS" if ok else "FAIL", "(example changes the result set; <15s)")

    from rasterio.transform import Affine
    A = Affine(*tr); inv = ~A
    ov = img.copy()
    for poly in gA.geometry:
        ring = [(int((inv * (x, y))[0]), int((inv * (x, y))[1])) for x, y in poly.exterior.coords]
        cv2.polylines(ov, [np.array(ring, np.int32)], True, (0, 255, 0), 1)
    cv2.imwrite("C:/Temp/phase2_similar.png", cv2.cvtColor(ov, cv2.COLOR_RGB2BGR))
    print("wrote C:/Temp/phase2_similar.png (red-roof-example matches)")


if __name__ == "__main__":
    main()
