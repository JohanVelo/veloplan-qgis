"""Phase 5 gate (headless): drive the app's functions directly (the Gradio widgets just bind to them).
PASS if: load+detect produce buildings; tuning a slider changes the erven preview (different image +
count) quickly; learn returns params; save/load round-trips; export writes files; build_ui() constructs."""
import time
import numpy as np
import geopandas as gpd
from shapely.geometry import box
import app

CSG = "C:/Users/jjsch/OneDrive/ON LAPTOP FIBRE/QGIS test/Vuma_MOA_Test/Erven.shp"


def main():
    ok = True
    img = app.load_raster()
    print("load_raster:", img.shape)

    det_img, det_txt = app.detect("sam_auto", 0.7, 0.9, 20.0, 600.0, True)
    nb = len(app.S["buildings"]); print("detect:", det_txt)
    ok &= nb > 0

    t0 = time.time()
    _, after14, s14 = app.tune(12.0, 14.0, 27.0, True, 60.0, 1300.0)
    _, after22, s22 = app.tune(12.0, 22.0, 27.0, True, 60.0, 1300.0)
    dt = time.time() - t0
    n14, n22 = len(app.S["erven"]), None
    # recompute counts cleanly
    _, _, s14b = app.tune(12.0, 14.0, 27.0, True, 60.0, 1300.0); c14 = len(app.S["erven"])
    _, _, s22b = app.tune(12.0, 22.0, 27.0, True, 60.0, 1300.0); c22 = len(app.S["erven"])
    diff_img = not np.array_equal(after14, after22)
    print(f"tune W14 -> {c14} erven ({s14b}) | W22 -> {c22} erven ({s22b}) | preview differs={diff_img}")
    ok &= diff_img and c14 != c22

    # learn from examples (sample CSG stands as 'drawn' erven)
    csg = gpd.read_file(CSG).to_crs(4326)
    csg = csg[csg.intersects(box(*app.S["aoi"].to_crs(4326).total_bounds))]
    csg = csg.to_crs(32735); csg = csg[(csg.geometry.area >= 150) & (csg.geometry.area <= 800)].to_crs(4326).iloc[:8]
    fit = app.learn_from_examples(csg)
    print("learn_from_examples ->", {k: round(v, 1) if isinstance(v, float) else v for k, v in fit.items()})
    ok &= fit.get("stand_W", 0) > 0

    cfg = app.save_config(name="phase5test"); back = app.load_config()
    print("config round-trip name:", back.get("name"), "stand_W:", round(back.get("stand_W", 0), 1))
    ok &= back.get("name") == "phase5test"

    paths = app.export()
    print("export:", list(paths.keys()))
    ok &= "erven" in paths

    try:
        ui = app.build_ui(); print("build_ui: OK", type(ui).__name__)
    except Exception as ex:
        print("build_ui FAILED:", ex); ok = False

    print("GATE:", "PASS" if ok else "FAIL", "(detect+tune+learn+save/load+export+UI build all work)")


if __name__ == "__main__":
    main()
