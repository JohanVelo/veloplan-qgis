"""QGIS-dock worker — runs in the venv (heavy deps). Reads a params JSON, produces Buildings,
Erven and Demand-point GeoJSON for the dock's QgsTask to load. Emits 'PROGRESS:<pct>' lines on stdout.

params JSON keys:
  aoi_geojson_path : AOI polygon (any CRS) — required
  buildings_path   : optional prebuilt footprints; if absent, detect via Google Open Buildings
  crisp            : bool (orthogonalise footprints)
  example_erven_path : optional erven the user drew -> fit stand_W/depth from them
  merge_m, stand_W, stand_depth, orient_snap, min_area, max_area : erven sliders
  outdir
"""
import json
import subprocess
import sys
from pathlib import Path

HERE = Path(__file__).resolve().parent
FA = next((c for c in (HERE.parent / "fibre_automation",                          # bundled in plugin
                       HERE.parent / "FiberNetworkAutomation" / "fibre_automation",  # repo-root layout
                       HERE / "fibre_automation")
           if (c / "cadastral_erven.py").exists()),
          HERE.parent / "fibre_automation")
sys.path.insert(0, str(HERE)); sys.path.insert(0, str(FA))


def log(p):
    print(f"PROGRESS:{p}", flush=True)


def main(params_path):
    import geopandas as gpd
    from erven import generate_erven
    from infer_params import fit_params

    cfg = json.loads(Path(params_path).read_text(encoding="utf-8"))
    outdir = cfg.get("outdir", "C:/Temp"); Path(outdir).mkdir(parents=True, exist_ok=True)
    aoi_path = cfg["aoi_geojson_path"]
    bld_out = f"{outdir}/studio_buildings.geojson"
    log(5)

    # 1) buildings
    if cfg.get("buildings_path"):
        bgdf = gpd.read_file(cfg["buildings_path"]).to_crs(4326)
        bgdf.to_file(bld_out, driver="GeoJSON")
    else:
        cmd = [sys.executable, str(FA / "detect_buildings.py"), "--aoi", aoi_path, "--out", bld_out]
        if cfg.get("crisp", True):
            cmd.append("--crisp")
        r = subprocess.run(cmd, capture_output=True, text=True)
        sys.stderr.write(r.stdout + r.stderr)
        if r.returncode != 0 or not Path(bld_out).exists():
            print("WORKER_ERROR: building detection failed", flush=True); return 1
        bgdf = gpd.read_file(bld_out)
    log(45)

    # 2) optional: learn lot size from example erven
    params = {k: cfg[k] for k in ("merge_m", "stand_W", "stand_depth", "orient_snap",
                                   "min_area", "max_area") if k in cfg}
    if cfg.get("example_erven_path") and Path(cfg["example_erven_path"]).exists():
        ex = gpd.read_file(cfg["example_erven_path"])
        fit = fit_params(ex)
        params.update({"stand_W": fit["stand_W"], "stand_depth": fit["stand_depth"]})
        sys.stderr.write(f"learned stand_W={fit['stand_W']:.1f} depth={fit['stand_depth']:.1f}\n")
    log(55)

    # 3) erven (cadastral, no Voronoi)
    aoi = gpd.read_file(aoi_path)
    # GUARDRAIL: AOI must cover the buildings; else derive AOI from the building hull (foolproof
    # against a stale/wrong AOI file — never produce empty output silently).
    b4 = bgdf.to_crs(4326); a4 = aoi.to_crs(4326)
    if not a4.geometry.union_all().intersects(b4.geometry.union_all()):
        sys.stderr.write("AOI does not overlap buildings -> using building hull as AOI\n")
        hull = b4.geometry.union_all().convex_hull.buffer(0.0005)
        aoi = gpd.GeoDataFrame(geometry=[hull], crs=4326)
    erven = generate_erven(bgdf, aoi, params)
    erv_out = f"{outdir}/studio_erven.geojson"
    erven.to_file(erv_out, driver="GeoJSON")
    log(85)

    # 4) one demand point per erf (on its building if present, else stand centroid)
    UTM = 32735
    e_utm = erven.to_crs(UTM); b_utm = bgdf.to_crs(UTM)
    bpts = gpd.GeoDataFrame(geometry=[g.representative_point() for g in b_utm.geometry], crs=UTM)
    rows = []
    sidx = bpts.sindex
    for geom in e_utm.geometry:
        hit = list(sidx.query(geom, predicate="contains"))
        pt = bpts.geometry.iloc[hit[0]] if hit else geom.representative_point()
        rows.append({"geometry": pt, "structure": 1 if hit else 0})
    dp = gpd.GeoDataFrame(rows, crs=UTM).to_crs(4326)
    dp["Type"] = "SDU"; dp["Status"] = "planned"
    dp.to_file(f"{outdir}/studio_demand.geojson", driver="GeoJSON")
    log(100)
    print(f"WORKER_OK buildings={len(bgdf)} erven={len(erven)} demand={len(dp)}", flush=True)
    return 0


if __name__ == "__main__":
    sys.exit(main(sys.argv[1]))
