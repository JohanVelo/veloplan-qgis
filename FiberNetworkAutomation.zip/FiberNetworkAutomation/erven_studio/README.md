# Erven Tuning Studio

A local app for tuning how erven (property plots) are generated from building
footprints — block merge, stand width/depth, street-orientation snap, min/max erf area
— with live before/after preview and GeoJSON export.

## Run
```
pip install -r requirements.txt
python app.py          # opens http://127.0.0.1:7861 in your browser
```
There's also a QGIS dock version (`qgis_dock.py`) for running it inside QGIS.

## Works without AI
- **Tuning + Export + `gob_batch`** (load a prebuilt footprint GeoJSON) run on **any
  laptop** — no GPU, no AI, no internet. These are pure geometry (shapely/geopandas).
- **`sam_auto` "Detect buildings"** is the only AI part — it needs PyTorch + SAM2 + a
  GPU. On a machine without them the studio still runs; Detect just shows a clear
  "needs AI" message. To use it, install torch + SAM2 (see `requirements.txt`).

## Files
`app.py` (UI + callbacks) · `buildings.py` (detection) · `erven.py` (erf generation) ·
`infer_params.py` (learn slider values from examples) · `qgis_dock.py` (in-QGIS dock) ·
`NOTES.md` (build notes) · `test_*.py` / `smoke_test.py` (tests).

No secrets, no network calls.
