"""Phase 1 gate: a slider (min_area) measurably changes the building count, and output is georeferenced.
PASS if count(min_area=20) > count(min_area=120) and both > 0, GeoJSON written."""
import numpy as np
from buildings import propose_buildings

TILE_NPZ = "C:/Temp/erven_work/bld_g/mosaic/mohadin.npz"


def tile_and_transform(size=512):
    z = np.load(TILE_NPZ); mos = z["mos"]; a, b, c, d, e, f = z["transform"]
    y0, x0 = mos.shape[0] // 2 - size // 2, mos.shape[1] // 2 - size // 2
    img = np.ascontiguousarray(mos[y0:y0 + size, x0:x0 + size])
    # offset the affine to the crop origin
    c2 = a * x0 + b * y0 + c; f2 = d * x0 + e * y0 + f
    return img, [a, b, c2, d, e, f2]


def main():
    img, tr = tile_and_transform(512)
    base = dict(iou=0.7, stability=0.9, points_per_side=24, max_area=600.0,
                min_solidity=0.55, roof_colour_on=True)
    g_small = propose_buildings(img, tr, {**base, "min_area": 20.0}, mode="sam_auto")
    g_big = propose_buildings(img, tr, {**base, "min_area": 120.0}, mode="sam_auto")
    n_small, n_big = len(g_small), len(g_big)
    print(f"min_area=20 -> {n_small} buildings | min_area=120 -> {n_big} buildings")
    g_small.to_file("C:/Temp/phase1_buildings.geojson", driver="GeoJSON")

    ok = n_small > n_big and n_big >= 0 and n_small > 0
    print("GATE:", "PASS" if ok else "FAIL", "(slider changes count; georeferenced GeoJSON written)")

    # proof render
    import cv2
    from rasterio.transform import Affine
    a, b, c, d, e, f = tr; A = Affine(a, b, c, d, e, f); inv = ~A
    ov = img.copy()
    for poly in g_small.geometry:
        ring = [(int((inv * (x, y))[0]), int((inv * (x, y))[1])) for x, y in poly.exterior.coords]
        cv2.polylines(ov, [np.array(ring, np.int32)], True, (0, 255, 0), 1)
    cv2.imwrite("C:/Temp/phase1_buildings.png", cv2.cvtColor(ov, cv2.COLOR_RGB2BGR))
    print("wrote C:/Temp/phase1_buildings.png")


if __name__ == "__main__":
    main()
