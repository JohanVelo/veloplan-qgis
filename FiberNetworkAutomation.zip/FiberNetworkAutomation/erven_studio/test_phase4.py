"""Phase 4 DECISIVE gate: learn erven from examples. Simulate JJ drawing example erven by sampling
real CSG stands; fit params (lot SIZE); regenerate (orientation per-block from streets); verify the
generated stands reproduce the examples' WIDTH (+/-15%) AND align to the LOCAL survey orientation
(nearest CSG stand, axis mod 90, median error <= 15 deg)."""
import geopandas as gpd
import numpy as np
from shapely.geometry import box

from infer_params import fit_params, _rect_dims
from erven import generate_erven

CSG = "C:/Users/jjsch/OneDrive/ON LAPTOP FIBRE/QGIS test/Vuma_MOA_Test/Erven.shp"
BLD = "C:/Temp/detected_buildings.geojson"
BBOX = (27.046, -26.7235, 27.0515, -26.719)
UTM = 32735


def axis90(geom):
    return _rect_dims(geom)[2] % 90.0


def ang90(a, b):
    d = abs(a - b) % 90.0
    return min(d, 90.0 - d)


def main():
    win = box(*BBOX)
    csg = gpd.read_file(CSG).to_crs(4326)
    csg = csg[csg.intersects(win)].to_crs(UTM); csg["a"] = csg.geometry.area
    stands = csg[(csg.a >= 150) & (csg.a <= 800)].reset_index(drop=True)
    print(f"CSG stands in window: {len(stands)}")
    examples = stands.to_crs(4326).iloc[:8]                       # "JJ draws ~8 erven"
    ex_W = float(np.median([_rect_dims(g)[0] for g in examples.to_crs(UTM).geometry]))
    print(f"examples: median width {ex_W:.1f} m")

    fit = fit_params(examples)
    print(f"fit -> stand_W {fit['stand_W']:.1f}, depth {fit['stand_depth']:.1f}, orient(per-block)={fit['orient']}")

    b = gpd.read_file(BLD).to_crs(4326); b = b[b.intersects(win)].copy()
    aoi = gpd.GeoDataFrame(geometry=[win], crs=4326)
    gen = generate_erven(b, aoi, fit).to_crs(UTM)
    gen_W = float(np.median([_rect_dims(g)[0] for g in gen.geometry]))
    print(f"generated: {len(gen)} erven, median width {gen_W:.1f} m")

    # local orientation: nearest CSG stand per generated stand, compare axis mod 90
    gen_c = gen.copy(); gen_c["geometry"] = gen.geometry.centroid
    near = gpd.sjoin_nearest(gen_c, stands[["geometry"]].assign(csg_ax=[axis90(g) for g in stands.geometry]),
                             how="left")
    gen_ax = np.array([axis90(g) for g in gen.geometry])
    near = near.reset_index(drop=True)
    errs = np.array([ang90(gen_ax[i], near["csg_ax"].iloc[i]) for i in range(len(gen))])
    med_err = float(np.median(errs)); pct = float((errs <= 20).mean() * 100)
    print(f"local orientation error: median {med_err:.1f} deg | within 20deg: {pct:.0f}%")

    dW = abs(gen_W - ex_W) / ex_W
    ok = len(gen) > 0 and dW <= 0.15 and med_err <= 15.0
    print(f"width error {dW*100:.1f}%")
    print("GATE:", "PASS" if ok else "FAIL",
          "(examples set lot width +/-15%; generated aligns to local survey, median axis err <=15deg)")


if __name__ == "__main__":
    main()
