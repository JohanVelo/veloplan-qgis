# HeroTel: PON Clustering Algorithm (TSD standard)

from qgis.core import (
    QgsProcessingParameterVectorLayer,
    QgsProcessingParameterNumber,
    QgsProcessing,
)

from .ht_base_algorithm import HeroTelBaseAlgorithm


class HT02PonClusteringAlgorithm(HeroTelBaseAlgorithm):
    """
    HT 2 — PON Clustering (SKATER regionalization) — TSD standard.

    Assigns ONT points to spatially contiguous PON clusters using the SKATER
    algorithm (spopt 0.7.0). Targets 60–102 ONTs per PON port.

    PENDING: HeroTel TSD specification for PON port count and capacity limits.
    This is a stub algorithm. Full implementation will:
      1. Load ONT v1 points and project to UTM (EPSG:32736 for Lulekani)
      2. Build KNN spatial weights graph (k=6)
      3. Run SKATER regionalization (n_clusters=ceil(total/102), floor=60)
      4. Post-process: split any PON > 102 ONTs via MST bisection
      5. Write pon_no (1-based) and zone_no to ONT layer attributes
      6. Generate PON boundary polygons via convex hull / alpha shape

    PON numbering: starts at 1 (adjust base when JJ confirms OLT port allocation).
    Zone formula: zone_no = (pon_no - 1) // 16 + 1  → 5 zones for 69 PONs (Lulekani).

    Run AFTER: HT 1 (ONT Placement)
    Run BEFORE: HT 3 (Splitter Placement)
    Requires: ONT v1, spopt>=0.7.0, libpysal>=4.14.1, scipy>=1.14.0
    Produces: pon_no + zone_no populated on ONT v1; PON v1 boundary polygons
    """

    INPUT = 'INPUT'
    N_CLUSTERS = 'N_CLUSTERS'
    FLOOR = 'FLOOR'

    def name(self):
        return 'ht_02_pon_clustering'

    def displayName(self):
        return 'HT 2 — PON Clustering (SKATER)'

    def shortHelpString(self):
        return """
        <p><b>HT 2 — PON Clustering (SKATER)</b></p>

        <p>Assigns ONTs to spatially contiguous PON clusters using SKATER regionalization.</p>

        <h4>Parameters</h4>
        <ul>
          <li><b>ONT layer</b> — ONT v1 point layer (must have pon_no and zone_no fields)</li>
          <li><b>n_clusters</b> — Number of PONs. Default: ceil(total_onts / 102)</li>
          <li><b>floor</b> — Minimum ONTs per PON. Use 60 for formal townships, 80 for informal.</li>
        </ul>

        <h4>Algorithm</h4>
        <p>SKATER (Spatial C(K)luster Analysis by Tree Edge Removal) from spopt 0.7.0.
        Produces spatially contiguous clusters — adjacent ONTs are grouped together,
        unlike K-Means which ignores spatial adjacency.</p>

        <h4>Post-processing</h4>
        <p>Any PON with > 102 ONTs is split via MST bisection (longest edge removal)
        until all clusters satisfy the capacity constraint.</p>

        <p><b>⚠️ PENDING:</b> HeroTel TSD specification from JJ. Full implementation awaiting PDF.</p>
        """

    def initAlgorithm(self, config=None):
        from qgis.core import QgsProject
        proj = QgsProject.instance()
        ont_layers = proj.mapLayersByName('ONT v1') or proj.mapLayersByName('Demand Points')

        self.addParameter(
            QgsProcessingParameterVectorLayer(
                self.INPUT,
                'ONT v1 point layer',
                [QgsProcessing.TypeVectorPoint],
                defaultValue=ont_layers[0] if ont_layers else None,
            )
        )
        self.addParameter(
            QgsProcessingParameterNumber(
                self.N_CLUSTERS,
                'Number of PON clusters (0 = auto-calculate)',
                type=QgsProcessingParameterNumber.Integer,
                minValue=0,
                defaultValue=0,
            )
        )
        self.addParameter(
            QgsProcessingParameterNumber(
                self.FLOOR,
                'Minimum ONTs per PON (60=formal, 80=informal)',
                type=QgsProcessingParameterNumber.Integer,
                minValue=10,
                defaultValue=60,
            )
        )

    def processAlgorithm(self, parameters, context, feedback):
        """Algorithm entry point — STUB pending TSD specification"""
        raise NotImplementedError(
            '\n'.join([
                'HT 2 — PON Clustering is not yet implemented.',
                '',
                'PENDING: HeroTel TSD (Telecommunications System Design) specification from JJ.',
                '',
                'Confirmed parameters for Lulekani (Ba-Phalaborwa):',
                '  • n_clusters = 69  (ceil(7024/102))',
                '  • floor = 60       (formal township grid)',
                '  • KNN k = 6        (uniform adjacency)',
                '  • CRS = EPSG:32736 (UTM Zone 36S — lon 31.06°E)',
                '  • PON 1–69 pending JJ OLT port allocation confirmation',
                '',
                'Full implementation will use:',
                '  from libpysal.weights import KNN',
                '  from spopt.region import Skater',
                '  model = Skater(dp_gdf, w, attrs_name=["id"],',
                '                 n_clusters=69, floor=60, islands="increase")',
                '',
                'Requires: pip install spopt==0.7.0 (after scipy>=1.14.0)',
                'Contact: ai@velocityfibre.co.za',
            ])
        )

    def postProcessAlgorithm(self, context, feedback):
        return {}
