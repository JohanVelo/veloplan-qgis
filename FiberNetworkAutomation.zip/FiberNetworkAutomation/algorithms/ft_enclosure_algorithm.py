# Fibertime: Label Enclosure Algorithm (MOA standard)

from datetime import datetime

from qgis.core import (
    QgsProcessingParameterVectorLayer,
    QgsProcessingParameterEnum,
    QgsProcessing,
    QgsProject,
    QgsSpatialIndex,
    QgsWkbTypes,
)

from .base_algorithm import BaseFiberAlgorithm


class FTEnclosureAlgorithm(BaseFiberAlgorithm):
    """
    Populate Fibertime Enclosure v1 — label_1 from strtfeat + static fields (MOA standard).

    Generates label_1 from the strtfeat (pole reference) on each feature:
      DIS type: MOA.DIS.DM.P.{pole}   (Distribution dome — at STS splitter poles)
      AGG type: MOA.AGG.DM.P.{pole}   (Aggregation dome — at FTS splitter poles)

    Strips the 'MOA.P.' prefix from strtfeat automatically.

    Also populates all standard static fields:
      cmpownr, mun, subplace, mainplce, stackref, datecrtd, crtdby.
    """

    ENC_TYPE = 'ENC_TYPE'
    ENC_TYPES = ['DIS  (Distribution — STS splitter locations)', 'AGG  (Aggregation — FTS splitter locations)']

    def name(self):
        return 'ft_label_enclosure'

    def displayName(self):
        return 'FT 4. Label Enclosure'

    def group(self):
        return 'Fibertime Network Labeling'

    def groupId(self):
        return 'fibertimenetworklabeling'

    def shortHelpString(self):
        return """
        Populate Fibertime Enclosure v1 — label_1 from strtfeat pole reference.

        Label format:
          DIS: MOA.DIS.DM.P.{pole}   (Distribution dome — STS splitter locations)
          AGG: MOA.AGG.DM.P.{pole}   (Aggregation dome — FTS splitter locations)

        The pole ID is taken from the strtfeat field (MOA.P. prefix stripped automatically).

        Run this separately for each enclosure type (select the correct layer first).

        Fields updated (label_1):
          MOA.DIS.DM.P.{pole}  or  MOA.AGG.DM.P.{pole}

        Static fields updated:
          cmpownr, mun, subplace, mainplce, stackref, datecrtd, crtdby

        ⚠️ Requires strtfeat to be populated on the enclosure layer.
        Run FT 5 (PON Zones) and FT 6 (Apply PON Order) first so strtfeat is set.
        """

    def initAlgorithm(self, config=None):
        proj = QgsProject.instance()
        enc_layers = proj.mapLayersByName('Enclosure v1') or proj.mapLayersByName('Enclosures Connectorised v1')

        self.addParameter(
            QgsProcessingParameterVectorLayer(
                self.INPUT,
                'Enclosure layer (Enclosure v1 or Enclosures Connectorised v1)',
                [QgsProcessing.TypeVectorPoint],
                defaultValue=enc_layers[0] if enc_layers else None,
            )
        )
        self.addParameter(
            QgsProcessingParameterEnum(
                self.ENC_TYPE,
                'Enclosure type',
                options=self.ENC_TYPES,
                defaultValue=0,
            )
        )

    def processAlgorithm(self, parameters, context, feedback):
        layer    = self.parameterAsVectorLayer(parameters, self.INPUT, context)
        enc_type = self.parameterAsEnum(parameters, self.ENC_TYPE, context)
        prefix   = 'DIS' if enc_type == 0 else 'AGG'

        feedback.pushInfo(f"Labeling {layer.name()} as MOA.{prefix}.DM.P.{{pole}} — {layer.featureCount()} features...")

        flds      = layer.fields()
        i_label1  = flds.indexOf('label_1')
        i_strt    = flds.indexOf('strtfeat')

        if i_label1 < 0:
            raise Exception(f"Field 'label_1' not found in {layer.name()}.")
        if i_strt < 0:
            raise Exception(f"Field 'strtfeat' not found in {layer.name()}. "
                            "Run FT 5 and FT 6 first to populate strtfeat.")

        SNAP_DEG = 8.0 / 111320.0
        fts_lyr = None
        fts_index = None
        _fts_list = QgsProject.instance().mapLayersByName('Splitter FTS v1')
        if _fts_list:
            fts_lyr = _fts_list[0]
            fts_index = QgsSpatialIndex(fts_lyr.getFeatures())

        dist_endpoints = []
        _dist_list = QgsProject.instance().mapLayersByName('Distribution Cable v1')
        if _dist_list:
            dist_lyr = _dist_list[0]
            i_cap = dist_lyr.fields().indexOf('cblcpty1')
            for _feat in dist_lyr.getFeatures():
                _geom = _feat.geometry()
                if not _geom or _geom.isEmpty():
                    continue
                if QgsWkbTypes.isMultiType(_geom.wkbType()):
                    parts = _geom.asMultiPolyline()
                    if not parts:
                        continue
                    s_pt, e_pt = parts[0][0], parts[-1][-1]
                else:
                    pts = _geom.asPolyline()
                    if len(pts) < 2:
                        continue
                    s_pt, e_pt = pts[0], pts[-1]
                dist_endpoints.append((s_pt, e_pt, str(_feat[i_cap]) if i_cap >= 0 else ''))

        i_spec1 = flds.indexOf('spec_1')
        i_cblcpty = flds.indexOf('cblcpty1')

        attr_map = {}
        no_strtfeat = 0
        for feat in layer.getFeatures():
            if feedback.isCanceled():
                return {}
            strt = str(feat['strtfeat']).strip()
            if not strt or strt in ('NULL', 'None', ''):
                no_strtfeat += 1
                continue
            pole = strt.replace('MOA.P.', '')
            row = {i_label1: f"MOA.{prefix}.DM.P.{pole}"}
            if i_spec1 >= 0 or i_cblcpty >= 0:
                spec_1_val = cblcpty1_val = None
                enc_geom = feat.geometry()
                if enc_geom and not enc_geom.isEmpty():
                    enc_pt = enc_geom.asPoint()
                    if fts_index and fts_lyr:
                        near_ids = fts_index.nearestNeighbor(enc_pt, 1)
                        if near_ids:
                            fts_feat = fts_lyr.getFeature(near_ids[0])
                            if fts_feat.hasGeometry() and enc_geom.distance(fts_feat.geometry()) <= SNAP_DEG:
                                spec_1_val, cblcpty1_val = 'CMJ', '144F'
                    if spec_1_val is None and dist_endpoints:
                        min_d = float('inf')
                        best_cap = None
                        for s_pt, e_pt, cap in dist_endpoints:
                            d = min(enc_pt.distance(s_pt), enc_pt.distance(e_pt))
                            if d < min_d:
                                min_d, best_cap = d, cap
                        if min_d <= SNAP_DEG and best_cap:
                            spec_1_val, cblcpty1_val = (
                                ('ODCFD1', '48F') if best_cap.startswith('48') else ('ODCFD0', '24F')
                            )
                    if i_spec1 >= 0 and spec_1_val:
                        row[i_spec1] = spec_1_val
                    if i_cblcpty >= 0 and cblcpty1_val:
                        row[i_cblcpty] = cblcpty1_val
            attr_map[feat.id()] = row

        layer.dataProvider().changeAttributeValues(attr_map)
        layer.dataProvider().reloadData()

        if no_strtfeat:
            feedback.pushWarning(f"{no_strtfeat} features skipped — strtfeat is empty.")

        feedback.pushInfo(f"[OK] label_1 written: {len(attr_map)} features.")

        feedback.pushInfo("Updating static fields...")
        self.bulk_set_static_fields(layer, {
            'cmpownr':  'VelocityFibre',
            'mun':      'JB Marks LM',
            'subplace': '676007',
            'mainplce': '676007',
            'stackref': 'MOA',
            'datecrtd': datetime.now().strftime('%Y%m%d'),
            'crtdby':   'Johan Scholtz',
        }, feedback)

        layer.triggerRepaint()
        feedback.pushInfo("[OK] Enclosure fields populated.")
        return {self.INPUT: layer.id()}

    def createInstance(self):
        return FTEnclosureAlgorithm()
