# Label Demand Points Algorithm

from qgis.core import (
    QgsProcessingParameterVectorLayer,
    QgsProcessing
)

from .base_algorithm import BaseFiberAlgorithm


class LabelDemandPointsAlgorithm(BaseFiberAlgorithm):
    """Algorithm to label Demand Points layers"""

    def name(self):
        return 'labeldemandpoints'

    def displayName(self):
        return '6. Label Demand Points'

    def shortHelpString(self):
        return """
        Auto-populate Demand Point fields.

        Fields updated:
        - Geo Latitu: latitude
        - Geo longit: longitude
        - Network Ty: "GPON"
        - Build Meth: "Aerial"
        - Premises T: "Residential"
        - AG Name: PRAK-Z1-AG01 (spatial lookup)
        - Block Name: PRAK-Z1-B001 (spatial lookup)
        - Zone: 1
        - Connectabl: "Yes"

        ⚠️ Run Aggregation Polygons and Blocks first!
        """

    def initAlgorithm(self, config=None):
        # Input layer
        self.addParameter(
            QgsProcessingParameterVectorLayer(
                self.INPUT,
                'Demand Points Layer',
                [QgsProcessing.TypeVectorPoint]
            )
        )

        # Project selection
        self.add_common_parameters()

    def processAlgorithm(self, parameters, context, feedback):
        # Get parameters
        layer = self.parameterAsVectorLayer(parameters, self.INPUT, context)
        project = self.get_project_code(parameters, context)

        feedback.pushInfo(f"Labeling Demand Points for {project}...")

        # Update Geo Latitu
        feedback.pushInfo("Updating Geo Latitu...")
        self.calculate_field(layer, "Geo Latitu", "y($geometry)", feedback)

        # Update Geo longit
        feedback.pushInfo("Updating Geo longit...")
        self.calculate_field(layer, "Geo Longit", "x($geometry)", feedback)

        # Update Network Ty
        feedback.pushInfo("Updating Network Ty...")
        self.calculate_field(layer, "Network Ty", "'GPON'", feedback)

        # Update Build Meth
        feedback.pushInfo("Updating Build Meth...")
        self.calculate_field(layer, "Build Meth", "'Aerial'", feedback)

        # Update Premises T
        feedback.pushInfo("Updating Premises T...")
        self.calculate_field(layer, "Premises T", "'Residential'", feedback)

        # Update AG Name (spatial)
        feedback.pushInfo("Updating AG Name (spatial lookup)...")
        formula = "array_first(overlay_contains('Aggregation Polygon', \"Label\"))"
        self.calculate_field(layer, "AG Name", formula, feedback)

        # Update Block Name (spatial)
        feedback.pushInfo("Updating Block Name (spatial lookup)...")
        formula = "array_first(overlay_contains('Block', \"Label.\"))"
        self.calculate_field(layer, "Block Name", formula, feedback)

        # Update Zone
        feedback.pushInfo("Updating Zone...")
        self.calculate_field(layer, "Zone", "1", feedback)

        # Update Connectabl
        feedback.pushInfo("Updating Connectabl...")
        self.calculate_field(layer, "Connectabl", "'Yes'", feedback)

        layer.triggerRepaint()
        feedback.pushInfo("✅ Demand Points labeled successfully!")

        return {self.INPUT: layer.id()}
