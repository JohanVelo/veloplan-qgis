# claude:approved-destructive
"""
FT Spur Enclosure Classifier
Detects distribution cables that are spur routes and ensures the enclosure at
each spur branch-off point is M16 Microloop (48F), not ODCFD0 (24F).

Rule (JJ-confirmed 2026-05-05):
  - Main route cable  → endpoint within SNAP_DEG of any FTS Splitter v1
  - Spur cable        → no FTS endpoint
  - Branch-off point  → the spur endpoint closest to a main cable geometry
  - M16 Microloop     → enclosure within ENC_DEG of a branch-off point
  - ODCFD0            → enclosure NOT near any spur branch-off
"""
from qgis.core import (
    QgsProcessingAlgorithm, QgsProcessingParameterBoolean,
    QgsProcessingOutputNumber,
    QgsProject, QgsGeometry, QgsPointXY, QgsSpatialIndex, QgsWkbTypes,
)
from qgis.PyQt.QtCore import QCoreApplication

SNAP_DEG   = 25.0 / 111320.0   # 25 m — FTS proximity → main route (cable endpoint to FTS pole can be 18-22m apart)
BRANCH_DEG = 10.0 / 111320.0   # 10 m — spur endpoint near main cable → branch-off
ENC_DEG    = 15.0 / 111320.0   # 15 m — enclosure search radius around branch-off


class FtSpurEnclosureAlgorithm(QgsProcessingAlgorithm):

    APPLY_CHANGES    = 'APPLY_CHANGES'
    OUTPUT_CONVERTED = 'OUTPUT_CONVERTED'
    OUTPUT_REVERTED  = 'OUTPUT_REVERTED'

    def initAlgorithm(self, config=None):
        self.addParameter(QgsProcessingParameterBoolean(
            self.APPLY_CHANGES,
            'Apply changes (uncheck to preview only)',
            defaultValue=True,
        ))
        self.addOutput(QgsProcessingOutputNumber(self.OUTPUT_CONVERTED, 'ODCFD0 → M16 converted'))
        self.addOutput(QgsProcessingOutputNumber(self.OUTPUT_REVERTED,  'M16 → ODCFD0 reverted'))

    def processAlgorithm(self, parameters, context, feedback):
        apply = self.parameterAsBoolean(parameters, self.APPLY_CHANGES, context)

        dist_lyr = QgsProject.instance().mapLayersByName('Distribution Cable v1')[0]
        fts_lyr  = QgsProject.instance().mapLayersByName('FTS Splitters v1')[0]
        enc_lyr  = QgsProject.instance().mapLayersByName('Enclosures Connectorised v1')[0]

        # 1. Index FTS splitter positions
        fts_idx = QgsSpatialIndex()
        fts_pts = {}
        for f in fts_lyr.getFeatures():
            if f.hasGeometry():
                fts_idx.addFeature(f)
                fts_pts[f.id()] = f.geometry().asPoint()

        # 2. Classify distribution cables as main / spur via FTS proximity
        def cable_endpoints(feat):
            geom = feat.geometry()
            if geom.isEmpty():
                return None, None
            if QgsWkbTypes.isMultiType(geom.wkbType()):
                parts = geom.asMultiPolyline()
                if not parts:
                    return None, None
                return QgsPointXY(parts[0][0]), QgsPointXY(parts[-1][-1])
            pts = geom.asPolyline()
            if not pts:
                return None, None
            return QgsPointXY(pts[0]), QgsPointXY(pts[-1])

        def near_fts(pt):
            if pt is None:
                return False
            near = fts_idx.nearestNeighbor(pt, 1)
            if not near:
                return False
            return QgsGeometry.fromPointXY(pt).distance(
                QgsGeometry.fromPointXY(fts_pts[near[0]])) <= SNAP_DEG

        main_cables, spur_cables = [], []
        for feat in dist_lyr.getFeatures():
            if not feat.hasGeometry() or feat.geometry().isEmpty():
                continue
            s, e = cable_endpoints(feat)
            if near_fts(s) or near_fts(e):
                main_cables.append(feat)
            else:
                spur_cables.append(feat)

        feedback.pushInfo(f'Main: {len(main_cables)}  Spur: {len(spur_cables)}')

        # 3. Spatial index of main cable geometries (for branch-off detection)
        main_idx = QgsSpatialIndex()
        main_geoms = {}
        for f in main_cables:
            main_idx.addFeature(f)
            main_geoms[f.id()] = f.geometry()

        # 4. Find branch-off point for each spur cable
        #    = the spur endpoint closest to any main cable line
        branch_points = []
        for feat in spur_cables:
            s, e = cable_endpoints(feat)
            best_pt, best_d = None, float('inf')
            for pt in [p for p in [s, e] if p is not None]:
                pt_geom = QgsGeometry.fromPointXY(pt)
                for mid in main_idx.nearestNeighbor(pt, 3):
                    d = pt_geom.distance(main_geoms[mid])
                    if d < best_d:
                        best_d, best_pt = d, pt
            if best_pt and best_d <= BRANCH_DEG:
                branch_points.append(best_pt)

        feedback.pushInfo(f'Branch-off points: {len(branch_points)}')

        # 5. Index enclosures
        enc_idx = QgsSpatialIndex()
        enc_feats = {}
        for f in enc_lyr.getFeatures():
            if f.hasGeometry() and not f.geometry().isEmpty():
                enc_idx.addFeature(f)
                enc_feats[f.id()] = f

        fields = enc_lyr.fields()
        spec_idx    = fields.indexOf('spec_1')
        cblcpty_idx = fields.indexOf('cblcpty1')
        subtyp1_idx = fields.indexOf('subtyp_1')

        # 6. Which enclosures are near a branch-off point?
        needs_m16 = set()
        for bp in branch_points:
            bp_geom = QgsGeometry.fromPointXY(bp)
            for eid in enc_idx.nearestNeighbor(bp, 3):
                if bp_geom.distance(enc_feats[eid].geometry()) <= ENC_DEG:
                    needs_m16.add(eid)

        # 7. Determine what needs changing
        to_m16, to_odcfd0 = {}, {}
        for fid, feat in enc_feats.items():
            spec = str(feat['spec_1']) if feat['spec_1'] else ''
            label = str(feat['label_1']) if feat['label_1'] else f'fid={fid}'
            if fid in needs_m16 and spec != 'M16 Microloop':
                to_m16[fid] = {spec_idx: 'M16 Microloop', cblcpty_idx: '48F', subtyp1_idx: 'Spur Route'}
                feedback.pushInfo(f'  → M16:    {label}  (was {spec or "NULL"})')
            elif fid not in needs_m16 and spec == 'M16 Microloop':
                to_odcfd0[fid] = {spec_idx: 'ODCFD0', cblcpty_idx: '24F', subtyp1_idx: 'Distribution'}
                feedback.pushInfo(f'  → ODCFD0: {label}  (M16 but no spur branch-off nearby)')

        feedback.pushInfo(f'Summary → M16: {len(to_m16)}  → ODCFD0: {len(to_odcfd0)}')

        # 8. Apply
        if apply and (to_m16 or to_odcfd0):
            all_updates = {**to_m16, **to_odcfd0}
            enc_lyr.startEditing()
            for fid, attrs in all_updates.items():
                for idx, val in attrs.items():
                    enc_lyr.changeAttributeValue(fid, idx, val)
            ok = enc_lyr.commitChanges()
            enc_lyr.reload()
            from qgis.utils import iface
            iface.mapCanvas().refreshAllLayers()
            feedback.pushInfo(f'Committed: {ok}')
        elif not apply:
            feedback.pushInfo('Preview only — no changes written.')

        return {self.OUTPUT_CONVERTED: len(to_m16), self.OUTPUT_REVERTED: len(to_odcfd0)}

    def name(self):            return 'ft_spur_enclosure_classifier'
    def displayName(self):     return 'FT 4b — Spur Enclosure Classifier (M16 / ODCFD0)'
    def group(self):           return 'Fibertime Network Labeling'
    def groupId(self):         return 'fibertime'
    def shortHelpString(self): return (
        'Classifies Enclosures Connectorised v1 as M16 Microloop (spur branch-off) '
        'or ODCFD0 (main distribution route) based on spur cable geometry.\n\n'
        'Uncheck "Apply changes" to run in preview/report mode only.'
    )
    def createInstance(self):  return FtSpurEnclosureAlgorithm()
    def tr(self, s):           return QCoreApplication.translate('FtSpurEnclosureAlgorithm', s)
