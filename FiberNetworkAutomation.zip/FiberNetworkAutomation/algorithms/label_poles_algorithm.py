# Label Poles Algorithm

from qgis.core import (
    QgsProcessingParameterVectorLayer,
    QgsProcessing
)

from .base_algorithm import BaseFiberAlgorithm


class LabelPolesAlgorithm(BaseFiberAlgorithm):
    """Algorithm to label Pole layers"""

    def name(self):
        return 'labelpoles'

    def displayName(self):
        return '3. Label Poles'

    def shortHelpString(self):
        return """
        Auto-populate Pole fields.

        Fields updated:
        - id: 1, 2, 3...
        - Name: PRAK-Z01-P0001, P0002...
        - X: longitude
        - Y: latitude
        - AG: PRAK-Z1-AG01 (spatial lookup)
        - Block: PRAK-Z1-B001 (spatial lookup)
        - fid: 1, 2, 3...

        ⚠️ Run Aggregation Polygons and Blocks first!
        """

    def initAlgorithm(self, config=None):
        # Input layer
        self.addParameter(
            QgsProcessingParameterVectorLayer(
                self.INPUT,
                'Poles Layer',
                [QgsProcessing.TypeVectorPoint]
            )
        )

        # Project selection
        self.add_common_parameters()

    def processAlgorithm(self, parameters, context, feedback):
        # Get parameters
        layer = self.parameterAsVectorLayer(parameters, self.INPUT, context)
        project = self.get_project_code(parameters, context)

        feedback.pushInfo(f"Labeling Poles for {project}...")

        # Update id
        feedback.pushInfo("Updating id...")
        self.calculate_field(layer, "id", "@row_number", feedback)

        # Update Name
        feedback.pushInfo("Updating Name...")
        formula = f"'{project}-Z01-P' || lpad(to_string(\"id\"), 4, '0')"
        self.calculate_field(layer, "Name", formula, feedback)

        # Update X
        feedback.pushInfo("Updating X coordinate...")
        self.calculate_field(layer, "X", "x($geometry)", feedback)

        # Update Y
        feedback.pushInfo("Updating Y coordinate...")
        self.calculate_field(layer, "Y", "y($geometry)", feedback)

        # Update AG (spatial)
        feedback.pushInfo("Updating AG (spatial lookup)...")
        formula = "array_first(overlay_contains('Aggregation Polygon', \"Label\"))"
        self.calculate_field(layer, "AG", formula, feedback)

        # Update Block (spatial)
        feedback.pushInfo("Updating Block (spatial lookup)...")
        formula = "array_first(overlay_contains('Block', \"Label.\"))"
        self.calculate_field(layer, "Block", formula, feedback)

        # Update fid
        feedback.pushInfo("Updating fid...")
        self.calculate_field(layer, "fid", "@row_number", feedback)

        layer.triggerRepaint()
        feedback.pushInfo("✅ Poles labeled successfully!")

        return {self.INPUT: layer.id()}
