"""Dock widget for FTTH Plan Tool."""

import os
import sip
import time
import traceback
import colorsys
import random
import heapq

from qgis.PyQt import QtWidgets, uic
from qgis.PyQt.QtCore import pyqtSignal, QMetaType, QVariant
from qgis.PyQt.QtGui import QColor, QFont
from qgis.PyQt.QtWidgets import QApplication
from qgis.core import (
    QgsVectorLayer, QgsWkbTypes, QgsProject, QgsGeometry, QgsPointXY,
    QgsFeature, QgsField, QgsUnitTypes, QgsSpatialIndex, QgsRectangle,
    QgsFillSymbol, QgsMarkerSymbol, QgsSingleSymbolRenderer,
    QgsCategorizedSymbolRenderer, QgsRendererCategory, QgsLineSymbol,
    QgsPalLayerSettings, QgsTextFormat, QgsTextBufferSettings,
    QgsVectorLayerSimpleLabeling, QgsCoordinateTransform,
    QgsExpression, QgsExpressionContextUtils,
)
from qgis.gui import QgsMapLayerComboBox, QgsMapToolEmitPoint

from .layer_utils import (
    get_layer_features,
    get_point_coordinates,
    get_linestring_coordinates,
    create_memory_layer,
    add_fields_to_layer,
    add_line_feature,
    count_features_by_geometry_type,
    get_layer_extent,
    get_all_vector_layers
)
from .core import NetworkGraph, _snap_coord
from .erf_grouping import (
    assign_batches_to_layer,
    get_batch_statistics,
    identify_erf_layer,
    assign_clusters_to_layer,
    assign_clusters_dbscan,
    assign_clusters_kmeans,
    balance_pon_loads,
    minimize_cable_length_clustering,
    find_optimal_splitter_locations,
    assign_tight_groups_of_8,
    cluster_tight_groups_of_8,
    group_zones_from_groups,
    cluster_continuous_groups,
    SKLEARN_AVAILABLE,
    NUMPY_AVAILABLE
)

# Cable profile functions (embedded until cable_profiles.py can be created)
import math
import bisect

CABLE_PROFILES = [2, 4, 6, 12, 24, 36, 48, 72, 96, 144, 288]
PROFILE_TYPE_DEFAULT = 'default'
PROFILE_TYPE_POPC = 'popc'
PROFILE_TYPE_OPERATOR = 'operator'

def get_cable_profile(demand, profile_type=PROFILE_TYPE_DEFAULT, reserve_percent=0.0):
    """Select smallest cable profile that accommodates demand."""
    if demand <= 0:
        return CABLE_PROFILES[0]
    if profile_type == PROFILE_TYPE_POPC:
        effective_demand = math.ceil(demand * 1.30)
    elif profile_type == PROFILE_TYPE_OPERATOR:
        return _get_operator_profile(demand)
    else:
        if reserve_percent > 0:
            effective_demand = math.ceil(demand * (1 + reserve_percent / 100))
        else:
            effective_demand = demand
    return _select_profile(effective_demand)

def _select_profile(demand):
    """Select smallest cable profile >= demand."""
    if demand <= 0:
        return CABLE_PROFILES[0]
    if demand in CABLE_PROFILES:
        return demand
    idx = bisect.bisect_right(CABLE_PROFILES, demand)
    if idx < len(CABLE_PROFILES):
        return CABLE_PROFILES[idx]
    else:
        return CABLE_PROFILES[-1]

def _get_operator_profile(demand):
    """Operator-specific cable thresholds."""
    if demand <= 9:
        return 12
    elif demand <= 20:
        return 24
    elif demand <= 40:
        return 48
    elif demand <= 60:
        return 72
    elif demand <= 80:
        return 96
    elif demand <= 120:
        return 144
    elif demand <= 180:
        return 216
    else:
        return 288

def format_cable_profile(profile):
    """Format cable profile as '48F', '144F', etc."""
    return f"{profile}F"


# ---------------------------------------------------------------------------
# Client profiles — network design parameters per operator
# ---------------------------------------------------------------------------
CLIENT_PROFILES = {
    "Herotel": {
        "max_pon_size": 128,
        "target_pon_size": 96,
        "splitter_ratio_feeder": "1:16",
        "splitter_ratio_dist": "1:8",
        "max_feeder_cable_fibres": 144,
        "feeder_pole_height_m": 7,
        "dist_pole_height_m": 6,
        "max_span_m": 70,
        "max_drop_length_m": 150,
        "description": "Herotel GPON — high-density, cascaded 1:16×1:8 split",
    },
    "Vuma": {
        "max_pon_size": 64,
        "target_pon_size": 48,
        "splitter_ratio_feeder": "1:32",
        "splitter_ratio_dist": "1:4",
        "max_feeder_cable_fibres": 96,
        "feeder_pole_height_m": 7,
        "dist_pole_height_m": 5,
        "max_span_m": 60,
        "max_drop_length_m": 100,
        "description": "Vuma FTTH — standard 1:32 split, 64-unit PON",
    },
    "Fibertime": {
        "max_pon_size": 96,
        "target_pon_size": 72,
        "splitter_ratio_feeder": "1:16",
        "splitter_ratio_dist": "1:4",
        "max_feeder_cable_fibres": 96,
        "feeder_pole_height_m": 7,
        "dist_pole_height_m": 5,
        "max_span_m": 70,
        "max_drop_length_m": 120,
        "description": "Fibertime GPON — balanced 1:16×1:4 split, 96-unit PON",
    },
}


FORM_CLASS, _ = uic.loadUiType(os.path.join(
    os.path.dirname(__file__), 'forms', 'dockwidget_base.ui'))


# ---------------------------------------------------------------------------
# Span-network routing helpers (used by Generate Drop Cables)
# ---------------------------------------------------------------------------

def _find_seg_index(pts, snap_pt):
    """Return (i, t) — index of sub-segment and fractional position along it
    where snap_pt is closest to the polyline defined by *pts*.
    """
    import math
    min_d = float('inf')
    best_i, best_t = 0, 0.0
    for i in range(len(pts) - 1):
        ax, ay = pts[i].x(), pts[i].y()
        bx, by = pts[i + 1].x(), pts[i + 1].y()
        dx, dy = bx - ax, by - ay
        seg_sq = dx * dx + dy * dy
        if seg_sq > 1e-20:
            t = max(0.0, min(1.0,
                ((snap_pt.x() - ax) * dx + (snap_pt.y() - ay) * dy) / seg_sq))
        else:
            t = 0.0
        cx, cy = ax + t * dx, ay + t * dy
        d = math.sqrt((snap_pt.x() - cx) ** 2 + (snap_pt.y() - cy) ** 2)
        if d < min_d:
            min_d, best_i, best_t = d, i, t
    return best_i, best_t


def _build_span_routing_graph(span_feats):
    """Build a NetworkX graph of the span network.

    Nodes  : (round(x, 4), round(y, 4)) tuples for segment endpoints.
    Edges  : one per span feature, carrying *pts* (vertex list) and *weight* (length).
    Returns: (G, seg_ep) where seg_ep[fid] = (start_node, end_node, [QgsPointXY …]).
    """
    import networkx as nx
    from qgis.core import QgsPointXY

    G = nx.Graph()
    seg_ep = {}
    for fid, feat in span_feats.items():
        geom = feat.geometry()
        if not geom or geom.isEmpty():
            continue
        pts = [QgsPointXY(v.x(), v.y()) for v in geom.vertices()]
        if len(pts) < 2:
            continue
        n_s = (round(pts[0].x(), 4), round(pts[0].y(), 4))
        n_e = (round(pts[-1].x(), 4), round(pts[-1].y(), 4))
        length = geom.length()
        if not G.has_edge(n_s, n_e) or G[n_s][n_e]['weight'] > length:
            G.add_edge(n_s, n_e, weight=length, fid=fid, pts=pts)
        seg_ep[fid] = (n_s, n_e, pts)
    return G, seg_ep


def _span_route_pts(snap_a, fid_a, snap_b, fid_b, G, seg_ep):
    """Return [QgsPointXY, …] following the span network from *snap_a* to *snap_b*.

    The list includes *snap_a* and *snap_b*.  Returns *None* if no path exists.
    """
    import networkx as nx
    import math
    from qgis.core import QgsPointXY

    n_sa, n_ea, pts_a = seg_ep[fid_a]
    n_sb, n_eb, pts_b = seg_ep[fid_b]
    i_a, _ = _find_seg_index(pts_a, snap_a)
    i_b, _ = _find_seg_index(pts_b, snap_b)

    # ---- Same segment: extract the portion between the two snap points -----
    if fid_a == fid_b:
        # Determine which snap is earlier along the segment
        def _along(pts, idx):
            return sum(math.dist((pts[j].x(), pts[j].y()),
                                 (pts[j + 1].x(), pts[j + 1].y()))
                       for j in range(idx))
        if _along(pts_a, i_a) <= _along(pts_a, i_b):
            return [snap_a] + pts_a[i_a + 1:i_b + 1] + [snap_b]
        else:
            return [snap_a] + list(reversed(pts_a[i_b + 1:i_a + 1])) + [snap_b]

    # ---- Different segments: route via endpoint graph ----------------------
    best_path, best_cost = None, float('inf')
    for da in [n_sa, n_ea]:
        for db in [n_sb, n_eb]:
            try:
                plen = nx.shortest_path_length(G, da, db, weight='weight')
                pnodes = nx.shortest_path(G, da, db, weight='weight')
            except Exception:
                continue
            cost = (plen
                    + math.dist(da, (snap_a.x(), snap_a.y()))
                    + math.dist(db, (snap_b.x(), snap_b.y())))
            if cost < best_cost:
                best_cost, best_path = cost, (pnodes, da, db)

    if best_path is None:
        return None

    pnodes, da, db = best_path
    result = [snap_a]

    # Part 1: snap_a → da along segment A
    if da == n_ea:
        result.extend(pts_a[i_a + 1:])               # forward to end
    else:
        result.extend(reversed(pts_a[:i_a + 1]))     # backward to start

    # Part 2: traverse path_nodes da → … → db
    for k in range(len(pnodes) - 1):
        n1, n2 = pnodes[k], pnodes[k + 1]
        ed = G[n1][n2]
        eps = ed['pts']
        en_s = (round(eps[0].x(), 4), round(eps[0].y(), 4))
        if n1 == en_s:
            result.extend(eps[1:])           # forward  — skip eps[0] (= n1, already added)
        else:
            result.extend(reversed(eps[:-1]))  # backward — skip eps[-1] (= n1, already added)

    # Part 3: db → snap_b along segment B  (db is already the last element)
    if db == n_sb:
        result.extend(pts_b[1:i_b + 1])              # forward from start
    else:
        result.extend(reversed(pts_b[i_b + 1:-1]))   # backward from end
    result.append(snap_b)

    return result

# ---------------------------------------------------------------------------


class FTTHPlanToolDockWidget(QtWidgets.QDockWidget, FORM_CLASS):
    """Dock widget for the FTTH Plan Tool plugin."""

    closingPlugin = pyqtSignal()

    def __init__(self, iface, parent=None):
        """Constructor.
        
        Args:
            iface: QGIS interface instance
            parent: Parent widget
        """
        super(FTTHPlanToolDockWidget, self).__init__(parent)
        self.setupUi(self)
        self.setWindowTitle("Velocity Network Planner")
        self.iface = iface
        self.network_graph = None
        self.result_layer = None
        self.grouped_layer = None
        self.demand_points_layer = None
        self.splitter_points_layer = None
        self._op_t0 = None
        self._op_last_pct = -1
        self._strip_gen = 0
        self.active_client = None

        # --- Progress strip (inserted above textEdit_output) ---
        from qgis.PyQt.QtWidgets import QWidget as _QW, QHBoxLayout as _QHL, QProgressBar as _QPB, QLabel as _QL
        from qgis.PyQt.QtCore import QTimer as _QTm
        self._prog_strip = _QW()
        self._prog_strip.setFixedHeight(30)
        _ps_lay = _QHL(self._prog_strip)
        _ps_lay.setContentsMargins(4, 3, 4, 3)
        _ps_lay.setSpacing(6)
        self._prog_op_lbl = _QL("Processing...")
        self._prog_op_lbl.setStyleSheet("font-weight: bold; color: #2a6ebb;")
        _ps_lay.addWidget(self._prog_op_lbl)
        self._prog_bar = _QPB()
        self._prog_bar.setRange(0, 100)
        self._prog_bar.setValue(0)
        self._prog_bar.setTextVisible(False)
        self._prog_bar.setFixedHeight(14)
        self._prog_bar.setStyleSheet(
            "QProgressBar{border:1px solid #bbb;border-radius:4px;background:#f0f0f0;}"
            "QProgressBar::chunk{background:#2a6ebb;border-radius:3px;}"
        )
        _ps_lay.addWidget(self._prog_bar, 1)
        self._prog_time_lbl = _QL("0s")
        self._prog_time_lbl.setMinimumWidth(140)
        self._prog_time_lbl.setStyleSheet("color: #444; font-size: 9pt;")
        _ps_lay.addWidget(self._prog_time_lbl)
        self._prog_strip.setVisible(False)
        _main_lay = self.dockWidgetContents.layout()
        for _i in range(_main_lay.count()):
            _item = _main_lay.itemAt(_i)
            if _item and _item.widget() is self.textEdit_output:
                _main_lay.insertWidget(_i, self._prog_strip)
                break
        self._prog_timer = _QTm(self)
        self._prog_timer.setInterval(500)
        self._prog_timer.timeout.connect(self._op_tick)
        self.active_client_profile = None

        # Connect client profile button
        self.pushButton_set_client.clicked.connect(self.on_set_client_clicked)
        self.pushButton_calculate.clicked.connect(self.on_calculate_clicked)
        self.pushButton_clear.clicked.connect(self.on_clear_clicked)
        self.pushButton_build_graph.clicked.connect(self.on_build_graph_clicked)
        self.pushButton_analyze.clicked.connect(self.on_analyze_clicked)
        self.pushButton_group_erven.clicked.connect(self.on_group_erven_clicked)
        self.pushButton_generate_demand_points.clicked.connect(self.on_generate_demand_points_clicked)
        self.pushButton_show_batch_stats.clicked.connect(self.on_show_batch_stats_clicked)
        self.pushButton_generate_boundaries.clicked.connect(self.on_generate_boundaries_clicked)
        self.pushButton_generate_splitters.clicked.connect(self.on_generate_splitters_clicked)
        self.pushButton_generate_drop_lashed.clicked.connect(self.on_generate_drop_lashed_clicked)
        self.pushButton_generate_drop_ptp.clicked.connect(self.on_generate_drop_ptp_clicked)
        self.pushButton_generate_aggregation_points.clicked.connect(self.on_generate_aggregation_points_clicked)
        self.pushButton_manual_override.clicked.connect(self.on_manual_override_clicked)
        self.pushButton_validate_span_network.clicked.connect(self.on_validate_span_network_clicked)
        self.pushButton_generate_feeder_routes.clicked.connect(self.on_generate_feeder_routes_clicked)
        self.pushButton_generate_poles.clicked.connect(self.on_generate_poles_clicked)

        # Hide buttons not needed at this stage
        self.pushButton_validate_span_network.setVisible(False)
        self.pushButton_show_batch_stats.setVisible(False)

        # ── Reorganize Generate PON groupbox layout ──────────────────────────
        # Final order:  [AutoNet] [ManualNet] [Manual Override] [_manual_section (hidden)]
        # _manual_section contains: form rows + all step buttons (shown on ManualNet toggle)
        from qgis.PyQt.QtWidgets import QPushButton as _QPB2, QWidget as _QW2, QVBoxLayout as _QVB2

        gb_layout = self.groupBox_4.layout()   # QVBoxLayout from UI file

        # 1. Drain ALL existing items from the groupBox layout (keeps widgets alive via parent)
        _gb_items = []
        while gb_layout.count():
            _item = gb_layout.takeAt(0)
            _w = _item.widget()
            _l = _item.layout()
            if _w:
                _gb_items.append(('widget', _w))
            elif _l:
                _gb_items.append(('layout', _l))

        # 2. Build _manual_section container for all items EXCEPT Manual Override
        self._manual_section = _QW2()
        self._manual_section.setObjectName("manualSection")
        _ms_lay = _QVB2(self._manual_section)
        _ms_lay.setContentsMargins(0, 0, 0, 0)
        _ms_lay.setSpacing(gb_layout.spacing())

        for _kind, _item in _gb_items:
            if _kind == 'widget' and _item is self.pushButton_manual_override:
                continue  # placed separately below
            if _kind == 'layout':
                _ms_lay.addLayout(_item)
            else:
                _ms_lay.addWidget(_item)

        self._manual_section.setVisible(False)  # collapsed by default

        # 3. AutoNet button
        self._btn_autonet = _QPB2("⚡ AutoNet")
        self._btn_autonet.setToolTip(
            "Auto-detect layers and run the full pipeline:\n"
            "Generate PON Groups → Demand Points → Group Boundaries → Splitter Points → Drops PTP"
        )
        self._btn_autonet.setStyleSheet(
            "QPushButton { background-color: #1a6b3c; color: white; font-weight: bold; "
            "border-radius: 4px; padding: 5px; font-size: 10pt; }"
            "QPushButton:hover { background-color: #238a4f; }"
            "QPushButton:pressed { background-color: #145230; }"
        )
        self._btn_autonet.clicked.connect(self.on_autonet_clicked)

        # 4. ManualNet toggle button
        self._btn_manualnet = _QPB2("🔧 ManualNet")
        self._btn_manualnet.setCheckable(True)
        self._btn_manualnet.setChecked(False)
        self._btn_manualnet.setToolTip("Show / hide manual step controls")
        self._btn_manualnet.setStyleSheet(
            "QPushButton { background-color: #2a5b8a; color: white; font-weight: bold; "
            "border-radius: 4px; padding: 5px; font-size: 10pt; }"
            "QPushButton:hover { background-color: #336fa5; }"
            "QPushButton:pressed { background-color: #1f4468; }"
            "QPushButton:checked { background-color: #1f4468; }"
        )
        self._btn_manualnet.toggled.connect(
            lambda checked: self._manual_section.setVisible(checked)
        )

        # 5. Rebuild layout: AutoNet → ManualNet → Manual Override → collapsible section
        gb_layout.addWidget(self._btn_autonet)
        gb_layout.addWidget(self._btn_manualnet)
        gb_layout.addWidget(self.pushButton_manual_override)
        gb_layout.addWidget(self._manual_section)
        
        # Connect pole distance combo box to enable/disable custom input
        self.comboBox_pole_distance.currentIndexChanged.connect(self.on_pole_distance_changed)
        
        # Connect collapsible group boxes
        self.groupBox_4.toggled.connect(lambda checked: self.toggle_groupbox(self.groupBox_4, checked))
        self.groupBox_feeder_routes.toggled.connect(lambda checked: self.toggle_groupbox(self.groupBox_feeder_routes, checked))
        self.groupBox_pole_generation.toggled.connect(lambda checked: self.toggle_groupbox(self.groupBox_pole_generation, checked))
        
        # Initialize collapsed state for groups that start collapsed
        self.toggle_groupbox(self.groupBox_feeder_routes, False)
        self.toggle_groupbox(self.groupBox_pole_generation, False)
        
        # Connect layer type combo box to update label
        self.comboBox_clustering_method.currentIndexChanged.connect(self.on_clustering_method_changed)
        
        # Check if advanced libraries are available
        if not SKLEARN_AVAILABLE or not NUMPY_AVAILABLE:
            self.log_message("NOTE: Advanced clustering (DBSCAN, K-Means) requires scikit-learn and numpy.")
            self.log_message("Install with: pip install scikit-learn numpy")

        # Lock all planning sections until a client profile is loaded
        self._set_planning_sections_enabled(False)

        self.log_message("Velocity Network Planner initialized. Select a Client Profile to begin.")

    def on_clustering_method_changed(self, index):
        """Update UI elements based on selected clustering method."""
        # Only "Tight Groups of 8" method remains, no UI updates needed
        pass

    def on_layer_type_changed(self, index):
        """Layer type is fixed to Demand Points."""
        pass

    def on_set_client_clicked(self):
        """Load the selected client profile and unlock planning tools."""
        client_name = self.comboBox_client.currentText()
        if client_name == "-- Select Client --":
            self.log_message("ERROR: Please select a client from the dropdown before loading a profile.")
            return

        self.active_client = client_name
        self.active_client_profile = CLIENT_PROFILES[client_name]
        profile = self.active_client_profile

        # Update status label
        self.label_active_client.setText(client_name)
        self.label_active_client.setStyleSheet("color: green; font-weight: bold;")

        # Unlock planning sections
        self._set_planning_sections_enabled(True)

        self.log_message(f"--- Client Profile Loaded: {client_name} ---")
        self.log_message(f"  {profile['description']}")
        self.log_message(f"  Max PON size: {profile['max_pon_size']}  |  Target: {profile['target_pon_size']}")
        self.log_message(f"  Split ratio: Feeder {profile['splitter_ratio_feeder']}  |  Dist {profile['splitter_ratio_dist']}")
        self.log_message(f"  Max feeder cable: {profile['max_feeder_cable_fibres']}F  |  Max span: {profile['max_span_m']}m")
        self.log_message(f"  Pole heights: Feeder {profile['feeder_pole_height_m']}m  |  Dist {profile['dist_pole_height_m']}m")
        self.log_message("Planning tools are now unlocked.")

    def _set_planning_sections_enabled(self, enabled: bool):
        """Enable or disable all planning group boxes."""
        for gb in (self.groupBox_4, self.groupBox_feeder_routes, self.groupBox_pole_generation):
            gb.setEnabled(enabled)

    def toggle_groupbox(self, groupbox, checked):
        """Toggle visibility of groupbox contents for collapsible behavior."""
        # Get the layout inside the groupbox
        layout = groupbox.layout()
        if layout:
            # Show/hide all widgets in the layout
            for i in range(layout.count()):
                item = layout.itemAt(i)
                widget = item.widget()
                if widget:
                    widget.setVisible(checked)
                # Handle nested layouts
                nested_layout = item.layout()
                if nested_layout:
                    for j in range(nested_layout.count()):
                        nested_item = nested_layout.itemAt(j)
                        nested_widget = nested_item.widget()
                        if nested_widget:
                            nested_widget.setVisible(checked)

    def log_message(self, message: str):
        """Add a message to the output text area.
        
        Args:
            message: Message to display
        """
        self.textEdit_output.append(message)

    # ------------------------------------------------------------------
    # Timer / progress helpers
    # ------------------------------------------------------------------
    def _fmt_time(self, secs: float) -> str:
        """Format seconds into human-readable string."""
        if secs >= 3600:
            return f"{int(secs // 3600)}h {int((secs % 3600) // 60)}m"
        elif secs >= 60:
            return f"{int(secs // 60)}m {int(secs % 60)}s"
        else:
            return f"{secs:.1f}s"

    def _op_tick(self):
        """Called every 500 ms by _prog_timer to update the elapsed/ETA display."""
        import time
        if self._op_t0 is None:
            return
        secs = time.time() - self._op_t0
        elapsed_str = self._fmt_time(secs)
        pct = self._prog_bar.value()
        if pct > 0:
            eta_secs = secs * (100 - pct) / pct
            eta_str = f" | ETA: ~{self._fmt_time(eta_secs)}"
        else:
            eta_str = ""
        self._prog_time_lbl.setText(f"\u23f1 {elapsed_str}{eta_str}")

    def _start_timer(self):
        """Record the start time and show the progress strip."""
        import time
        self._op_t0 = time.time()
        self._op_last_pct = -1
        self._strip_gen += 1
        self._prog_bar.setValue(0)
        self._prog_time_lbl.setText("0s")
        self._prog_op_lbl.setText("Processing\u2026")
        self._prog_strip.setVisible(True)
        self._prog_timer.start()

    def _hide_prog_strip(self, gen: int):
        """Hide the progress strip only if no newer operation has started since gen."""
        if self._strip_gen == gen:
            self._prog_strip.setVisible(False)

    def _elapsed(self, label: str = ''):
        """Log time elapsed since _start_timer() was called, then finalise the strip."""
        import time
        from qgis.PyQt.QtCore import QTimer as _QT
        from qgis.PyQt.QtWidgets import QApplication as _QApp
        if self._op_t0 is None:
            return
        secs = time.time() - self._op_t0
        t_str = self._fmt_time(secs)
        prefix = f"{label} \u2014 " if label else ''
        self.log_message(f"  \u23f1 {prefix}{t_str}")
        # Finalise the strip
        self._prog_timer.stop()
        self._prog_bar.setValue(100)
        self._prog_op_lbl.setText(f"\u2713 {label}" if label else "\u2713 Done")
        self._prog_time_lbl.setText(f"\u23f1 {t_str}")
        _QApp.processEvents()
        _gen = self._strip_gen
        _QT.singleShot(3000, lambda: self._hide_prog_strip(_gen))
        self._op_t0 = None

    def _progress(self, done: int, total: int, label: str = ''):
        """Update progress bar and log at 25 % milestones; flush Qt event queue."""
        from qgis.PyQt.QtWidgets import QApplication
        import time
        if total > 0:
            pct = done * 100 // total
            self._prog_bar.setValue(pct)
            if label:
                self._prog_op_lbl.setText(label)
            milestone = (pct // 25) * 25
            if milestone > 0 and milestone != self._op_last_pct:
                self._op_last_pct = milestone
                elapsed = (time.time() - self._op_t0) if self._op_t0 is not None else 0.0
                tag = f"{label}: " if label else ''
                self.log_message(
                    f"  {tag}{milestone}%  ({done}/{total})  [{elapsed:.1f}s]"
                )
        QApplication.processEvents()


    def on_build_graph_clicked(self):
        """Build network graph from selected layers."""
        nodes_layer = self.comboBox_nodes.currentLayer()
        ducts_layer = self.comboBox_ducts.currentLayer()
        
        if not ducts_layer:
            self.log_message("ERROR: Please select a ducts layer.")
            return
        
        self._start_timer()
        try:
            self.log_message("Building network graph...")
            self.network_graph = NetworkGraph()

            # Add named nodes if a nodes layer is selected
            if nodes_layer:
                self.log_message(f"Loading nodes from '{nodes_layer.name()}'...")
                node_count = 0
                for feature in get_layer_features(nodes_layer):
                    coords = get_point_coordinates(feature)
                    if coords:
                        self.network_graph.add_node_from_qgis(
                            f"node_{feature.id()}",
                            coords,
                            properties=feature.attributeMap(),
                        )
                        node_count += 1
                self.log_message(f"  Added {node_count} nodes")

            # Add edges from ducts (intermediate vertices included)
            self.log_message(f"Loading ducts from '{ducts_layer.name()}'...")
            duct_count = 0
            for feature in get_layer_features(ducts_layer):
                coords = get_linestring_coordinates(feature)
                if coords and len(coords) >= 2:
                    self.network_graph.add_edge_from_qgis(
                        coords,
                        properties=feature.attributeMap(),
                    )
                    duct_count += 1
            self.log_message(f"  Processed {duct_count} duct features")

            # Display graph info
            info = self.network_graph.get_graph_info()
            self.log_message(f"\nGraph built successfully:")
            self.log_message(f"  Total nodes  : {info['nodes']}")
            self.log_message(f"  Total edges  : {info['edges']}")
            self.log_message(f"  Total length : {info.get('total_length', 0):.2f}")
            self.log_message(f"  Connected    : {info['connected']}")
            if info['components'] > 1:
                self.log_message(
                    f"  WARNING: {info['components']} isolated network islands detected. "
                    f"Sizes: {info['component_sizes']}"
                )
            self._elapsed("Total time")
        except Exception as e:
            self.log_message(f"ERROR building graph: {str(e)}")

    def on_calculate_clicked(self):
        """Calculate shortest path between two points."""
        if not self.network_graph or self.network_graph.G.number_of_nodes() == 0:
            self.log_message("ERROR: Please build the network graph first.")
            return
        
        ducts_layer = self.comboBox_ducts.currentLayer()
        if not ducts_layer:
            self.log_message("ERROR: No ducts layer selected.")
            return
        
        # For demonstration, use the extent of the ducts layer to pick random points
        extent = get_layer_extent(ducts_layer)
        
        # Use first and last node coordinates as example
        nodes = list(self.network_graph.G.nodes(data=True))
        if len(nodes) < 2:
            self.log_message("ERROR: Need at least 2 nodes for routing.")
            return
        
        source_coord = nodes[0][1]['coord']
        target_coord = nodes[-1][1]['coord']
        
        self.log_message(f"\nCalculating route...")
        self.log_message(f"  From: {source_coord}")
        self.log_message(f"  To: {target_coord}")
        self._start_timer()
        try:
            path_coords, total_length = self.network_graph.shortest_path_with_cost(
                source_coord, target_coord
            )
            self.log_message(f"  Route found with {len(path_coords)} vertices")
            self.log_message(f"  Total length : {total_length:.2f}")
            self.log_message(f"  Optical loss : {self._path_loss_db(path_coords):.3f} dB")

            # Create result layer
            self.create_result_layer(path_coords, total_length)
            self._elapsed("Total time")
        except Exception as e:
            self.log_message(f"ERROR calculating route: {str(e)}")

    def create_result_layer(self, path_coords, total_length):
        """Create a layer to display the routing result.
        
        Args:
            path_coords: List of (x, y) coordinate tuples
            total_length: Total path length
        """
        # Remove old result layer if exists
        if self.result_layer:
            QgsProject.instance().removeMapLayer(self.result_layer.id())
        
        # Get CRS from ducts layer
        ducts_layer = self.comboBox_ducts.currentLayer()
        crs = ducts_layer.crs().authid() if ducts_layer else "EPSG:4326"
        
        # Create new result layer
        self.result_layer = create_memory_layer("FTTH Route Result", "LineString", crs)
        
        # Add fields
        add_fields_to_layer(self.result_layer, [
            ('route_id', int, 'Integer'),
            ('length', float, 'Double'),
            ('num_points', int, 'Integer')
        ])
        self.result_layer.updateFields()
        
        # Add the route as a line feature
        attributes = {
            'route_id': 1,
            'length': total_length,
            'num_points': len(path_coords)
        }
        add_line_feature(self.result_layer, path_coords, attributes)
        
        # Update layer extent and add to map
        self.result_layer.updateExtents()
        QgsProject.instance().addMapLayer(self.result_layer)
        
        self.log_message("  Result layer added to map.")

    def _path_loss_db(self, path_coords: list) -> float:
        """Sum optical loss_db across graph edges that form *path_coords*.

        Walks consecutive coordinate pairs and looks up the edge in the graph.
        Coordinates are snapped via the graph's own precision before lookup.
        """
        if not self.network_graph:
            return 0.0
        ng = self.network_graph
        total = 0.0
        for raw_u, raw_v in zip(path_coords[:-1], path_coords[1:]):
            from .core import _snap_coord
            su = _snap_coord(raw_u, ng.snap_precision)
            sv = _snap_coord(raw_v, ng.snap_precision)
            nu = ng._coord_index.get(su)
            nv = ng._coord_index.get(sv)
            if nu and nv and ng.G.has_edge(nu, nv):
                total += ng.G.edges[nu, nv].get('loss_db', 0.0)
        return total

    def on_analyze_clicked(self):
        """Analyze selected layers and display statistics."""
        nodes_layer = self.comboBox_nodes.currentLayer()
        ducts_layer = self.comboBox_ducts.currentLayer()
        
        self.log_message("\n=== Layer Analysis ===")
        self._start_timer()
        if nodes_layer:
            self.log_message(f"\nNodes Layer: '{nodes_layer.name()}'")
            self.log_message(f"  Feature count: {nodes_layer.featureCount()}")
            self.log_message(f"  CRS: {nodes_layer.crs().authid()}")
            counts = count_features_by_geometry_type(nodes_layer)
            for geom_type, count in counts.items():
                if count > 0:
                    self.log_message(f"  {geom_type}: {count}")
            
            # List fields
            fields = nodes_layer.fields()
            field_names = [field.name() for field in fields]
            self.log_message(f"  Fields: {', '.join(field_names)}")
        
        if ducts_layer:
            self.log_message(f"\nDucts Layer: '{ducts_layer.name()}'")
            self.log_message(f"  Feature count: {ducts_layer.featureCount()}")
            self.log_message(f"  CRS: {ducts_layer.crs().authid()}")
            counts = count_features_by_geometry_type(ducts_layer)
            for geom_type, count in counts.items():
                if count > 0:
                    self.log_message(f"  {geom_type}: {count}")
            
            # List fields
            fields = ducts_layer.fields()
            field_names = [field.name() for field in fields]
            self.log_message(f"  Fields: {', '.join(field_names)}")
            
            # Calculate total length
            total_length = 0
            for feature in get_layer_features(ducts_layer):
                geom = feature.geometry()
                if geom:
                    total_length += geom.length()
            self.log_message(f"  Total length: {total_length:.2f}")
        self._elapsed("Total time")

    def on_clear_clicked(self):
        """Clear output and remove result layer."""
        self.textEdit_output.clear()
        
        if self.result_layer:
            QgsProject.instance().removeMapLayer(self.result_layer.id())
            self.result_layer = None

    def on_autonet_clicked(self):
        """AutoNet: auto-detect layers and run the full PON pipeline in one click.
        Steps: 1. Set combos  2. PON Groups  3. Demand Points
               4. Group Boundaries  5. Splitter Points  6. Drops PTP
        """
        from qgis.core import QgsProject, QgsVectorLayer
        from qgis.PyQt.QtWidgets import QApplication

        TOTAL_STEPS = 5

        def _autonet_progress(step, label):
            pct = int((step - 1) / TOTAL_STEPS * 100)
            self._prog_bar.setValue(pct)
            self._prog_op_lbl.setText(f"AutoNet {step}/{TOTAL_STEPS}: {label}")
            self._prog_strip.setVisible(True)
            QApplication.processEvents()

        self.log_message("\n══════════════════════════════════════════")
        self.log_message("  ⚡ AutoNet — Full Pipeline Started")
        self.log_message("══════════════════════════════════════════")
        self._prog_strip.setVisible(True)
        self._prog_bar.setValue(0)
        self._prog_op_lbl.setText("AutoNet — detecting layers…")
        QApplication.processEvents()

        # ── Layer auto-detection ───────────────────────────────────────
        # Exclude GENERATED output layer patterns (must NOT match input layer names).
        # Important: 'demand point' would match "Demand Points" (the INPUT layer) —
        # so exclude only the specific generated output suffixes.
        _excl_fragments = (
            'groups of',           # "Demand Points - Groups of 8"
            'group of',
            'demand points -',     # any "Demand Points - <suffix>" variant
            'splitter point',      # "Splitter Points" output layer
            'drop cable',
            'drop_cable',
            'pon zone',
            'pon boundary',
            'zone boundary',
            'group boundary',
            'aggregation point',
            'feeder route',
            'poles_',
            'autonet',
            'shortest',            # "Shortest path" routing output
            'routing',
        )
        # Generic placeholder/extent layer names (exact match)
        _generic_exact = {'aoi', 'extent', 'bbox', 'boundary', 'mask',
                          'study area', 'project area', 'area of interest',
                          'shortest path', 'shortest_path', 'routing result'}

        def _is_output_layer(name_lower):
            if name_lower in _generic_exact:
                return True
            return any(frag in name_lower for frag in _excl_fragments)

        def _find_layer(keywords, geom_type=None):
            """Search project layers by keyword, skipping known output layers."""
            for lyr in QgsProject.instance().mapLayers().values():
                if not isinstance(lyr, QgsVectorLayer):
                    continue
                if geom_type is not None and lyr.geometryType() != geom_type:
                    continue
                ln = lyr.name().lower()
                if _is_output_layer(ln):
                    continue
                if any(kw in ln for kw in keywords):
                    return lyr
            return None

        def _resolve_layer(combo, keywords, geom_type=None, fallback_geom=None):
            """Return best layer for a combo:
            1. Use the combo's current selection if it's a valid (non-output) layer.
            2. Otherwise search by keywords.
            3. Fallback: retry with fallback_geom or no geom filter.
            """
            current = combo.currentLayer()
            if current and isinstance(current, QgsVectorLayer):
                if not _is_output_layer(current.name().lower()):
                    return current   # already set correctly by user

            # Auto-detect by keyword
            lyr = _find_layer(keywords, geom_type)
            if not lyr and fallback_geom is not None:
                lyr = _find_layer(keywords, fallback_geom)
            if not lyr:
                lyr = _find_layer(keywords)
            return lyr

        # Demand: polygon (parcels/erven) preferred, then point, then any
        demand_kw = ('erf', 'parcel', 'stand', 'plot', 'property', 'premise',
                     'demand', 'subscriber', 'home', 'household')
        demand_lyr = _resolve_layer(self.comboBox_erf, demand_kw,
                                    geom_type=2, fallback_geom=0)

        # Span/route: line layer
        span_kw = ('span', 'route', 'fibre', 'fiber', 'cable', 'duct',
                   'network', 'trunk', 'backbone')
        span_lyr = _resolve_layer(self.comboBox_span_layer, span_kw, geom_type=1)

        # Road: line layer — 'path' intentionally excluded (too generic, matches "Shortest path")
        road_kw = ('road', 'street', 'highway', 'lane', 'avenue')
        road_lyr = _resolve_layer(self.comboBox_road_layer, road_kw, geom_type=1)

        # ── Validate ──────────────────────────────────────────────────
        if not demand_lyr:
            self.log_message("ERROR: AutoNet could not identify a demand/parcel layer.")
            self.log_message("  Please set the Demand Layer combo manually and retry.")
            self._prog_strip.setVisible(False)
            return
        if not span_lyr:
            self.log_message("ERROR: AutoNet could not identify a span/route layer.")
            self.log_message("  Please set the Route Layer combo manually and retry.")
            self._prog_strip.setVisible(False)
            return
        if not road_lyr:
            self.log_message("WARNING: No road layer found — road-crossing rule will be skipped.")

        # ── Apply combos ──────────────────────────────────────────────
        self.comboBox_erf.setLayer(demand_lyr)
        self.comboBox_span_layer.setLayer(span_lyr)
        if road_lyr:
            self.comboBox_road_layer.setLayer(road_lyr)

        # Lock method to Tight PON of 96
        for i in range(self.comboBox_clustering_method.count()):
            if 'tight' in self.comboBox_clustering_method.itemText(i).lower():
                self.comboBox_clustering_method.setCurrentIndex(i)
                break

        self.log_message(f"  Demand layer : {demand_lyr.name()}")
        self.log_message(f"  Route layer  : {span_lyr.name()}")
        self.log_message(f"  Road layer   : {road_lyr.name() if road_lyr else '(none)'}")
        self.log_message(f"  Method       : {self.comboBox_clustering_method.currentText()}")
        QApplication.processEvents()

        # ── Step 1: Generate PON Groups ───────────────────────────────
        _autonet_progress(1, "Generate PON Groups")
        self.log_message("\n── Step 1/5: Generate PON Groups ──")
        self.on_group_erven_clicked()
        QApplication.processEvents()

        # ── Step 2: Generate Demand Points ───────────────────────────
        _autonet_progress(2, "Generate Demand Points")
        self.log_message("\n── Step 2/5: Generate Demand Points ──")
        self.on_generate_demand_points_clicked()
        QApplication.processEvents()

        # ── Step 3: Generate Group Boundaries ────────────────────────
        _autonet_progress(3, "Generate Group Boundaries")
        self.log_message("\n── Step 3/5: Generate Group Boundaries ──")
        self.on_generate_boundaries_clicked()
        QApplication.processEvents()

        # ── Step 4: Generate Splitter Points ─────────────────────────
        _autonet_progress(4, "Generate Splitter Points")
        self.log_message("\n── Step 4/5: Generate Splitter Points ──")
        self.on_generate_splitters_clicked()
        QApplication.processEvents()

        # ── Step 5: Generate Drops PTP ───────────────────────────────
        _autonet_progress(5, "Generate Drops PTP")
        self.log_message("\n── Step 5/5: Generate Drops PTP ──")
        self.on_generate_drop_ptp_clicked()
        QApplication.processEvents()

        # ── Done ─────────────────────────────────────────────────────
        self._prog_bar.setValue(100)
        self._prog_op_lbl.setText("⚡ AutoNet Complete ✓")
        from qgis.PyQt.QtCore import QTimer as _QT2
        _gen = self._strip_gen
        _QT2.singleShot(4000, lambda: self._hide_prog_strip(_gen))
        self.log_message("")
        self.log_message("══════════════════════════════════════════")
        self.log_message("  ⚡ AutoNet — Pipeline Complete ✓")
        self.log_message("══════════════════════════════════════════")

    def on_group_erven_clicked(self):
        """Group ERF parcels or demand points using selected clustering method."""
        selected_layer = self.comboBox_erf.currentLayer()
        
        if not selected_layer:
            self.log_message("ERROR: Please select a layer.")
            return
        
        # Layer type fixed to Demand Points; method fixed to Tight PON of 96 (groups of 8)
        layer_type_name = "Demand Points"
        method_name = "Tight PON of 96"
        target_size = 8
        continuous_mode = False
        
        self.log_message(f"\n=== Grouping {layer_type_name} ===")
        self.log_message(f"Layer: '{selected_layer.name()}' ({selected_layer.featureCount()} features)")

        # Warn if the input layer looks like it's already been grouped
        _input_fields = [f.name() for f in selected_layer.fields()]
        if 'zone_name' in _input_fields or 'group_8' in _input_fields:
            self.log_message(
                "⚠ WARNING: The selected layer already has 'zone_name'/'group_8' fields — "
                "it appears to be a previously grouped layer, NOT the original demand points. "
                "Please select the ORIGINAL demand points layer in the dropdown above, "
                "then re-run Generate PON Groups."
            )
        # Warn if the layer has a filter expression active (subset string)
        _subset = selected_layer.subsetString()
        if _subset:
            self.log_message(
                f"⚠ WARNING: Layer has an active filter: {_subset!r}. "
                "Only filtered features will be grouped. Remove the filter if you want "
                "the full network covered."
            )
        
        try:
            # Tight Groups of 8
            from qgis.core import QgsVectorLayer, QgsFeature, QgsField, QgsProject
            from qgis.PyQt.QtCore import QVariant, QMetaType
            from .erf_grouping import cluster_tight_groups_of_8, group_zones_from_groups
            
            # Get all features
            features = list(selected_layer.getFeatures())
            total_features = len(features)
            
            if total_features == 0:
                self.log_message("ERROR: Layer has no features.")
                return
            
            # Check if route layer is selected
            route_layer = self.comboBox_span_layer.currentLayer()
            road_layer = self.comboBox_road_layer.currentLayer()
            if road_layer:
                self.log_message(f"Road barrier layer: '{road_layer.name()}' — drop cables will not cross roads")
            
            # Grouping parameters (Herotel Tight PON of 96 defaults)
            try:
                network_coverage = self.doubleSpinBox_span_corridor.value()
            except AttributeError:
                network_coverage = 150.0
            group_cohesion = 120
            gap_tolerance = 3
            
            # Determine geometry type
            geom_type = selected_layer.geometryType()
            is_point_layer = (geom_type == 0)
            
            if route_layer:
                self.log_message(f"Grouping along route: '{route_layer.name()}'")
                self.log_message(f"Span corridor: {network_coverage:.0f} m — demand points within this perpendicular distance of span are span-anchored")
                self.log_message(f"Creating tight groups of {target_size} on same span segments...")
                self.log_message("Ensuring each group stays on same route segment...")
                if is_point_layer:
                    self.log_message(f"Points within {group_cohesion} units considered adjacent...")
                    self.log_message(f"Network coverage: {network_coverage} units, Gap tolerance multiplier: {gap_tolerance}x")
                else:
                    self.log_message("Parcels must touch to be in same group...")
            else:
                self.log_message(f"Detecting blocks and creating tight groups of {target_size}...")
                self.log_message("Analyzing layout and block boundaries...")
            
            # Perform clustering
            self.log_message(f"Clustering {total_features} features...")
            self._start_timer()
            from qgis.PyQt.QtWidgets import QApplication as _QApp
            _QApp.processEvents()
            if continuous_mode:
                # Groups of 100: continuous along span, crosses segments
                from .erf_grouping import cluster_continuous_groups
                if not route_layer:
                    self.log_message("ERROR: Continuous mode (Groups of 100) requires a Route/Span layer.")
                    return
                feature_to_group = cluster_continuous_groups(features, route_layer, target_size=target_size)
            else:
                # Groups of 8/16/128: respects segments and blocks
                feature_to_group = cluster_tight_groups_of_8(
                    features, 
                    route_layer=route_layer, 
                    target_size=target_size,
                    span_proximity_limit=network_coverage,
                    adjacency_distance=group_cohesion,
                    gap_tolerance_multiplier=gap_tolerance,
                    progress_callback=lambda done, total, lbl='Clustering': self._progress(done, total, lbl),
                    road_layer=road_layer,
                    demand_crs=selected_layer.crs(),
                )
            
            if not feature_to_group:
                self.log_message("ERROR: No features could be grouped.")
                return
            # Log clustering milestone without stopping the timer
            import time as _time
            _clust_secs = _time.time() - self._op_t0
            self.log_message(f"  \u23f1 Clustering \u2014 {self._fmt_time(_clust_secs)}")
            
            # Create new scratch layer
            crs = selected_layer.crs().authid()
            geom_type = selected_layer.geometryType()
            geom_type_names = {0: "Point", 1: "LineString", 2: "Polygon"}
            geom_name = geom_type_names.get(geom_type, "Polygon")
            
            new_layer = QgsVectorLayer(f"{geom_name}?crs={crs}", 
                                      f"{selected_layer.name()} - Groups of {target_size}", 
                                      "memory")
            provider = new_layer.dataProvider()
            
            # Copy original fields
            provider.addAttributes(selected_layer.fields().toList())
            # Add group field
            field_name = f'group_{target_size}'
            provider.addAttributes([QgsField(field_name, QMetaType.Type.Int)])
            # Add zone fields — packs groups into PON zones capped at 128 units (Herotel GPON standard)
            zone_field_name = 'zone_id'
            zone_name_field = 'zone_name'
            provider.addAttributes([
                QgsField(zone_field_name, QMetaType.Type.Int),
                QgsField(zone_name_field, QMetaType.Type.QString),
            ])
            new_layer.updateFields()

            # Compute zone assignments: span-ordered packing of groups into
            # PON-zone buckets capped at 96 demand units (Herotel Tight PON of 96).
            # Groups are ordered along the span from the farthest leaf back to the POP
            # when a span layer is available, ensuring each PON zone is a contiguous
            # stretch of the network.
            feature_positions = {}
            for feat in features:
                geom = feat.geometry()
                if geom and not geom.isEmpty():
                    c = geom.centroid().asPoint()
                    feature_positions[feat.id()] = (c.x(), c.y())
            zone_max_size = 96
            olt_layer = self.comboBox_olt_layer.currentLayer()
            feature_to_zone = group_zones_from_groups(
                feature_to_group,
                max_zone_size=zone_max_size,
                feature_positions=feature_positions,
                route_layer=route_layer,
                pop_layer=olt_layer,
            )

            _no_group = sum(1 for f in features if feature_to_group.get(f.id()) is None)
            _no_zone  = sum(1 for f in features if feature_to_group.get(f.id()) is not None
                           and feature_to_zone.get(f.id()) is None)
            self.log_message(f"Grouped: {len(feature_to_group)} / {total_features} features "
                             f"({_no_group} skipped, {_no_zone} grouped but missing zone)")

            # Add features with group and zone assignments
            self.log_message("Building output layer...")
            new_features = []
            _ungrouped_count = 0
            for idx, feat in enumerate(features):
                self._progress(idx + 1, total_features, 'Output')
                group_id = feature_to_group.get(feat.id())
                z_id = feature_to_zone.get(feat.id()) if group_id is not None else None
                if group_id is None:
                    _ungrouped_count += 1

                new_feat = QgsFeature(new_layer.fields())
                new_feat.setGeometry(feat.geometry())

                # Copy original attributes
                for field in selected_layer.fields():
                    new_feat[field.name()] = feat[field.name()]

                # Assign group and zone (NULL when clustering missed this feature)
                new_feat[field_name] = group_id
                new_feat[zone_field_name] = z_id
                new_feat[zone_name_field] = f"Zone {z_id}" if z_id is not None else None
                new_features.append(new_feat)
            if _ungrouped_count:
                self.log_message(f"WARNING: {_ungrouped_count} features had no group assignment "
                                 f"(zone_name will be NULL — boundary step will assign to nearest zone)")
            
            provider.addFeatures(new_features)
            new_layer.updateExtents()
            
            # Add layer to project
            QgsProject.instance().addMapLayer(new_layer)
            
            # Store reference to grouped layer for demand point generation
            self.grouped_layer = new_layer
            
            total_features = len(new_features)
            total_clusters = len(set(feature_to_group.values()))
            total_zones = len(set(feature_to_zone.values())) if feature_to_zone else 0
            
            # Apply zone-based symbology so each "Zone N" is a distinct colour
            self.apply_batch_symbology(new_layer, zone_name_field)
            
            # Group boundaries removed - use "Generate Group Boundaries" button instead
            
            self.log_message(f"\nCreated {total_clusters} groups → {total_zones} zones (max {zone_max_size} units/zone, named Zone 1 … Zone {total_zones})")
            if route_layer:
                self.log_message("All groups constrained to same span segment")
                if is_point_layer:
                    self.log_message("All points in each group are within 10 units of each other")
                else:
                    self.log_message("All parcels in each group touch each other")
            else:
                self.log_message("Groups respect natural block boundaries")
                
            if total_features % target_size != 0:
                last_group_size = total_features % target_size if total_features % target_size != 0 else target_size
                self.log_message(f"Note: Last group has {last_group_size} features")
            
            # Common output
            self.log_message(f"\nGrouping completed successfully!")
            self._elapsed("Total time")
            self.log_message(f"  Total {layer_type_name.lower()}: {total_features}")
            self.log_message(f"  Total groups: {total_clusters}")
            self.log_message(f"  Total zones:  {total_zones} (≤{zone_max_size} units each, Zone 1 – Zone {total_zones})")
            if total_clusters > 0:
                self.log_message(f"  Avg per group: {total_features / total_clusters:.1f}")
            if total_zones > 0:
                self.log_message(f"  Avg per zone:  {total_features / total_zones:.1f}")
            
            self.log_message(f"\nNew layer created: '{new_layer.name()}'")
            self.log_message(f"Fields added: '{field_name}' (group number), '{zone_field_name}' (zone number), '{zone_name_field}' (zone label).")
            self.log_message(f"Use 'Show Statistics' for detailed info.")
            
        except Exception as e:
            self.log_message(f"ERROR: {str(e)}")
            import traceback
            self.log_message(traceback.format_exc())

    def on_generate_demand_points_clicked(self):
        """Generate demand points from grouped parcels at their centroids."""
        # Use the most recently generated grouped layer
        selected_layer = self.grouped_layer
        
        if not selected_layer:
            self.log_message("ERROR: Please generate grouped parcels first.")
            return
        
        self.log_message(f"\n=== Generating Demand Points ===")
        self.log_message(f"Source Layer: '{selected_layer.name()}'")
        
        try:
            from qgis.core import QgsVectorLayer, QgsFeature, QgsProject, QgsWkbTypes
            from qgis.PyQt.QtCore import QVariant, QMetaType
            
            # Get features from source layer
            features = list(selected_layer.getFeatures())
            
            if len(features) == 0:
                self.log_message("ERROR: Layer has no features.")
                return
            
            # Create new point layer with same CRS
            crs = selected_layer.crs().authid()
            demand_layer = QgsVectorLayer(f"Point?crs={crs}", 
                                         f"{selected_layer.name()} - Demand Points", 
                                         "memory")
            provider = demand_layer.dataProvider()
            
            # Copy all fields from source layer
            provider.addAttributes(selected_layer.fields().toList())
            demand_layer.updateFields()
            
            # Create demand point for each parcel at its centroid
            total_src = len(features)
            self.log_message(f"Processing {total_src} features...")
            self._start_timer()
            demand_features = []
            for idx, feature in enumerate(features):
                self._progress(idx + 1, total_src, 'Demand pts')
                geom = feature.geometry()
                if geom and not geom.isEmpty():
                    # Get centroid
                    centroid = geom.centroid()
                    
                    # Create new point feature
                    demand_feature = QgsFeature(demand_layer.fields())
                    demand_feature.setGeometry(centroid)
                    
                    # Copy all attributes from source feature
                    for field in selected_layer.fields():
                        demand_feature[field.name()] = feature[field.name()]
                    
                    demand_features.append(demand_feature)
            
            # Add features to layer
            provider.addFeatures(demand_features)
            demand_layer.updateExtents()
            
            # Add layer to project
            QgsProject.instance().addMapLayer(demand_layer)
            
            # Store reference for drop cable generation
            self.demand_points_layer = demand_layer
            
            self.log_message(f"\nCreated {len(demand_features)} demand points")
            self._elapsed("Total time")
            self.log_message(f"New layer: '{demand_layer.name()}'")
            self.log_message("All attributes copied from source parcels")
            
        except Exception as e:
            self.log_message(f"ERROR: {str(e)}")
            import traceback
            self.log_message(traceback.format_exc())

    def apply_batch_symbology(self, layer: QgsVectorLayer, field_name: str = 'batch_id'):
        """Apply categorized symbology to show different batches/clusters in different colors.
        
        Args:
            layer: Layer with grouping field
            field_name: Name of the field to use for symbology
        """
        try:
            from qgis.core import (
                QgsCategorizedSymbolRenderer,
                QgsRendererCategory,
                QgsSymbol,
                QgsStyle
            )
            from qgis.PyQt.QtGui import QColor
            import random
            
            field_idx = layer.fields().indexOf(field_name)
            
            if field_idx < 0:
                return
            
            # Get unique values
            unique_values = set()
            for feature in layer.getFeatures():
                value = feature.attribute(field_name)
                if value is not None:
                    unique_values.add(value)
            
            # Create categories
            categories = []
            for value in sorted(unique_values):
                # Generate a color for each group
                random.seed(value)  # Consistent colors for same value
                color = QColor(
                    random.randint(100, 255),
                    random.randint(100, 255),
                    random.randint(100, 255),
                    180  # Some transparency
                )
                
                symbol = QgsSymbol.defaultSymbol(layer.geometryType())
                symbol.setColor(color)
                
                # Determine label — for zone_name the stored value IS already
                # the human-readable label ("Zone 1", "Zone 2", …)
                if field_name == 'zone_name':
                    label = str(value)
                elif 'batch' in field_name.lower():
                    label = f"Batch {value}"
                elif 'cluster' in field_name.lower():
                    label = f"Cluster {value}"
                elif 'pon' in field_name.lower():
                    label = f"PON {value}"
                elif 'zone' in field_name.lower():
                    label = f"Zone {value}"
                else:
                    label = f"Group {value}"
                
                category = QgsRendererCategory(
                    value,
                    symbol,
                    label
                )
                categories.append(category)
            
            # Apply renderer
            renderer = QgsCategorizedSymbolRenderer(field_name, categories)
            layer.setRenderer(renderer)
            layer.triggerRepaint()
            
            self.log_message(f"  Applied color-coded symbology.")
            
        except Exception as e:
            # If symbology fails, just log it but don't fail the whole operation
            self.log_message(f"  (Could not apply symbology: {str(e)})")

    def on_find_splitters_clicked(self):
        """Find and display optimal splitter locations."""
        selected_layer = self.comboBox_erf.currentLayer()
        
        if not selected_layer:
            self.log_message("ERROR: Please select a layer.")
            return
        
        if not SKLEARN_AVAILABLE or not NUMPY_AVAILABLE:
            self.log_message("ERROR: Splitter optimization requires scikit-learn and numpy.")
            self.log_message("Install with: pip install scikit-learn numpy")
            return
        
        num_splitters = 10  # Default number of splitters
        
        self.log_message(f"\n=== Finding Optimal Splitter Locations ===")
        self.log_message(f"Layer: '{selected_layer.name()}'")
        self.log_message(f"Number of splitters: {num_splitters}")
        
        try:
            # Get features
            features = list(selected_layer.getFeatures())
            
            if len(features) == 0:
                self.log_message("ERROR: Layer has no features.")
                return
            
            # Find optimal locations
            self._start_timer()
            splitter_locations = find_optimal_splitter_locations(features, num_splitters)
            
            # Create a memory layer for splitter points
            from qgis.core import QgsVectorLayer, QgsFeature, QgsGeometry, QgsProject, QgsField
            from qgis.PyQt.QtCore import QVariant, QMetaType
            
            # Get CRS from source layer
            crs = selected_layer.crs().authid()
            splitter_layer = QgsVectorLayer(f"Point?crs={crs}", "Optimal Splitter Locations", "memory")
            provider = splitter_layer.dataProvider()
            
            # Add fields
            provider.addAttributes([
                QgsField("splitter_id", QMetaType.Type.Int),
                QgsField("x_coord", QMetaType.Type.Double),
                QgsField("y_coord", QMetaType.Type.Double)
            ])
            splitter_layer.updateFields()
            
            # Add splitter points
            splitter_features = []
            for idx, location in enumerate(splitter_locations):
                feat = QgsFeature()
                feat.setGeometry(QgsGeometry.fromPointXY(location))
                feat.setAttributes([idx + 1, location.x(), location.y()])
                splitter_features.append(feat)
            
            provider.addFeatures(splitter_features)
            splitter_layer.updateExtents()
            
            # Style the splitter layer
            from qgis.core import QgsMarkerSymbol, QgsSingleSymbolRenderer
            from qgis.PyQt.QtGui import QColor
            
            symbol = QgsMarkerSymbol.createSimple({
                'name': 'star',
                'color': 'red',
                'size': '4',
                'outline_color': 'white',
                'outline_width': '0.5'
            })
            renderer = QgsSingleSymbolRenderer(symbol)
            splitter_layer.setRenderer(renderer)
            
            # Add layer to project
            QgsProject.instance().addMapLayer(splitter_layer)
            
            self.log_message(f"\nCreated {len(splitter_locations)} optimal splitter locations.")
            self.log_message(f"Splitter layer added to map.")
            self.log_message(f"Locations minimize average distance to parcels/points.")
            self._elapsed("Total time")
            
        except Exception as e:
            self.log_message(f"ERROR: {str(e)}")
            import traceback
            self.log_message(traceback.format_exc())

    def on_cluster_erven_clicked(self):
        """Group ERF parcels into spatial clusters based on proximity."""
        erf_layer = self.comboBox_erf.currentLayer()
        
        if not erf_layer:
            self.log_message("ERROR: Please select an ERF layer.")
            return
        
        self.log_message(f"\n=== Clustering ERF Parcels by Proximity ===")
        self.log_message(f"Layer: '{erf_layer.name()}'")
        self.log_message(f"Grouping adjacent parcels into spatial clusters...")
        
        try:
            # Perform the clustering with a reasonable distance threshold
            # Adjust this based on your data's coordinate system and parcel sizes
            max_distance = 500.0  # Adjust as needed for your project
            self._start_timer()
            total_features, total_clusters = assign_clusters_to_layer(
                erf_layer,
                max_distance=max_distance,
                field_name='cluster_id'
            )
            
            self.log_message(f"\nClustering completed successfully!")
            self.log_message(f"  Total parcels: {total_features}")
            self.log_message(f"  Total clusters: {total_clusters}")
            self.log_message(f"  Avg parcels per cluster: {total_features / total_clusters:.1f}" if total_clusters > 0 else "")
            
            # Refresh the layer
            erf_layer.triggerRepaint()
            
            # Apply categorized symbology based on cluster_id
            self._apply_cluster_symbology(erf_layer)
            
            self.log_message(f"\nCluster ID field added to layer.")
            self.log_message(f"Each color represents a spatial cluster of adjacent parcels.")
            self._elapsed("Total time")
        except Exception as e:
            self.log_message(f"ERROR clustering ERF parcels: {str(e)}")
            import traceback
            self.log_message(traceback.format_exc())

    def _apply_cluster_symbology(self, layer: QgsVectorLayer):
        """Apply categorized symbology to show different clusters in different colors.
        
        Args:
            layer: Layer with cluster_id field
        """
        try:
            from qgis.core import (
                QgsCategorizedSymbolRenderer,
                QgsRendererCategory,
                QgsSymbol,
                QgsStyle
            )
            from qgis.PyQt.QtGui import QColor
            import random
            
            field_name = 'cluster_id'
            field_idx = layer.fields().indexOf(field_name)
            
            if field_idx < 0:
                return
            
            # Get unique cluster values
            unique_values = set()
            for feature in layer.getFeatures():
                cluster_id = feature.attribute(field_name)
                if cluster_id is not None:
                    unique_values.add(cluster_id)
            
            # Create categories
            categories = []
            for cluster_id in sorted(unique_values):
                # Generate a color for each cluster
                random.seed(cluster_id)  # Consistent colors for same cluster
                color = QColor(
                    random.randint(100, 255),
                    random.randint(100, 255),
                    random.randint(100, 255),
                    200  # Some transparency
                )
                
                symbol = QgsSymbol.defaultSymbol(layer.geometryType())
                symbol.setColor(color)
                
                category = QgsRendererCategory(
                    cluster_id,
                    symbol,
                    f"Cluster {cluster_id}"
                )
                categories.append(category)
            
            # Create and set the renderer
            renderer = QgsCategorizedSymbolRenderer(field_name, categories)
            layer.setRenderer(renderer)
            layer.triggerRepaint()
            
        except Exception as e:
            # If symbology fails, just log it but don't fail the whole operation
            self.log_message(f"  (Could not apply cluster symbology: {str(e)})")

    def on_show_batch_stats_clicked(self):
        """Show statistics about batch assignments."""
        erf_layer = self.comboBox_erf.currentLayer()
        
        if not erf_layer:
            self.log_message("ERROR: Please select an ERF layer.")
            return
        
        field_idx = erf_layer.fields().indexOf('batch_id')
        if field_idx < 0:
            self.log_message("ERROR: Layer has no 'batch_id' field. Please group ERF parcels first.")
            return
        
        self.log_message(f"\n=== Batch Statistics ===")
        self.log_message(f"Layer: '{erf_layer.name()}'")
        
        try:
            stats = get_batch_statistics(erf_layer)
            self._start_timer()
            if not stats:
                self.log_message("No batch data found.")
                return
            
            self.log_message(f"\nTotal batches: {stats['total_batches']}")
            self.log_message(f"Average batch size: {stats['avg_batch_size']:.1f}")
            
            # Show details for each batch
            self.log_message(f"\nBatch Details:")
            for batch_id in sorted(stats['batch_counts'].keys()):
                count = stats['batch_counts'][batch_id]
                extent = stats['batch_extents'].get(batch_id)
                
                if extent:
                    extent_str = f"({extent.xMinimum():.2f}, {extent.yMinimum():.2f}) to ({extent.xMaximum():.2f}, {extent.yMaximum():.2f})"
                else:
                    extent_str = "N/A"
                
                self.log_message(f"  Batch {batch_id}: {count} parcels")
                self.log_message(f"    Extent: {extent_str}")
            self._elapsed("Total time")
        except Exception as e:
            self.log_message(f"ERROR getting batch statistics: {str(e)}")

    def _build_zone_polygon(self, grouped_layer, zone_feats):
        """Return a QgsGeometry zone polygon for a list of demand features.
        Uses the same buffer + morphological-closing algorithm as
        on_generate_boundaries_clicked so the shapes stay consistent."""
        from qgis.core import QgsGeometry, QgsUnitTypes
        is_point_layer = grouped_layer.geometryType() == 0
        geoms = [f.geometry() for f in zone_feats if not f.geometry().isEmpty()]
        if not geoms:
            return QgsGeometry()
        if is_point_layer:
            unit_type = grouped_layer.crs().mapUnits()
            if unit_type == QgsUnitTypes.DistanceDegrees:
                min_r, max_r = 0.00005, 0.00025
            else:
                min_r, max_r = 5.0, 30.0
            coords = [f.geometry().asPoint()
                      for f in zone_feats if not f.geometry().isEmpty()]
            if len(coords) <= 1:
                radius = max_r
            else:
                nn_sum, nn_count = 0.0, 0
                for i, pt in enumerate(coords):
                    best = float('inf')
                    for j, other in enumerate(coords):
                        if i == j:
                            continue
                        d = ((pt.x() - other.x()) ** 2 +
                             (pt.y() - other.y()) ** 2) ** 0.5
                        if d < best:
                            best = d
                    if best < float('inf'):
                        nn_sum += best
                        nn_count += 1
                mean_nn = nn_sum / nn_count if nn_count else max_r
                radius = max(min(mean_nn * 0.55, max_r), min_r)
            zone_geom = zone_feats[0].geometry().buffer(radius, 8)
            for f in zone_feats[1:]:
                if not f.geometry().isEmpty():
                    zone_geom = zone_geom.combine(
                        f.geometry().buffer(radius, 8))
            gap_r = radius * 2.5
            zone_geom = zone_geom.buffer(gap_r, 6).buffer(-gap_r * 0.92, 6)
            if not zone_geom.isEmpty():
                if zone_geom.isMultipart():
                    zone_geom = zone_geom.convexHull()
                else:
                    poly = zone_geom.asPolygon()
                    if poly:
                        zone_geom = QgsGeometry.fromPolygonXY([poly[0]])
        else:
            merged = geoms[0]
            for g in geoms[1:]:
                merged = merged.combine(g)
            zone_geom = merged.convexHull()
        return zone_geom

    # ── Boundary-generation helpers (class-level so they aren't recreated ──
    # ── on every button click)                                            ──

    @staticmethod
    def _snap_parts_together(geom, bridge_r):
        """Connect all multipart fragments by bridging nearest-point pairs."""
        if not geom.isMultipart():
            return geom
        parts = list(geom.asGeometryCollection())
        while len(parts) > 1:
            min_d = float('inf')
            bi, bj = 0, 1
            bp1 = bp2 = None
            for ii in range(len(parts)):
                for jj in range(ii + 1, len(parts)):
                    d = parts[ii].distance(parts[jj])
                    if d < min_d:
                        min_d = d
                        bi, bj = ii, jj
                        bp1 = parts[ii].nearestPoint(parts[jj]).asPoint()
                        bp2 = parts[jj].nearestPoint(parts[ii]).asPoint()
            if bp1 is None or bp2 is None:
                break
            bridge = QgsGeometry.fromPolylineXY([
                QgsPointXY(bp1.x(), bp1.y()),
                QgsPointXY(bp2.x(), bp2.y()),
            ]).buffer(bridge_r, 4)
            merged_part = parts[bi].combine(parts[bj]).combine(bridge)
            parts = [parts[k] for k in range(len(parts)) if k != bi and k != bj]
            parts.append(merged_part)
        return parts[0] if parts else geom

    @staticmethod
    def _centroid_xy(pts):
        """Return (mean_x, mean_y) of a list of QgsPointXY."""
        if not pts:
            return (0, 0)
        return (sum(p.x() for p in pts) / len(pts),
                sum(p.y() for p in pts) / len(pts))

    @staticmethod
    def _force_single(geom, z_n, zone_build_params):
        """Rebuild a multipart geometry into one solid polygon."""
        if not geom.isMultipart():
            return geom
        zp = zone_build_params.get(z_n, {})
        radius_z = zp.get('radius', 5.0)
        result = FTTHPlanToolDockWidget._snap_parts_together(geom, radius_z)
        if not result.isMultipart():
            return result
        hull = geom.convexHull()
        return hull if not hull.isEmpty() else geom

    def on_generate_boundaries_clicked(self):
        """Generate one polygon boundary per PON zone from the grouped demand points layer."""
        # Prefer the stored reference; fall back to searching project layers by field
        grouped_layer = self.grouped_layer
        if not grouped_layer:
            # Pick the grouped layer with the MOST features to avoid stale partial layers
            _best_layer = None
            _best_count = -1
            for layer in QgsProject.instance().mapLayers().values():
                if isinstance(layer, QgsVectorLayer):
                    if 'zone_name' in [f.name() for f in layer.fields()]:
                        _fc = layer.featureCount()
                        if _fc > _best_count:
                            _best_count = _fc
                            _best_layer = layer
            grouped_layer = _best_layer

        if not grouped_layer:
            self.log_message("ERROR: No grouped PON layer found. Run 'Generate PON Groups' first.")
            return

        field_names = [f.name() for f in grouped_layer.fields()]
        if 'zone_name' not in field_names:
            self.log_message("ERROR: Layer has no 'zone_name' field. Run 'Generate PON Groups' first.")
            return

        has_zone_id = 'zone_id' in field_names
        is_point_layer = grouped_layer.geometryType() == 0

        self.log_message(f"\n=== Generating PON Zone Boundaries ===")
        self.log_message(f"Source layer: '{grouped_layer.name()}' ({grouped_layer.featureCount()} features)")
        if not self.grouped_layer:
            self.log_message("  (using project layer — if incomplete, re-run 'Generate PON Groups' first)")

        try:
            crs = grouped_layer.crs().authid()

            polygon_layer = QgsVectorLayer(
                f"Polygon?crs={crs}",
                f"{grouped_layer.name()} - PON Zones",
                "memory"
            )
            poly_provider = polygon_layer.dataProvider()
            poly_provider.addAttributes([
                QgsField('zone_name', QMetaType.Type.QString),
                QgsField('zone_id', QMetaType.Type.Int),
                QgsField('unit_count', QMetaType.Type.Int),
            ])
            polygon_layer.updateFields()

            # Collect features per zone
            features_by_zone = {}
            zone_id_map = {}
            _total_feats = 0
            _null_zone_feats = 0
            _null_zone_list = []
            for feat in grouped_layer.getFeatures():
                _total_feats += 1
                z_name = feat['zone_name']
                if not z_name:
                    _null_zone_feats += 1
                    _null_zone_list.append(feat)
                    continue
                if z_name not in features_by_zone:
                    features_by_zone[z_name] = []
                    zone_id_map[z_name] = feat['zone_id'] if has_zone_id else 0
                features_by_zone[z_name].append(feat)
            self.log_message(f"Layer features: {_total_feats} total, "
                             f"{_total_feats - _null_zone_feats} with zone, "
                             f"{_null_zone_feats} with NULL zone_name (assigning to nearest zone)")

            # Assign NULL-zone features to the geographically nearest zone
            if _null_zone_list and features_by_zone:
                # Build one centroid per zone from its members
                _zone_cx = {}
                _zone_cy = {}
                for _zn, _zfeats in features_by_zone.items():
                    _xs = [_zf.geometry().centroid().asPoint().x()
                           for _zf in _zfeats
                           if not _zf.geometry().isEmpty()]
                    _ys = [_zf.geometry().centroid().asPoint().y()
                           for _zf in _zfeats
                           if not _zf.geometry().isEmpty()]
                    if _xs:
                        _zone_cx[_zn] = sum(_xs) / len(_xs)
                        _zone_cy[_zn] = sum(_ys) / len(_ys)
                _zone_names_sorted = list(_zone_cx.keys())
                for _nf in _null_zone_list:
                    _nf_geom = _nf.geometry()
                    if not _nf_geom or _nf_geom.isEmpty():
                        continue
                    _pt = _nf_geom.centroid().asPoint()
                    _best_z = min(
                        _zone_names_sorted,
                        key=lambda _zn: (_pt.x() - _zone_cx[_zn]) ** 2
                                       + (_pt.y() - _zone_cy[_zn]) ** 2
                    )
                    features_by_zone[_best_z].append(_nf)

            # Build one polygon per zone
            zone_polygons = []
            zone_build_params = {}   # z_name → {radius, mean_nn, coords}
            _total_zones = len(features_by_zone)

            self._start_timer()
            _QApp = QApplication
            _QApp.processEvents()
            for _bz_idx, (z_name, zone_feats) in enumerate(sorted(
                    features_by_zone.items(),
                    key=lambda kv: zone_id_map.get(kv[0], 0))):
                self._progress(_bz_idx + 1, _total_zones, 'Boundaries')

                geoms = [f.geometry() for f in zone_feats if not f.geometry().isEmpty()]
                if not geoms:
                    continue

                z_id = zone_id_map.get(z_name, 0)
                count = len(zone_feats)

                if is_point_layer:
                    unit_type = grouped_layer.crs().mapUnits()
                    if unit_type == QgsUnitTypes.DistanceDegrees:
                        min_r, max_r = 0.00004, 0.00025   # ~4 m – 28 m at equator
                    else:
                        min_r, max_r = 4.0, 30.0           # metres

                    coords = [f.geometry().asPoint()
                              for f in zone_feats if not f.geometry().isEmpty()]

                    if len(coords) <= 1:
                        radius = max_r
                        mean_nn = max_r
                    else:
                        nn_sum, nn_count = 0.0, 0
                        for i, pt in enumerate(coords):
                            best = float('inf')
                            for j, other in enumerate(coords):
                                if i == j:
                                    continue
                                d = ((pt.x()-other.x())**2 +
                                     (pt.y()-other.y())**2) ** 0.5
                                if d < best:
                                    best = d
                            if best < float('inf'):
                                nn_sum += best
                                nn_count += 1
                        mean_nn = nn_sum / nn_count if nn_count else max_r
                        radius = max(min(mean_nn * 0.55, max_r), min_r)

                    # Buffer every point and union
                    merged = geoms[0].buffer(radius, 12)
                    for g in geoms[1:]:
                        merged = merged.combine(g.buffer(radius, 12))

                    # First: light morphological close to merge same-side gaps
                    close_r = radius * 0.5
                    candidate = merged.buffer(close_r, 8).buffer(-close_r, 8)
                    zone_geom = candidate if not candidate.isEmpty() else merged

                    # Second: if still multipart, directly snap parts together
                    if zone_geom.isMultipart():
                        zone_geom = self._snap_parts_together(zone_geom, radius)

                    # Last resort: convex hull (always single polygon)
                    if zone_geom.isMultipart():
                        zone_geom = zone_geom.convexHull()

                    # Store params for post-overlap consolidation
                    zone_build_params[z_name] = {
                        'radius': radius, 'mean_nn': mean_nn, 'coords': coords
                    }

                else:
                    # Dissolve parcel polygons then convex hull for a clean outer envelope
                    merged = geoms[0]
                    for g in geoms[1:]:
                        merged = merged.combine(g)
                    zone_geom = merged.convexHull()

                poly_feat = QgsFeature(polygon_layer.fields())
                poly_feat.setGeometry(zone_geom)
                poly_feat.setAttributes([z_name, z_id, count])
                zone_polygons.append(poly_feat)

            # ── Remove overlaps between zone polygons ─────────────────────────
            # For any area where two zones overlap, assign it to whichever zone
            # has a demand point closer to that overlap region.
            if len(zone_polygons) > 1:
                # Build working list
                zone_data = []
                for pf in zone_polygons:
                    z = pf.attribute('zone_name')
                    pts = [f.geometry().asPoint()
                           for f in features_by_zone.get(z, [])
                           if not f.geometry().isEmpty()]
                    zone_data.append([pf.geometry(), pts, pf])

                # Subtract overlaps: zone that owns an overlap area keeps it
                clipped_geoms = []
                for i, (g_i, pts_i, feat_i) in enumerate(zone_data):
                    clipped = g_i
                    z_name_i = feat_i.attribute('zone_name')
                    cx_i, cy_i = self._centroid_xy(pts_i)
                    for j, (g_j, pts_j, feat_j) in enumerate(zone_data):
                        if i == j:
                            continue
                        inter = clipped.intersection(g_j)
                        if inter.isEmpty():
                            continue
                        oc = inter.centroid().asPoint()
                        cx_j, cy_j = self._centroid_xy(pts_j)
                        di = (oc.x()-cx_i)**2 + (oc.y()-cy_i)**2
                        dj = (oc.x()-cx_j)**2 + (oc.y()-cy_j)**2
                        if dj < di:
                            diff = clipped.difference(inter)
                            if not diff.isEmpty():
                                clipped = diff
                            # If the difference fragmented the polygon, immediately
                            # consolidate back to a single polygon.
                            if clipped.isMultipart():
                                clipped = self._force_single(clipped, z_name_i, zone_build_params)
                    clipped_geoms.append(clipped)

                # Re-add any demand point that fell outside its clipped polygon
                unit_type = grouped_layer.crs().mapUnits()
                for i in range(len(clipped_geoms)):
                    z_n = zone_polygons[i].attribute('zone_name')
                    pts_i = zone_data[i][1]
                    if not pts_i:
                        continue
                    pad_r = zone_build_params.get(z_n, {}).get(
                        'radius',
                        0.000009 if unit_type == QgsUnitTypes.DistanceDegrees else 5.0
                    )
                    clipped = clipped_geoms[i]
                    for _pt in pts_i:
                        pt_geom = QgsGeometry.fromPointXY(_pt)
                        if not clipped.contains(pt_geom):
                            clipped = clipped.combine(pt_geom.buffer(pad_r, 8))
                    clipped_geoms[i] = clipped

                # Final pass: guarantee every zone is a single solid polygon
                for i in range(len(clipped_geoms)):
                    if clipped_geoms[i].isMultipart():
                        z_n = zone_polygons[i].attribute('zone_name')
                        clipped_geoms[i] = self._force_single(clipped_geoms[i], z_n, zone_build_params)

                for i, pf in enumerate(zone_polygons):
                    pf.setGeometry(clipped_geoms[i])

            poly_provider.addFeatures(zone_polygons)
            polygon_layer.updateExtents()

            # Categorised renderer — distinct colour per zone
            n = max(len(zone_polygons), 1)
            categories = []
            for i, pf in enumerate(zone_polygons):
                z_name = pf.attribute('zone_name')
                hue = (i / n) % 1.0
                r, g, b = [int(c * 255) for c in colorsys.hsv_to_rgb(hue, 0.65, 0.88)]
                fill_col    = QColor(r, g, b, 70)
                outline_col = QColor(r, g, b, 230)
                sym = QgsFillSymbol.createSimple({
                    'color':         fill_col.name(QColor.HexArgb),
                    'outline_color': outline_col.name(),
                    'outline_width': '1.2',
                    'outline_style': 'solid',
                })
                categories.append(QgsRendererCategory(z_name, sym, z_name))

            polygon_layer.setRenderer(QgsCategorizedSymbolRenderer('zone_name', categories))

            # Labels — zone name + unit count
            label_settings = QgsPalLayerSettings()
            label_settings.fieldName = "zone_name || '\n' || unit_count || ' units'"
            label_settings.isExpression = True
            label_settings.enabled = True

            text_fmt = QgsTextFormat()
            text_fmt.setFont(QFont('Arial', 9, QFont.Bold))
            text_fmt.setSize(9)
            text_fmt.setColor(QColor('#1a1a1a'))

            buf = QgsTextBufferSettings()
            buf.setEnabled(True)
            buf.setSize(1.0)
            buf.setColor(QColor('white'))
            text_fmt.setBuffer(buf)
            label_settings.setFormat(text_fmt)

            polygon_layer.setLabeling(QgsVectorLayerSimpleLabeling(label_settings))
            polygon_layer.setLabelsEnabled(True)

            QgsProject.instance().addMapLayer(polygon_layer)

            self.log_message(f"\nCreated {len(zone_polygons)} PON zone boundary polygons")
            self.log_message(f"Layer: '{polygon_layer.name()}'")
            for pf in zone_polygons:
                self.log_message(
                    f"  {pf.attribute('zone_name')}: {pf.attribute('unit_count')} units")
            self._elapsed("Total time")

        except Exception as e:
            self.log_message(f"ERROR generating PON zone boundaries: {str(e)}")
            import traceback
            self.log_message(traceback.format_exc())

    def on_generate_splitters_clicked(self):
        """Generate splitter points on span line for each group."""
        from qgis.core import QgsVectorLayer, QgsFeature, QgsGeometry, QgsProject, QgsField, QgsPointXY
        from qgis.core import QgsMarkerSymbol, QgsSingleSymbolRenderer
        from qgis.PyQt.QtCore import QVariant, QMetaType
        import math
        
        # Find the grouped layer (check for Groups of 8, 16, 128, or 100)
        grouped_layer = None
        for layer in QgsProject.instance().mapLayers().values():
            if isinstance(layer, QgsVectorLayer):
                layer_name = layer.name().lower()
                if (('groups of 8' in layer_name or 'group of 8' in layer_name or 
                     'groups of 16' in layer_name or 'group of 16' in layer_name or
                     'groups of 128' in layer_name or 'group of 128' in layer_name or
                     'groups of 100' in layer_name or 'group of 100' in layer_name) and 
                   'boundary' not in layer_name and 
                   'splitter' not in layer_name):
                    grouped_layer = layer
                    break
        
        if not grouped_layer:
            self.log_message("ERROR: Could not find grouped layer.")
            self.log_message("Please run 'Group Parcels/Points' first.")
            return
        
        # Get span layer
        span_layer = self.comboBox_span_layer.currentLayer()
        if not span_layer:
            self.log_message("ERROR: Please select a Route/Span layer.")
            return
        
        # Check for group field
        group_field = None
        if 'group_8' in [f.name() for f in grouped_layer.fields()]:
            group_field = 'group_8'
        elif 'group_16' in [f.name() for f in grouped_layer.fields()]:
            group_field = 'group_16'
        elif 'group_128' in [f.name() for f in grouped_layer.fields()]:
            group_field = 'group_128'
        elif 'group_100' in [f.name() for f in grouped_layer.fields()]:
            group_field = 'group_100'
        elif 'batch_id' in [f.name() for f in grouped_layer.fields()]:
            group_field = 'batch_id'
        
        if not group_field:
            self.log_message("ERROR: Layer must have 'group_8', 'group_16', 'group_128', 'group_100', or 'batch_id' field.")
            return

        # Detect aggregation zone field so each splitter records which zone it belongs to
        src_field_names = [f.name() for f in grouped_layer.fields()]
        zone_field_src = None
        if 'zone_id' in src_field_names:
            zone_field_src = 'zone_id'
        elif 'group_100' in src_field_names:
            zone_field_src = 'group_100'

        self.log_message(f"\n=== Generating Splitter Points ===")
        self.log_message(f"Source layer: '{grouped_layer.name()}'")
        self.log_message(f"Span layer: '{span_layer.name()}'")
        
        try:
            crs = grouped_layer.crs().authid()
            
            # Create splitter points layer
            splitter_layer = QgsVectorLayer(f"Point?crs={crs}", 
                                           "Splitter Points", 
                                           "memory")
            provider = splitter_layer.dataProvider()
            
            # Add fields
            provider.addAttributes([
                QgsField('fid', QMetaType.Type.Int),
                QgsField('ID', QMetaType.Type.QString),
                QgsField('group_id', QMetaType.Type.Int),
                QgsField('zone_id', QMetaType.Type.Int),    # aggregation zone membership
                QgsField('drop_count', QMetaType.Type.Int),   # number of demand points in this group
            ])
            splitter_layer.updateFields()
            
            # --- Locate poles layer for snapping (optional) ---
            from qgis.core import QgsSpatialIndex
            poles_layer = None
            for lyr in QgsProject.instance().mapLayers().values():
                if isinstance(lyr, QgsVectorLayer) and lyr.geometryType() == 0:  # Point
                    if lyr.name().lower().startswith('poles_') and 'pole_type' in [f.name() for f in lyr.fields()]:
                        poles_layer = lyr
                        break

            # Build spatial index + coordinate lookup for fast nearest-pole search
            pole_coords = {}   # feature_id -> QgsPointXY
            pole_index = None
            if poles_layer:
                pole_index = QgsSpatialIndex()
                for pf in poles_layer.getFeatures():
                    pole_index.insertFeature(pf)
                    pole_coords[pf.id()] = pf.geometry().asPoint()
                self.log_message(f"Snapping splitters to nearest pole ('{poles_layer.name()}')")
            else:
                self.log_message("No poles layer found — snapping splitters to nearest span line point")

            # Group features by group_id
            features_by_group = {}
            for feat in grouped_layer.getFeatures():
                group_id = feat[group_field]
                if group_id not in features_by_group:
                    features_by_group[group_id] = []
                features_by_group[group_id].append(feat)
            
            # Create splitter point for each group
            splitter_features = []
            total_groups_sp = len(features_by_group)
            self.log_message(f"Processing {total_groups_sp} groups...")
            self._start_timer()
            for sp_idx, (group_id, group_features) in enumerate(features_by_group.items()):
                self._progress(sp_idx + 1, total_groups_sp, 'Splitters')
                if not group_features:
                    continue
                
                # Calculate centroid of all features in group
                all_points = []
                for feat in group_features:
                    geom = feat.geometry()
                    if geom:
                        centroid = geom.centroid().asPoint()
                        all_points.append(centroid)
                
                if not all_points:
                    continue
                
                # Calculate average position (group centroid)
                avg_x = sum(pt.x() for pt in all_points) / len(all_points)
                avg_y = sum(pt.y() for pt in all_points) / len(all_points)
                group_centroid = QgsPointXY(avg_x, avg_y)
                
                # --- Snap to nearest pole (preferred) or nearest span point (fallback) ---
                nearest_point = None

                if pole_index and pole_coords:
                    # Use spatial index: find 1 nearest pole to the group centroid
                    from qgis.core import QgsRectangle
                    cx, cy = group_centroid.x(), group_centroid.y()
                    candidates = pole_index.nearestNeighbor(group_centroid, 1)
                    if candidates:
                        nearest_point = pole_coords[candidates[0]]
                else:
                    # Fallback: nearest point on the span line
                    min_distance = float('inf')
                    for span_feat in span_layer.getFeatures():
                        span_geom = span_feat.geometry()
                        if not span_geom or span_geom.isEmpty():
                            continue
                        nearest = span_geom.nearestPoint(QgsGeometry.fromPointXY(group_centroid))
                        if nearest.isEmpty():
                            continue
                        nearest_pt = nearest.asPoint()
                        distance = math.sqrt(
                            (group_centroid.x() - nearest_pt.x())**2 +
                            (group_centroid.y() - nearest_pt.y())**2
                        )
                        if distance < min_distance:
                            min_distance = distance
                            nearest_point = nearest_pt
                
                if nearest_point:
                    # Create splitter point feature
                    splitter_feat = QgsFeature(splitter_layer.fields())
                    splitter_feat.setGeometry(QgsGeometry.fromPointXY(nearest_point))
                    
                    # Count demand points in this group
                    drop_count = len(group_features)

                    # Resolve zone membership from source features
                    zone_val = group_features[0][zone_field_src] if zone_field_src else None
                    zone_int = int(zone_val) if zone_val is not None else -1

                    # Set attributes: fid, ID, group_id, zone_id, drop_count
                    splitter_feat.setAttributes([
                        int(group_id),  # fid
                        str(group_id),  # ID
                        int(group_id),  # group_id
                        zone_int,       # zone_id
                        drop_count,     # drop_count
                    ])
                    
                    splitter_features.append(splitter_feat)
            
            # Add features to layer
            provider.addFeatures(splitter_features)
            splitter_layer.updateExtents()
            
            # Apply symbology - green circles
            symbol = QgsMarkerSymbol.createSimple({
                'name': 'circle',
                'color': '0,255,0',
                'outline_color': 'black',
                'outline_width': '0.5',
                'size': '4'
            })
            renderer = QgsSingleSymbolRenderer(symbol)
            splitter_layer.setRenderer(renderer)
            
            # Add labels showing drop count
            from qgis.core import QgsPalLayerSettings, QgsTextFormat, QgsTextBufferSettings, QgsVectorLayerSimpleLabeling
            from qgis.PyQt.QtGui import QFont, QColor
            
            label_settings = QgsPalLayerSettings()
            # Label: "Grp <group_id> | Zone <zone_id> [<drop_count>]"
            if zone_field_src:
                label_settings.fieldName = (
                    '\'Grp \' || "group_id" || \' | Z\' || "zone_id" || \' [\' || "drop_count" || \']\''
                )
                label_settings.isExpression = True
            else:
                label_settings.fieldName = '\'Grp \' || "group_id" || \' [\' || "drop_count" || \']\''
                label_settings.isExpression = True
            label_settings.enabled = True
            label_settings.placement = QgsPalLayerSettings.AroundPoint
            
            text_format = QgsTextFormat()
            text_format.setFont(QFont('Arial', 8))
            text_format.setSize(8)
            text_format.setColor(QColor('black'))
            
            buffer_settings = QgsTextBufferSettings()
            buffer_settings.setEnabled(True)
            buffer_settings.setSize(1.0)
            buffer_settings.setColor(QColor('white'))
            text_format.setBuffer(buffer_settings)
            
            label_settings.setFormat(text_format)
            
            labeling = QgsVectorLayerSimpleLabeling(label_settings)
            splitter_layer.setLabeling(labeling)
            splitter_layer.setLabelsEnabled(True)
            
            # Add layer to project
            QgsProject.instance().addMapLayer(splitter_layer)
            
            # Store reference for drop cable generation
            self.splitter_points_layer = splitter_layer
            
            # Calculate statistics
            total_drops = sum(f['drop_count'] for f in splitter_features)
            max_drops = max((f['drop_count'] for f in splitter_features), default=0)
            min_drops = min((f['drop_count'] for f in splitter_features), default=0)
            
            self.log_message(f"\nCreated {len(splitter_features)} splitter points")
            self._elapsed("Total time")
            self.log_message(f"  Total demand points: {total_drops}")
            self.log_message(f"  Max drops per splitter: {max_drops}")
            self.log_message(f"  Min drops per splitter: {min_drops}")
            self.log_message(f"Layer: '{splitter_layer.name()}'")
            if zone_field_src:
                self.log_message(f"Zone membership sourced from field '{zone_field_src}'")
                self.log_message("Label shows: Zone ID [drop count]")
            else:
                self.log_message("No zone field found — zone_id set to -1; label shows drop count only")
            self.log_message("Splitters placed on span line for each group")
            
        except Exception as e:
            self.log_message(f"ERROR generating splitters: {str(e)}")
            import traceback
            self.log_message(traceback.format_exc())

    def on_generate_drop_lashed_clicked(self):
        """Generate drop cables that follow the span network for drops >50 m (aerial lashed)."""
        from qgis.core import (QgsVectorLayer, QgsFeature, QgsGeometry, QgsProject,
                               QgsField, QgsLineString, QgsPointXY,
                               QgsSpatialIndex, QgsUnitTypes,
                               QgsLineSymbol, QgsSingleSymbolRenderer,
                               QgsRuleBasedRenderer)
        from qgis.PyQt.QtCore import QVariant, QMetaType
        import math
        
        # Try to use stored layer references first, then search if needed
        demand_points_layer = None
        splitter_points_layer = None
        
        # Check if stored references are valid
        try:
            if self.demand_points_layer and not sip.isdeleted(self.demand_points_layer):
                demand_points_layer = self.demand_points_layer
                self.log_message(f"Using stored demand points layer: '{demand_points_layer.name()}'")
        except:
            pass
        
        try:
            if self.splitter_points_layer and not sip.isdeleted(self.splitter_points_layer):
                splitter_points_layer = self.splitter_points_layer
                self.log_message(f"Using stored splitter points layer: '{splitter_points_layer.name()}'")
        except:
            pass
        
        # Find demand points layer if not stored — prefer point geometry over polygon
        if not demand_points_layer:
            _dm_candidates = []
            for layer in QgsProject.instance().mapLayers().values():
                if isinstance(layer, QgsVectorLayer):
                    layer_name = layer.name().lower()
                    if 'demand points' in layer_name or 'demand_points' in layer_name:
                        _dm_candidates.append(layer)
            # Prefer point (geometryType 0) layers; fall back to first match
            _pt_layers = [l for l in _dm_candidates if l.geometryType() == 0]
            if _pt_layers:
                demand_points_layer = _pt_layers[0]
            elif _dm_candidates:
                demand_points_layer = _dm_candidates[0]
            if demand_points_layer:
                self.log_message(f"Found demand points layer: '{demand_points_layer.name()}'")

        if not demand_points_layer:
            self.log_message("ERROR: Could not find demand points layer.")
            self.log_message("Please generate demand points first.")
            return
        
        # Find splitter points layer if not stored
        if not splitter_points_layer:
            for layer in QgsProject.instance().mapLayers().values():
                if isinstance(layer, QgsVectorLayer):
                    layer_name = layer.name().lower()
                    if 'splitter' in layer_name and layer.geometryType() == 0:  # Point layer
                        splitter_points_layer = layer
                        self.log_message(f"Found splitter points layer: '{splitter_points_layer.name()}'")
                        break
        
        if not splitter_points_layer:
            self.log_message("ERROR: Could not find splitter points layer.")
            self.log_message("Please generate splitter points first.")
            return
        
        self.log_message(f"\n=== Generating Drop Cables Lashed ===")
        self.log_message(f"Demand points: '{demand_points_layer.name()}'")
        self.log_message(f"Splitters: '{splitter_points_layer.name()}'")
        
        try:
            crs = demand_points_layer.crs().authid()
            
            # Check if Drop Cables layer already exists
            existing_drop_cable_layer = None
            for layer in QgsProject.instance().mapLayers().values():
                if isinstance(layer, QgsVectorLayer) and layer.name() == "Drop Cables Lashed":
                    existing_drop_cable_layer = layer
                    break
            
            # If layer exists, remove it and recreate (to reflect updated group IDs)
            if existing_drop_cable_layer:
                self.log_message("Updating existing Drop Cables Lashed layer...")
                QgsProject.instance().removeMapLayer(existing_drop_cable_layer.id())
            
            # Create drop cables layer
            drop_cable_layer = QgsVectorLayer(f"LineString?crs={crs}",
                                             "Drop Cables Lashed",
                                             "memory")
            provider = drop_cable_layer.dataProvider()
            
            # Add fields - including fiber count from cable profile system
            provider.addAttributes([
                QgsField('cable_id', QMetaType.Type.Int),
                QgsField('group_id', QMetaType.Type.Int),
                QgsField('demand_id', QMetaType.Type.Int),
                QgsField('fiber_count', QMetaType.Type.Int),
                QgsField('fiber_size', QMetaType.Type.QString),
                QgsField('via_span', QMetaType.Type.Int),      # 1 = routed via span; 0 = direct
                QgsField('cable_length', QMetaType.Type.Double),   # Cartesian length in CRS units
                QgsField('zone_id', QMetaType.Type.Int),      # aggregation zone membership
            ])
            drop_cable_layer.updateFields()
            
            # Add virtual field for length using $length expression
            from qgis.core import QgsField, QgsExpression, QgsExpressionContextUtils
            length_field = QgsField('length', QMetaType.Type.Double)
            length_field.setLength(10)
            length_field.setPrecision(2)
            drop_cable_layer.addExpressionField('$length', length_field)
            
            # Drop cables typically use smallest profile (1-2 fibers per customer)
            drop_fiber_count = get_cable_profile(1, PROFILE_TYPE_DEFAULT)  # 2F minimum
            drop_fiber_size = format_cable_profile(drop_fiber_count)
            self.log_message(f"Drop cable profile: {drop_fiber_size} (1 fiber per customer + spare)")
            
            # Get splitters indexed by group_id; also build zone lookup (group_id -> zone_id)
            splitters_by_group = {}
            zone_by_group = {}
            _sp_has_zone = 'zone_id' in [f.name() for f in splitter_points_layer.fields()]
            for _sp in splitter_points_layer.getFeatures():
                _sgid = _sp['group_id']
                _sgeom = _sp.geometry()
                if _sgeom and not _sgeom.isEmpty():
                    splitters_by_group[_sgid] = _sgeom.asPoint()
                if _sp_has_zone and _sgid is not None:
                    _zv = _sp['zone_id']
                    zone_by_group[_sgid] = int(_zv) if _zv is not None else -1

            self.log_message(f"Found {len(splitters_by_group)} splitter groups: {sorted(splitters_by_group.keys())}")

            # ---- Via-span routing setup ----------------------------------------
            # Drop cables longer than VIA_SPAN_THRESHOLD are routed to the nearest
            # point on the span line first, then onward to the splitter.
            span_layer = self.comboBox_span_layer.currentLayer()
            span_feats = {}
            span_index = None
            crs_units = demand_points_layer.crs().mapUnits()
            is_geographic = (crs_units == QgsUnitTypes.DistanceDegrees)
            VIA_SPAN_THRESHOLD = 0.00045 if is_geographic else 50.0  # ~50 m
            if span_layer:
                span_feats = {f.id(): f for f in span_layer.getFeatures()}
                span_index = QgsSpatialIndex(span_layer.getFeatures())
                self.log_message(
                    f"Span layer: '{span_layer.name()}' ({len(span_feats)} segments)"
                    f" — cables >{VIA_SPAN_THRESHOLD:.0f} map units will follow span network")
            else:
                self.log_message("No span layer selected — all drop cables will be direct")

            # Build routing graph and pre-compute splitter snap points
            span_graph = None
            seg_ep = {}
            splitter_snaps = {}  # group_id -> (snap_pt, snap_fid)
            if span_feats:
                span_graph, seg_ep = _build_span_routing_graph(span_feats)
                self.log_message(
                    f"Routing graph: {span_graph.number_of_nodes()} nodes, "
                    f"{span_graph.number_of_edges()} edges")
                for _gid, _spt in splitters_by_group.items():
                    _nearest = span_index.nearestNeighbor(_spt, 5)
                    _best_snap, _best_fid, _best_d = None, None, float('inf')
                    for _fid in _nearest:
                        _sg = span_feats[_fid].geometry()
                        _near = _sg.nearestPoint(QgsGeometry.fromPointXY(_spt))
                        if _near.isEmpty():
                            continue
                        _np = _near.asPoint()
                        _d = math.sqrt((_spt.x() - _np.x()) ** 2 + (_spt.y() - _np.y()) ** 2)
                        if _d < _best_d:
                            _best_d = _d
                            _best_snap = QgsPointXY(_np.x(), _np.y())
                            _best_fid = _fid
                    splitter_snaps[_gid] = (_best_snap, _best_fid)
            # -------------------------------------------------------------------

            # Check what fields exist in demand points
            demand_fields = [f.name() for f in demand_points_layer.fields()]
            self.log_message(f"Demand points fields: {demand_fields}")
            
            # Create drop cable for each demand point to its group's splitter
            cable_features = []
            cable_id = 1
            skipped_no_group = 0
            skipped_no_splitter = 0
            groups_found = set()
            connections_by_group = {}
            total_demand = demand_points_layer.featureCount()
            self.log_message(f"Connecting {total_demand} demand points to splitters...")
            self._start_timer()
            for dc_idx, demand_point in enumerate(demand_points_layer.getFeatures()):
                self._progress(dc_idx + 1, total_demand, 'Drop cables')
                demand_geom = demand_point.geometry()
                if not demand_geom or demand_geom.isEmpty():
                    continue
                # Use centroid for polygon/line layers so non-point sources work correctly
                if demand_geom.type() == 0:  # Point
                    demand_pt = demand_geom.asPoint()
                else:
                    demand_pt = demand_geom.centroid().asPoint()
                
                # Find group_id field (could be group_8, group_16, group_128, or group_100)
                group_id = None
                group_field_used = None
                for field_name in ['group_8', 'group_16', 'group_128', 'group_100', 'batch_id']:
                    if field_name in demand_fields:
                        group_id = demand_point[field_name]
                        group_field_used = field_name
                        if group_id is not None:
                            groups_found.add(group_id)
                        break
                
                if group_id is None:
                    skipped_no_group += 1
                    continue
                
                # Get splitter for this group (each demand point connects to splitter with matching group_id)
                if group_id not in splitters_by_group:
                    skipped_no_splitter += 1
                    continue
                
                splitter_pt = splitters_by_group[group_id]

                # Straight-line distance from demand point to splitter
                direct_dist = math.sqrt(
                    (demand_pt.x() - splitter_pt.x()) ** 2 +
                    (demand_pt.y() - splitter_pt.y()) ** 2
                )

                # Via-span routing: cables beyond threshold follow the span network
                # path: demand_pt → snap_on_span → [span] → snap_on_span → splitter_pt
                via_span_used = 0
                if span_index and span_feats and direct_dist > VIA_SPAN_THRESHOLD:
                    # Find nearest point on span for this demand point
                    snap_d, snap_d_fid, min_snap_d = None, None, float('inf')
                    for fid in span_index.nearestNeighbor(demand_pt, 5):
                        sg = span_feats[fid].geometry()
                        if not sg or sg.isEmpty():
                            continue
                        near_geom = sg.nearestPoint(QgsGeometry.fromPointXY(demand_pt))
                        if near_geom.isEmpty():
                            continue
                        np_pt = near_geom.asPoint()
                        d = math.sqrt((demand_pt.x() - np_pt.x()) ** 2 +
                                      (demand_pt.y() - np_pt.y()) ** 2)
                        if d < min_snap_d:
                            min_snap_d = d
                            snap_d = QgsPointXY(np_pt.x(), np_pt.y())
                            snap_d_fid = fid

                    snap_s, snap_s_fid = splitter_snaps.get(group_id, (None, None))

                    if snap_d and snap_s and span_graph:
                        span_pts = _span_route_pts(
                            snap_d, snap_d_fid, snap_s, snap_s_fid, span_graph, seg_ep)
                        if span_pts:
                            line_geom = QgsGeometry.fromPolylineXY(
                                [demand_pt] + span_pts + [splitter_pt])
                            via_span_used = 1
                        else:
                            # No graph path — fall back to simple 3-point line
                            line_geom = QgsGeometry.fromPolylineXY(
                                [demand_pt, snap_d, snap_s, splitter_pt])
                            via_span_used = 1
                    elif snap_d:
                        line_geom = QgsGeometry.fromPolylineXY(
                            [demand_pt, snap_d, splitter_pt])
                        via_span_used = 1
                    else:
                        line_geom = QgsGeometry.fromPolylineXY([demand_pt, splitter_pt])
                else:
                    line_geom = QgsGeometry.fromPolylineXY([demand_pt, splitter_pt])

                # Create feature (length auto-calculated by virtual field)
                cable_feat = QgsFeature(drop_cable_layer.fields())
                cable_feat.setGeometry(line_geom)
                cable_feat.setAttributes([
                    cable_id,
                    int(group_id),
                    int(demand_point.id()),
                    drop_fiber_count,
                    drop_fiber_size,
                    via_span_used,
                    line_geom.length(),  # Cartesian CRS units — used by renderer
                    zone_by_group.get(int(group_id), -1),  # zone_id
                ])
                
                cable_features.append(cable_feat)
                
                # Track connections per group
                if group_id not in connections_by_group:
                    connections_by_group[group_id] = 0
                connections_by_group[group_id] += 1
                
                cable_id += 1
            
            self.log_message(f"Demand point groups found: {sorted(groups_found)}")
            self.log_message(f"Connections per group: {dict(sorted(connections_by_group.items()))}")
            if skipped_no_group > 0:
                self.log_message(f"Warning: {skipped_no_group} demand points had no group_id field")
            if skipped_no_splitter > 0:
                self.log_message(f"Warning: {skipped_no_splitter} demand points had no matching splitter")
                self.log_message(f"  Splitter groups: {sorted(splitters_by_group.keys())}")
                self.log_message(f"  Demand groups:   {sorted(groups_found)}")
            
            if len(cable_features) == 0:
                self.log_message("ERROR: No drop cables were created!")
                self.log_message("Please check that:")
                self.log_message("  1. Demand points have group_8, group_16, group_128, or group_100 field")
                self.log_message("  2. Splitters have matching group_id values")
                return
            
            # Add features to layer
            provider.addFeatures(cable_features)
            drop_cable_layer.updateExtents()
            
            # Apply rule-based symbology using stored cable_length field:
            #   cable_length > VIA_SPAN_THRESHOLD  → neon orange solid (warning)
            #   cable_length <= VIA_SPAN_THRESHOLD → red dashed (normal)
            # Use cookbook-style construction: renderer from default sym, then replace rules
            renderer = QgsRuleBasedRenderer(
                QgsLineSymbol.createSimple({'color': '220,0,0', 'width': '0.5', 'line_style': 'dash'}))
            root_rule = renderer.rootRule()
            for _r in root_rule.children()[:]:
                root_rule.removeChild(_r)
            rule_warn = QgsRuleBasedRenderer.Rule(
                QgsLineSymbol.createSimple({'color': '255,140,0', 'width': '0.8', 'line_style': 'solid'}))
            rule_warn.setFilterExpression(f'"cable_length" > {VIA_SPAN_THRESHOLD}')
            rule_warn.setLabel('Drop >50 m (WARNING)')
            root_rule.appendChild(rule_warn)
            rule_normal = QgsRuleBasedRenderer.Rule(
                QgsLineSymbol.createSimple({'color': '220,0,0', 'width': '0.5', 'line_style': 'dash'}))
            rule_normal.setFilterExpression(f'"cable_length" <= {VIA_SPAN_THRESHOLD}')
            rule_normal.setLabel('Drop ≤50 m')
            root_rule.appendChild(rule_normal)
            drop_cable_layer.setRenderer(renderer)
            
            # Add layer to project
            QgsProject.instance().addMapLayer(drop_cable_layer)
            
            # Calculate total length from the added features (virtual field will be populated)
            total_length = 0
            over_warn = 0
            for feat in drop_cable_layer.getFeatures():
                fl = feat['length'] if feat['length'] else 0
                total_length += fl
                if fl > VIA_SPAN_THRESHOLD:
                    over_warn += 1
            
            avg_length = total_length / len(cable_features) if len(cable_features) > 0 else 0
            
            via_span_count = sum(
                1 for f in drop_cable_layer.getFeatures() if f['via_span'] == 1)
            direct_count = len(cable_features) - via_span_count

            self.log_message(f"\nCreated {len(cable_features)} drop cables")
            self._elapsed("Total time")
            self.log_message(f"Layer: '{drop_cable_layer.name()}'")
            self.log_message(f"Total cable length: {total_length:.2f} units")
            self.log_message(f"Average cable length: {avg_length:.2f} units")
            self.log_message(
                f"Direct (≤{VIA_SPAN_THRESHOLD:.0f} mu): {direct_count}  "
                f"Via-span (>{VIA_SPAN_THRESHOLD:.0f} mu): {via_span_count}")
            if over_warn > 0:
                self.log_message(
                    f"WARNING: {over_warn} cable(s) exceed {VIA_SPAN_THRESHOLD:.0f} m "
                    f"— shown in neon orange on map")
            self.log_message("Length field uses $length expression (auto-updates with geometry)")
            
        except Exception as e:
            self.log_message(f"ERROR generating drop cables: {str(e)}")
            import traceback
            self.log_message(traceback.format_exc())

    def on_generate_drop_ptp_clicked(self):
        """Generate straight-line (point-to-point) drop cables from each demand point directly to its splitter."""
        from qgis.core import (QgsVectorLayer, QgsFeature, QgsGeometry, QgsProject,
                               QgsField, QgsPointXY,
                               QgsUnitTypes,
                               QgsLineSymbol, QgsRuleBasedRenderer)
        from qgis.PyQt.QtCore import QVariant, QMetaType
        import math

        # Locate demand points layer
        demand_points_layer = None
        try:
            if self.demand_points_layer and not sip.isdeleted(self.demand_points_layer):
                demand_points_layer = self.demand_points_layer
        except:
            pass
        if not demand_points_layer:
            _dm_candidates = []
            for layer in QgsProject.instance().mapLayers().values():
                if isinstance(layer, QgsVectorLayer):
                    ln = layer.name().lower()
                    if 'demand points' in ln or 'demand_points' in ln:
                        _dm_candidates.append(layer)
            # Prefer point geometry layers; fall back to first match
            _pt_layers = [l for l in _dm_candidates if l.geometryType() == 0]
            if _pt_layers:
                demand_points_layer = _pt_layers[0]
            elif _dm_candidates:
                demand_points_layer = _dm_candidates[0]
        if not demand_points_layer:
            self.log_message("ERROR: Could not find demand points layer. Generate demand points first.")
            return

        # Locate splitter points layer
        splitter_points_layer = None
        try:
            if self.splitter_points_layer and not sip.isdeleted(self.splitter_points_layer):
                splitter_points_layer = self.splitter_points_layer
        except:
            pass
        if not splitter_points_layer:
            for layer in QgsProject.instance().mapLayers().values():
                if isinstance(layer, QgsVectorLayer):
                    if 'splitter' in layer.name().lower() and layer.geometryType() == 0:
                        splitter_points_layer = layer
                        break
        if not splitter_points_layer:
            self.log_message("ERROR: Could not find splitter points layer. Generate splitter points first.")
            return

        self.log_message(f"\n=== Generating Drop Cables PTP ===")
        self.log_message(f"Demand points: '{demand_points_layer.name()}'")
        self.log_message(f"Splitters:     '{splitter_points_layer.name()}'")

        try:
            crs = demand_points_layer.crs().authid()

            # Remove existing PTP layer if present
            for layer in list(QgsProject.instance().mapLayers().values()):
                if isinstance(layer, QgsVectorLayer) and layer.name() == "Drop Cables PTP":
                    QgsProject.instance().removeMapLayer(layer.id())
                    break

            # Create layer
            drop_ptp_layer = QgsVectorLayer(f"LineString?crs={crs}", "Drop Cables PTP", "memory")
            provider = drop_ptp_layer.dataProvider()
            provider.addAttributes([
                QgsField('cable_id', QMetaType.Type.Int),
                QgsField('group_id', QMetaType.Type.Int),
                QgsField('demand_id', QMetaType.Type.Int),
                QgsField('fiber_count', QMetaType.Type.Int),
                QgsField('fiber_size', QMetaType.Type.QString),
                QgsField('via_span', QMetaType.Type.Int),      # always 0 for PTP
                QgsField('cable_length', QMetaType.Type.Double),   # Cartesian CRS-unit length
                QgsField('zone_id', QMetaType.Type.Int),      # aggregation zone membership
            ])
            drop_ptp_layer.updateFields()

            # Virtual length field
            from qgis.core import QgsExpression
            vf = QgsField('length', QMetaType.Type.Double)
            vf.setLength(10)
            vf.setPrecision(2)
            drop_ptp_layer.addExpressionField('$length', vf)

            drop_fiber_count = get_cable_profile(1, PROFILE_TYPE_DEFAULT)
            drop_fiber_size = format_cable_profile(drop_fiber_count)
            self.log_message(f"Drop cable profile: {drop_fiber_size}")

            # Index splitters by group_id; also build zone lookup (group_id -> zone_id)
            splitters_by_group = {}
            zone_by_group = {}
            _ptp_sp_has_zone = 'zone_id' in [f.name() for f in splitter_points_layer.fields()]
            for sp in splitter_points_layer.getFeatures():
                gid = sp['group_id']
                sg = sp.geometry()
                if sg and not sg.isEmpty():
                    splitters_by_group[gid] = sg.asPoint()
                if _ptp_sp_has_zone and gid is not None:
                    _zv = sp['zone_id']
                    zone_by_group[gid] = int(_zv) if _zv is not None else -1

            # Threshold for colour warning (same units logic as lashed)
            crs_units = demand_points_layer.crs().mapUnits()
            is_geographic = (crs_units == QgsUnitTypes.DistanceDegrees)
            PTP_WARN_THRESHOLD = 0.00045 if is_geographic else 50.0

            demand_fields = [f.name() for f in demand_points_layer.fields()]
            cable_features = []
            cable_id = 1
            skipped_no_group = 0
            skipped_no_splitter = 0
            groups_found = set()
            connections_by_group = {}
            total_demand = demand_points_layer.featureCount()
            self.log_message(f"Connecting {total_demand} demand points (straight line)...")
            self._start_timer()

            for idx, demand_point in enumerate(demand_points_layer.getFeatures()):
                self._progress(idx + 1, total_demand, 'PTP drops')
                dg = demand_point.geometry()
                if not dg or dg.isEmpty():
                    continue
                # Use centroid for polygon/line sources so non-point layers work correctly
                if dg.type() == 0:  # Point
                    demand_pt = dg.asPoint()
                else:
                    demand_pt = dg.centroid().asPoint()

                # Resolve group_id
                group_id = None
                for fn in ['group_8', 'group_16', 'group_128', 'group_100', 'batch_id']:
                    if fn in demand_fields:
                        group_id = demand_point[fn]
                        if group_id is not None:
                            groups_found.add(group_id)
                        break
                if group_id is None:
                    skipped_no_group += 1
                    continue
                if group_id not in splitters_by_group:
                    skipped_no_splitter += 1
                    continue

                splitter_pt = splitters_by_group[group_id]
                line_geom = QgsGeometry.fromPolylineXY([demand_pt, splitter_pt])

                feat = QgsFeature(drop_ptp_layer.fields())
                feat.setGeometry(line_geom)
                feat.setAttributes([
                    cable_id,
                    int(group_id),
                    int(demand_point.id()),
                    drop_fiber_count,
                    drop_fiber_size,
                    0,                    # via_span always 0
                    line_geom.length(),   # Cartesian CRS units
                    zone_by_group.get(int(group_id), -1),  # zone_id
                ])
                cable_features.append(feat)
                connections_by_group[group_id] = connections_by_group.get(group_id, 0) + 1
                cable_id += 1

            if skipped_no_group:
                self.log_message(f"Warning: {skipped_no_group} demand points had no group_id field")
            if skipped_no_splitter:
                self.log_message(f"Warning: {skipped_no_splitter} demand points had no matching splitter")

            if not cable_features:
                self.log_message("ERROR: No PTP drop cables created — check group_id / splitter alignment.")
                return

            provider.addFeatures(cable_features)
            drop_ptp_layer.updateExtents()

            # Rule-based renderer: blue normal, orange warning for long cables
            renderer = QgsRuleBasedRenderer(
                QgsLineSymbol.createSimple({'color': '0,100,200', 'width': '0.5', 'line_style': 'solid'}))
            root_rule = renderer.rootRule()
            for _r in root_rule.children()[:]:
                root_rule.removeChild(_r)
            rule_warn = QgsRuleBasedRenderer.Rule(
                QgsLineSymbol.createSimple({'color': '255,140,0', 'width': '0.8', 'line_style': 'solid'}))
            rule_warn.setFilterExpression(f'"cable_length" > {PTP_WARN_THRESHOLD}')
            rule_warn.setLabel('PTP Drop >50 m (WARNING)')
            root_rule.appendChild(rule_warn)
            rule_normal = QgsRuleBasedRenderer.Rule(
                QgsLineSymbol.createSimple({'color': '0,100,200', 'width': '0.5', 'line_style': 'solid'}))
            rule_normal.setFilterExpression(f'"cable_length" <= {PTP_WARN_THRESHOLD}')
            rule_normal.setLabel('PTP Drop ≤50 m')
            root_rule.appendChild(rule_normal)
            drop_ptp_layer.setRenderer(renderer)

            QgsProject.instance().addMapLayer(drop_ptp_layer)

            # Summary stats
            total_length = sum(f['cable_length'] or 0 for f in drop_ptp_layer.getFeatures())
            over_warn = sum(1 for f in drop_ptp_layer.getFeatures() if (f['cable_length'] or 0) > PTP_WARN_THRESHOLD)
            avg_length = total_length / len(cable_features) if cable_features else 0

            self.log_message(f"\nCreated {len(cable_features)} PTP drop cables")
            self._elapsed("Total time")
            self.log_message(f"Layer: '{drop_ptp_layer.name()}'")
            self.log_message(f"Total cable length: {total_length:.2f} units")
            self.log_message(f"Average cable length: {avg_length:.2f} units")
            self.log_message(f"Connections per group: {dict(sorted(connections_by_group.items()))}")
            if over_warn:
                self.log_message(
                    f"WARNING: {over_warn} cable(s) exceed {PTP_WARN_THRESHOLD:.0f} m — shown in neon orange")

        except Exception as e:
            self.log_message(f"ERROR generating PTP drop cables: {str(e)}")
            import traceback
            self.log_message(traceback.format_exc())

    def on_manual_override_clicked(self):
        """Open Manual Override dialog — reassign splitter zones or demand point group/zone."""
        from qgis.PyQt.QtWidgets import (QDialog, QVBoxLayout, QHBoxLayout, QLabel,
                                          QListWidget, QAbstractItemView,
                                          QSpinBox, QPushButton, QComboBox,
                                          QGroupBox, QFormLayout, QFrame,
                                          QTabWidget, QWidget)
        from qgis.PyQt.QtCore import Qt
        from qgis.core import QgsProject, QgsVectorLayer
        import sip, math

        # ---- Locate Splitter Points layer ----
        splitter_layer = None
        try:
            if self.splitter_points_layer and not sip.isdeleted(self.splitter_points_layer):
                splitter_layer = self.splitter_points_layer
        except Exception:
            pass
        if not splitter_layer:
            for _lyr in QgsProject.instance().mapLayers().values():
                if isinstance(_lyr, QgsVectorLayer) and 'splitter' in _lyr.name().lower() and _lyr.geometryType() == 0:
                    splitter_layer = _lyr
                    break
        if not splitter_layer:
            self.log_message("ERROR: No Splitter Points layer found. Generate splitter points first.")
            return

        sp_field_names = [f.name() for f in splitter_layer.fields()]
        if 'zone_id' not in sp_field_names:
            self.log_message("WARNING: Splitter layer has no 'zone_id' field. Re-generate splitter points first.")
            return

        # ---- Build splitter data list ----
        splitter_data = []
        for _feat in splitter_layer.getFeatures():
            _gid = _feat['group_id']
            _zid = _feat['zone_id']
            _dc  = _feat['drop_count'] if 'drop_count' in sp_field_names else 0
            _pt  = _feat.geometry().asPoint() if (_feat.geometry() and not _feat.geometry().isEmpty()) else None
            splitter_data.append({
                'fid':        _feat.id(),
                'group_id':   _gid,
                'zone_id':    int(_zid) if _zid is not None else -1,
                'drop_count': int(_dc)  if _dc  is not None else 0,
                'x':          _pt.x()  if _pt  else 0.0,
                'y':          _pt.y()  if _pt  else 0.0,
            })
        if not splitter_data:
            self.log_message("ERROR: Splitter Points layer is empty.")
            return

        # ---- Locate Demand Points layer + build demand_data ----
        _dem_layer = None
        _dp_link = None   # group link field (e.g. group_8)
        _dp_zi   = -1     # zone_id field index
        _dp_zni  = -1     # zone_name field index
        try:
            if self.demand_points_layer and not sip.isdeleted(self.demand_points_layer):
                _dem_layer = self.demand_points_layer
        except Exception:
            pass
        if not _dem_layer:
            for _lyr in QgsProject.instance().mapLayers().values():
                if isinstance(_lyr, QgsVectorLayer):
                    _ln = _lyr.name().lower()
                    if 'demand points' in _ln or 'demand_points' in _ln:
                        _dem_layer = _lyr
                        break
        demand_data = []
        if _dem_layer:
            _dfnames = [f.name() for f in _dem_layer.fields()]
            _dp_link = next((fn for fn in ['group_8', 'group_16', 'group_128', 'group_100', 'batch_id']
                              if fn in _dfnames), None)
            _dp_zi   = _dem_layer.fields().indexFromName('zone_id')   if 'zone_id'   in _dfnames else -1
            _dp_zni  = _dem_layer.fields().indexFromName('zone_name') if 'zone_name' in _dfnames else -1
            if _dp_link:
                for _f in _dem_layer.getFeatures():
                    _gid = _f[_dp_link]
                    _zid = _f['zone_id'] if _dp_zi >= 0 else None
                    _pt  = _f.geometry().asPoint() if (_f.geometry() and not _f.geometry().isEmpty()) else None
                    demand_data.append({
                        'fid':      _f.id(),
                        'group_id': _gid,
                        'zone_id':  int(_zid) if _zid is not None else -1,
                        'x':        _pt.x() if _pt else 0.0,
                        'y':        _pt.y() if _pt else 0.0,
                    })

        # ---- Prevent second instance ----
        if getattr(self, '_override_dlg', None) and self._override_dlg.isVisible():
            self._override_dlg.raise_()
            self._override_dlg.activateWindow()
            return

        # ================================================================
        # Build dialog
        # ================================================================
        dlg = QDialog(self)
        self._override_dlg = dlg
        dlg.setWindowTitle("Manual Override")
        dlg.setMinimumWidth(500)
        dlg.setMinimumHeight(580)
        dlg.setModal(False)
        dlg.setWindowFlags(dlg.windowFlags() | Qt.WindowStaysOnTopHint)
        layout = QVBoxLayout(dlg)
        layout.setSpacing(6)

        # Shared map-pick toggle (top of dialog)
        pick_row = QHBoxLayout()
        btn_pick = QPushButton("Map Picking: ON")
        btn_pick.setCheckable(True)
        btn_pick.setChecked(True)
        btn_pick.setStyleSheet(
            "QPushButton:checked  { background-color: #4CAF50; color: white; font-weight: bold; }"
            "QPushButton:!checked { background-color: #f0ad4e; color: black; }")
        btn_pick.setToolTip("Click on the map to select the nearest feature on the active tab.")
        pick_row.addStretch()
        pick_row.addWidget(btn_pick)
        layout.addLayout(pick_row)

        # Tab widget
        tab_widget = QTabWidget()
        layout.addWidget(tab_widget)

        # ----------------------------------------------------------------
        # TAB 0 — Splitter Zones
        # ----------------------------------------------------------------
        tab_sp = QWidget()
        sp_layout = QVBoxLayout(tab_sp)
        sp_layout.setSpacing(6)

        sp_layout.addWidget(QLabel("<b>Select splitters and reassign them to a new PON zone.</b>"))
        sp_layout.addWidget(QLabel("Click splitters on the map or use Ctrl/Shift+click on the list."))

        list_widget = QListWidget()
        list_widget.setSelectionMode(QAbstractItemView.ExtendedSelection)
        list_widget.setMinimumHeight(160)
        for sd in splitter_data:
            list_widget.addItem(f"Group {sd['group_id']}   |   Zone {sd['zone_id']}   |   {sd['drop_count']} drops")
        sp_layout.addWidget(list_widget)

        sp_sel_row = QHBoxLayout()
        btn_select_all = QPushButton("Select All")
        btn_clear_sel  = QPushButton("Clear Selection")
        btn_zoom_sel   = QPushButton("Zoom to Selected")
        btn_zoom_sel.setToolTip("Zoom the map canvas to the selected splitters")
        sp_sel_row.addWidget(btn_select_all)
        sp_sel_row.addWidget(btn_clear_sel)
        sp_sel_row.addWidget(btn_zoom_sel)
        sp_sel_row.addStretch()
        sp_layout.addLayout(sp_sel_row)

        summary_box = QGroupBox("Selection Summary")
        form = QFormLayout(summary_box)
        lbl_sel_count = QLabel("0")
        lbl_sel_zones = QLabel("—")
        lbl_sel_drops = QLabel("0")
        form.addRow("Selected:",      lbl_sel_count)
        form.addRow("Current Zones:", lbl_sel_zones)
        form.addRow("Total Drops:",   lbl_sel_drops)
        sp_layout.addWidget(summary_box)

        nz_box = QGroupBox("New Zone Assignment")
        nz_row = QHBoxLayout(nz_box)
        nz_row.addWidget(QLabel("New Zone ID:"))
        spin = QSpinBox()
        spin.setMinimum(0)
        spin.setMaximum(9999)
        nz_row.addWidget(spin)
        nz_row.addStretch()
        btn_apply_sp = QPushButton("Apply Zone Change")
        btn_apply_sp.setDefault(True)
        btn_undo_sp = QPushButton("↩ Undo")
        btn_undo_sp.setEnabled(False)
        btn_undo_sp.setToolTip("Undo the last applied change")
        nz_row.addWidget(btn_apply_sp)
        nz_row.addWidget(btn_undo_sp)
        sp_layout.addWidget(nz_box)

        tab_widget.addTab(tab_sp, "Splitter Zones")

        # ----------------------------------------------------------------
        # TAB 1 — Demand Points
        # ----------------------------------------------------------------
        tab_dp = QWidget()
        dp_layout = QVBoxLayout(tab_dp)
        dp_layout.setSpacing(6)

        if demand_data:
            dp_layout.addWidget(QLabel("<b>Select demand points and reassign them to a different splitter.</b>"))
            dp_layout.addWidget(QLabel("Click demand points on the map or use Ctrl/Shift+click on the list."))

            dem_list = QListWidget()
            dem_list.setSelectionMode(QAbstractItemView.ExtendedSelection)
            dem_list.setMinimumHeight(160)
            for dd in demand_data:
                dem_list.addItem(f"DP {dd['fid']}   |   Group {dd['group_id']}   |   Zone {dd['zone_id']}")
            dp_layout.addWidget(dem_list)

            dp_sel_row = QHBoxLayout()
            btn_dp_select_all = QPushButton("Select All")
            btn_dp_clear_sel  = QPushButton("Clear Selection")
            dp_sel_row.addWidget(btn_dp_select_all)
            dp_sel_row.addWidget(btn_dp_clear_sel)
            dp_sel_row.addStretch()
            dp_layout.addLayout(dp_sel_row)

            dp_info_box = QGroupBox("Selection Info")
            dp_form = QFormLayout(dp_info_box)
            lbl_dp_count = QLabel("0")
            lbl_dp_groups = QLabel("—")
            dp_form.addRow("Selected:",        lbl_dp_count)
            dp_form.addRow("Current Groups:",  lbl_dp_groups)
            dp_layout.addWidget(dp_info_box)

            tgt_box = QGroupBox("Target Splitter")
            tgt_form = QFormLayout(tgt_box)

            # Manual group ID entry
            from qgis.PyQt.QtWidgets import QSpinBox
            spin_grp = QSpinBox()
            spin_grp.setMinimum(1)
            spin_grp.setMaximum(99999)
            spin_grp.setValue(splitter_data[0]['group_id'] if splitter_data else 1)
            spin_grp.setToolTip("Type or select the target Group ID directly")
            tgt_form.addRow("Group ID (manual):", spin_grp)

            combo_target = QComboBox()
            combo_target.setMinimumWidth(300)
            for sd in splitter_data:
                combo_target.addItem(f"Group {sd['group_id']}  |  Zone {sd['zone_id']}  |  {sd['drop_count']} drops")
            tgt_form.addRow("Or pick from list:", combo_target)

            # Sync spin_grp ↔ combo_target
            def _combo_to_spin(idx):
                if 0 <= idx < len(splitter_data):
                    spin_grp.blockSignals(True)
                    spin_grp.setValue(splitter_data[idx]['group_id'])
                    spin_grp.blockSignals(False)

            def _spin_to_combo():
                gid = spin_grp.value()
                for i, sd in enumerate(splitter_data):
                    if sd['group_id'] == gid:
                        combo_target.blockSignals(True)
                        combo_target.setCurrentIndex(i)
                        combo_target.blockSignals(False)
                        return

            combo_target.currentIndexChanged.connect(_combo_to_spin)
            spin_grp.valueChanged.connect(_spin_to_combo)
            dp_layout.addWidget(tgt_box)

            dp_btn_row = QHBoxLayout()
            btn_apply_dp = QPushButton("Apply Demand Reassignment")
            btn_undo_dp  = QPushButton("↩ Undo")
            btn_undo_dp.setEnabled(False)
            btn_undo_dp.setToolTip("Undo the last applied change")
            dp_btn_row.addWidget(btn_apply_dp)
            dp_btn_row.addWidget(btn_undo_dp)
            dp_btn_row.addStretch()
            dp_layout.addLayout(dp_btn_row)

            regen_row = QHBoxLayout()
            btn_regen_drops = QPushButton("Regenerate Drops")
            btn_regen_drops.setToolTip("Re-run Generate Drops PTP after demand point reassignment")
            btn_regen_drops.setStyleSheet("QPushButton { background-color: #d9534f; color: white; font-weight: bold; }")
            regen_row.addWidget(btn_regen_drops)
            regen_row.addStretch()
            dp_layout.addLayout(regen_row)
        else:
            dp_layout.addWidget(QLabel("No Demand Points layer found.\nGenerate demand points first."))
            dem_list      = None
            combo_target  = None
            btn_apply_dp  = None
            btn_undo_dp   = None

        tab_widget.addTab(tab_dp, "Demand Points")

        # ----------------------------------------------------------------
        # TAB 2 — Add Splitter Point
        # ----------------------------------------------------------------
        tab_ns = QWidget()
        ns_layout = QVBoxLayout(tab_ns)
        ns_layout.setSpacing(6)

        ns_layout.addWidget(QLabel("<b>Manually place a new splitter point on the map.</b>"))
        ns_layout.addWidget(QLabel(
            "Click on the map to capture coordinates, then confirm attributes and click Add."))

        # Captured location display
        ns_loc_box = QGroupBox("Captured Location")
        ns_loc_form = QFormLayout(ns_loc_box)
        lbl_ns_x = QLabel("—")
        lbl_ns_y = QLabel("—")
        ns_loc_form.addRow("X (Easting):", lbl_ns_x)
        ns_loc_form.addRow("Y (Northing):", lbl_ns_y)
        ns_layout.addWidget(ns_loc_box)

        # Auto-detected / editable attributes
        ns_attr_box = QGroupBox("Splitter Attributes")
        ns_attr_form = QFormLayout(ns_attr_box)

        _max_grp = max((sd['group_id'] for sd in splitter_data), default=0)
        from qgis.PyQt.QtWidgets import QSpinBox as _NSSpinBox
        spin_ns_zone = _NSSpinBox()
        spin_ns_zone.setMinimum(0)
        spin_ns_zone.setMaximum(99999)
        spin_ns_zone.setValue(0)
        spin_ns_zone.setToolTip("Auto-detected from PON Zone polygon; editable")

        spin_ns_group = _NSSpinBox()
        spin_ns_group.setMinimum(1)
        spin_ns_group.setMaximum(999999)
        spin_ns_group.setValue(_max_grp + 1)
        spin_ns_group.setToolTip("Suggested next group ID; editable")

        spin_ns_drops = _NSSpinBox()
        spin_ns_drops.setMinimum(0)
        spin_ns_drops.setMaximum(9999)
        spin_ns_drops.setValue(0)
        spin_ns_drops.setToolTip("Number of drop cables (demand points) for this splitter")

        ns_attr_form.addRow("Zone ID (auto):", spin_ns_zone)
        ns_attr_form.addRow("Group ID:",       spin_ns_group)
        ns_attr_form.addRow("Drop Count:",     spin_ns_drops)
        ns_layout.addWidget(ns_attr_box)

        ns_btn_row = QHBoxLayout()
        btn_add_sp  = QPushButton("Add Splitter Point")
        btn_add_sp.setEnabled(False)
        btn_add_sp.setStyleSheet(
            "QPushButton:enabled  { background-color: #4CAF50; color: white; font-weight: bold; }"
            "QPushButton:disabled { background-color: #cccccc; color: #888; }")
        btn_clear_ns = QPushButton("Clear")
        ns_btn_row.addWidget(btn_add_sp)
        ns_btn_row.addWidget(btn_clear_ns)
        ns_btn_row.addStretch()
        ns_layout.addLayout(ns_btn_row)
        ns_layout.addStretch()

        # Container for the pending point coords
        _ns_point = [None]   # [QgsPointXY or None]

        def _clear_ns():
            _ns_point[0] = None
            lbl_ns_x.setText("—")
            lbl_ns_y.setText("—")
            btn_add_sp.setEnabled(False)
            spin_ns_zone.setValue(0)
            spin_ns_group.setValue(max((sd['group_id'] for sd in splitter_data), default=0) + 1)
            spin_ns_drops.setValue(0)

        btn_clear_ns.clicked.connect(_clear_ns)

        def _do_add_splitter():
            if not _ns_point[0]:
                status_lbl.setText("<font color='red'>No point captured. Click the map first.</font>")
                return
            from qgis.core import QgsFeature, QgsGeometry, QgsPointXY
            _pt = _ns_point[0]
            _gid  = spin_ns_group.value()
            _zid  = spin_ns_zone.value()
            _dcnt = spin_ns_drops.value()

            # Guard: duplicate group_id
            if any(sd['group_id'] == _gid for sd in splitter_data):
                status_lbl.setText(
                    f"<font color='red'>Group ID {_gid} already exists. Choose a different Group ID.</font>")
                return

            new_feat = QgsFeature(splitter_layer.fields())
            new_feat.setGeometry(QgsGeometry.fromPointXY(QgsPointXY(_pt.x(), _pt.y())))
            new_feat.setAttributes([
                _gid,          # fid
                str(_gid),     # ID
                _gid,          # group_id
                _zid,          # zone_id
                _dcnt,         # drop_count
            ])

            splitter_layer.startEditing()
            ok = splitter_layer.addFeature(new_feat)
            splitter_layer.commitChanges()
            splitter_layer.triggerRepaint()

            if ok:
                # Update in-memory list so tab 0 reflects the new splitter
                _new_fid = new_feat.id()
                splitter_data.append({
                    'fid':        _new_fid,
                    'group_id':   _gid,
                    'zone_id':    _zid,
                    'drop_count': _dcnt,
                    'x':          _pt.x(),
                    'y':          _pt.y(),
                })
                list_widget.addItem(
                    f"Group {_gid}   |   Zone {_zid}   |   {_dcnt} drops")
                # Update combo in demand tab
                if demand_data:
                    combo_target.addItem(
                        f"Group {_gid}  |  Zone {_zid}  |  {_dcnt} drops")

                status_lbl.setText(
                    f"<font color='green'><b>✓ Splitter added:</b> "
                    f"Group {_gid} | Zone {_zid} | {_dcnt} drops at "
                    f"({_pt.x():.1f}, {_pt.y():.1f})</font>")
                self.log_message(
                    f"Manual Override — new splitter: Group {_gid}, Zone {_zid}, "
                    f"drops={_dcnt}, pos=({_pt.x():.2f}, {_pt.y():.2f})")
                _clear_ns()
            else:
                status_lbl.setText("<font color='red'>Failed to add splitter feature to layer.</font>")

        btn_add_sp.clicked.connect(_do_add_splitter)

        # ---- Move / Edit / Regenerate buttons ----
        action_btn_row = QHBoxLayout()
        btn_move_sp = QPushButton("Move Splitter")
        btn_move_sp.setCheckable(True)
        btn_move_sp.setStyleSheet(
            "QPushButton:checked  { background-color: #e67e22; color: white; font-weight: bold; }"
            "QPushButton:!checked { background-color: #ecf0f1; color: black; }")
        btn_move_sp.setToolTip(
            "Click to enable: then click a splitter on the map to select it, "
            "then click the new location to move it there.")

        btn_edit_sp = QPushButton("Edit Splitter")
        btn_edit_sp.setCheckable(True)
        btn_edit_sp.setStyleSheet(
            "QPushButton:checked  { background-color: #2980b9; color: white; font-weight: bold; }"
            "QPushButton:!checked { background-color: #ecf0f1; color: black; }")
        btn_edit_sp.setToolTip(
            "Click to enable: then click a splitter on the map to load its attributes, "
            "edit the values above, then click Apply Edit to save.")

        btn_regen_drops_sp = QPushButton("Regenerate Drops")
        btn_regen_drops_sp.setStyleSheet(
            "QPushButton { background-color: #d9534f; color: white; font-weight: bold; }")
        btn_regen_drops_sp.setToolTip("Re-run Generate Drops PTP to update drop cables from splitters to demand points.")

        action_btn_row.addWidget(btn_move_sp)
        action_btn_row.addWidget(btn_edit_sp)
        action_btn_row.addWidget(btn_regen_drops_sp)
        action_btn_row.addStretch()
        ns_layout.addLayout(action_btn_row)

        # Apply Edit button (hidden until edit mode is active)
        edit_apply_row = QHBoxLayout()
        btn_apply_edit_sp = QPushButton("Apply Edit")
        btn_apply_edit_sp.setEnabled(False)
        btn_apply_edit_sp.setStyleSheet(
            "QPushButton:enabled  { background-color: #27ae60; color: white; font-weight: bold; }"
            "QPushButton:disabled { background-color: #cccccc; color: #888; }")
        btn_apply_edit_sp.setToolTip("Save the edited attributes back to the selected splitter.")
        edit_apply_row.addWidget(btn_apply_edit_sp)
        edit_apply_row.addStretch()
        ns_layout.addLayout(edit_apply_row)

        _edit_state = {"fid": None}   # fid of splitter being edited

        def _apply_splitter_edit():
            fid = _edit_state["fid"]
            if fid is None:
                return
            new_zid  = spin_ns_zone.value()
            new_gid  = spin_ns_group.value()
            new_dcnt = spin_ns_drops.value()

            # Read old values before editing so we can detect zone changes
            fnames = [f.name() for f in splitter_layer.fields()]
            old_feat = splitter_layer.getFeature(fid)
            old_zid  = int(old_feat["zone_id"]  or 0) if "zone_id"  in fnames else new_zid
            old_gid  = old_feat["group_id"] if "group_id" in fnames else new_gid

            splitter_layer.startEditing()
            if "zone_id"    in fnames: splitter_layer.changeAttributeValue(fid, fnames.index("zone_id"),    new_zid)
            if "group_id"   in fnames: splitter_layer.changeAttributeValue(fid, fnames.index("group_id"),   new_gid)
            if "drop_count" in fnames: splitter_layer.changeAttributeValue(fid, fnames.index("drop_count"), new_dcnt)
            splitter_layer.commitChanges()
            splitter_layer.removeSelection()
            splitter_layer.triggerRepaint()

            # --- Cascade zone change to PON Zone boundary polygon -----------
            # Only needed when zone_id actually changed.
            if old_zid != new_zid:
                # Determine which group_id to look up demand points for.
                # Use new_gid (just edited) which is the authoritative group link.
                _edit_grp = new_gid

                # Locate demand / grouped layer and its group link field
                _el = None
                _el_link = None
                import sip as _sip2
                try:
                    if self.demand_points_layer and not _sip2.isdeleted(self.demand_points_layer):
                        _el = self.demand_points_layer
                except Exception:
                    pass
                if not _el:
                    for _lx in QgsProject.instance().mapLayers().values():
                        if isinstance(_lx, QgsVectorLayer):
                            _ln = _lx.name().lower()
                            if 'demand points' in _ln or 'demand_points' in _ln:
                                _el = _lx
                                break
                if _el:
                    _efnames = [f.name() for f in _el.fields()]
                    _el_link = next((fn for fn in ['group_8', 'group_16', 'group_128',
                                                    'group_100', 'batch_id']
                                      if fn in _efnames), None)
                    # Also update zone_id on demand points for this group
                    _el_zi = _el.fields().indexFromName('zone_id') if 'zone_id' in _efnames else -1
                    _el_zni = _el.fields().indexFromName('zone_name') if 'zone_name' in _efnames else -1
                    if _el_link and _el_zi >= 0:
                        _el.startEditing()
                        for _ef in _el.getFeatures():
                            if _ef[_el_link] == _edit_grp:
                                _el.changeAttributeValue(_ef.id(), _el_zi, new_zid)
                                if _el_zni >= 0:
                                    _el.changeAttributeValue(_ef.id(), _el_zni, f"Zone {new_zid}")
                        _el.commitChanges()
                        _el.triggerRepaint()

                # Rebuild PON Zone boundary polygons for old_zid and new_zid
                _src_lyr  = _el if (_el and _el_link) else None
                _src_link = _el_link

                # If demand layer not usable, fall back to grouped_layer
                if not _src_lyr:
                    _gl = getattr(self, 'grouped_layer', None)
                    try:
                        if _gl and not _sip2.isdeleted(_gl):
                            _gfn = [f.name() for f in _gl.fields()]
                            _gl_link = next((fn for fn in ['group_8', 'group_16', 'group_128',
                                                            'group_100', 'batch_id']
                                              if fn in _gfn), None)
                            if _gl_link:
                                _src_lyr  = _gl
                                _src_link = _gl_link
                    except Exception:
                        pass

                if _src_lyr and _src_link:
                    # Build zone→groups mapping from the full splitter layer (post-edit)
                    _z2g_edit: dict = {}
                    for _sf2 in splitter_layer.getFeatures():
                        _z = int(_sf2["zone_id"] or 0) if "zone_id" in fnames else -1
                        _g = _sf2["group_id"] if "group_id" in fnames else None
                        if _g is not None:
                            _z2g_edit.setdefault(_z, set()).add(_g)

                    for _pon_lyr in QgsProject.instance().mapLayers().values():
                        if not (isinstance(_pon_lyr, QgsVectorLayer) and 'PON Zones' in _pon_lyr.name()):
                            continue
                        _pf = [f.name() for f in _pon_lyr.fields()]
                        if 'zone_id' not in _pf or 'unit_count' not in _pf:
                            continue
                        _uc_idx = _pon_lyr.fields().indexFromName('unit_count')
                        _pon_lyr.startEditing()
                        _old_found = False
                        _new_found = False
                        _del_fids  = []
                        for _pf2 in _pon_lyr.getFeatures():
                            _pzid = int(_pf2['zone_id'] or 0)
                            if _pzid == old_zid:
                                _old_found = True
                                _rem_grps = _z2g_edit.get(old_zid, set())
                                _rem_feats = [_ff for _ff in _src_lyr.getFeatures()
                                              if _ff[_src_link] in _rem_grps]
                                if _rem_feats:
                                    _oz_geom = self._build_zone_polygon(_src_lyr, _rem_feats)
                                    if not _oz_geom.isEmpty():
                                        _pon_lyr.changeGeometry(_pf2.id(), _oz_geom)
                                    new_uc = sum(1 for _ in _rem_feats)
                                    _pon_lyr.changeAttributeValue(_pf2.id(), _uc_idx, new_uc)
                                else:
                                    _del_fids.append(_pf2.id())
                            elif _pzid == new_zid:
                                _new_found = True
                                _new_grps = _z2g_edit.get(new_zid, set())
                                _nz_feats = [_ff for _ff in _src_lyr.getFeatures()
                                             if _ff[_src_link] in _new_grps]
                                if _nz_feats:
                                    _nz_geom = self._build_zone_polygon(_src_lyr, _nz_feats)
                                    if not _nz_geom.isEmpty():
                                        _pon_lyr.changeGeometry(_pf2.id(), _nz_geom)
                                    new_uc = sum(1 for _ in _nz_feats)
                                    _pon_lyr.changeAttributeValue(_pf2.id(), _uc_idx, new_uc)
                        if _del_fids:
                            _pon_lyr.deleteFeatures(_del_fids)
                        # Create new polygon if new zone has no existing polygon
                        if not _new_found:
                            _new_grps = _z2g_edit.get(new_zid, set())
                            _nz_feats = [_ff for _ff in _src_lyr.getFeatures()
                                         if _ff[_src_link] in _new_grps]
                            if _nz_feats:
                                from qgis.core import QgsFeature as _QFe
                                _nz_geom = self._build_zone_polygon(_src_lyr, _nz_feats)
                                if not _nz_geom.isEmpty():
                                    _nf = _QFe(_pon_lyr.fields())
                                    _nf.setGeometry(_nz_geom)
                                    _nf['zone_id']    = new_zid
                                    _nf['zone_name']  = f"Zone {new_zid}"
                                    _nf['unit_count'] = sum(1 for _ in _nz_feats)
                                    _pon_lyr.addFeature(_nf)
                        _pon_lyr.commitChanges()
                        _pon_lyr.triggerRepaint()
                        break

            status_lbl.setText(
                f"<font color='green'><b>✓ Splitter FID {fid} updated:</b> "
                f"Zone {new_zid} | Group {new_gid} | Drops {new_dcnt}</font>")
            _edit_state["fid"] = None
            btn_apply_edit_sp.setEnabled(False)
            btn_edit_sp.setChecked(False)
            _clear_ns()

        btn_apply_edit_sp.clicked.connect(_apply_splitter_edit)
        btn_regen_drops_sp.clicked.connect(lambda: self.on_generate_drop_ptp_clicked())

        # State for two-click move: [selected_fid, selected_geom]
        _move_state = [None, None]   # [fid, QgsGeometry snapshot]

        class _MoveSplitterTool(self.iface.mapCanvas().__class__.__bases__[0]):
            """Dummy base placeholder — replaced below."""
            pass

        from qgis.gui import QgsMapToolEmitPoint as _QMTEP
        from qgis.core import QgsGeometry as _QG, QgsPointXY as _QPXY

        class _MoveSplitterTool(_QMTEP):
            def __init__(self, canvas, state, layer, status, btn, prev_tool):
                super().__init__(canvas)
                self._state   = state
                self._layer   = layer
                self._status  = status
                self._btn     = btn
                self._prev    = prev_tool

            def canvasReleaseEvent(self, e):
                from qgis.core import QgsPointXY, QgsGeometry, QgsRectangle
                pt = self.toMapCoordinates(e.pos())
                if self._state[0] is None:
                    # Phase 1: find nearest splitter within a tolerance
                    tol = self.canvas().extent().width() * 0.01
                    rect = QgsRectangle(pt.x()-tol, pt.y()-tol, pt.x()+tol, pt.y()+tol)
                    best_fid, best_dist = None, float("inf")
                    for feat in self._layer.getFeatures():
                        g = feat.geometry()
                        if g and not g.isEmpty():
                            d = g.distance(QgsGeometry.fromPointXY(pt))
                            if d < best_dist:
                                best_dist, best_fid = d, feat.id()
                    if best_fid is not None:
                        self._state[0] = best_fid
                        self._state[1] = QgsGeometry(self._layer.getFeature(best_fid).geometry())
                        self._layer.selectByIds([best_fid])
                        self._status.setText(
                            f"<font color='orange'>Splitter FID {best_fid} selected — "
                            f"now click the new location.</font>")
                    else:
                        self._status.setText(
                            "<font color='red'>No splitter found near click. Try again.</font>")
                else:
                    # Phase 2: move selected splitter to new location
                    fid = self._state[0]
                    self._layer.startEditing()
                    self._layer.changeGeometry(fid, QgsGeometry.fromPointXY(pt))
                    self._layer.commitChanges()
                    self._layer.removeSelection()
                    self._layer.triggerRepaint()
                    self._status.setText(
                        f"<font color='green'><b>✓ Splitter moved</b> to "
                        f"({pt.x():.1f}, {pt.y():.1f})</font>")
                    self._state[0] = None
                    self._state[1] = None
                    # Deactivate move mode
                    self._btn.setChecked(False)
                    self.canvas().setMapTool(self._prev)

        _mv_prev = {"tool": None}

        def _toggle_move(checked):
            if checked:
                _mv_prev["tool"] = self.iface.mapCanvas().mapTool()
                tool = _MoveSplitterTool(
                    self.iface.mapCanvas(),
                    _move_state,
                    splitter_layer,
                    status_lbl,
                    btn_move_sp,
                    _mv_prev["tool"])
                self.iface.mapCanvas().setMapTool(tool)
                # store so we can clean up on dialog close
                dlg._move_tool = tool
                status_lbl.setText(
                    "<font color='orange'>Move mode ON — click a splitter to select it.</font>")
            else:
                _move_state[0] = None
                _move_state[1] = None
                splitter_layer.removeSelection()
                if _mv_prev["tool"]:
                    self.iface.mapCanvas().setMapTool(_mv_prev["tool"])
                status_lbl.setText("Move mode OFF.")

        btn_move_sp.toggled.connect(_toggle_move)

        # ---- Edit Splitter map tool ----
        class _EditSplitterTool(_QMTEP):
            def __init__(self, canvas, edit_state, layer, status, btn,
                         spin_zone, spin_group, spin_drops, btn_apply, prev_tool):
                super().__init__(canvas)
                self._edit_state = edit_state
                self._layer      = layer
                self._status     = status
                self._btn        = btn
                self._spin_zone  = spin_zone
                self._spin_group = spin_group
                self._spin_drops = spin_drops
                self._btn_apply  = btn_apply
                self._prev       = prev_tool

            def canvasReleaseEvent(self, e):
                from qgis.core import QgsGeometry, QgsPointXY
                pt = self.toMapCoordinates(e.pos())
                # Find nearest splitter
                best_fid, best_dist = None, float("inf")
                for feat in self._layer.getFeatures():
                    g = feat.geometry()
                    if g and not g.isEmpty():
                        d = g.distance(QgsGeometry.fromPointXY(pt))
                        if d < best_dist:
                            best_dist, best_fid = d, feat.id()
                if best_fid is None:
                    self._status.setText("<font color='red'>No splitter found near click.</font>")
                    return
                feat = self._layer.getFeature(best_fid)
                fnames = [f.name() for f in self._layer.fields()]
                self._edit_state["fid"] = best_fid
                self._layer.selectByIds([best_fid])
                if "zone_id"    in fnames: self._spin_zone.setValue(int(feat["zone_id"]  or 0))
                if "group_id"   in fnames: self._spin_group.setValue(int(feat["group_id"] or 0))
                if "drop_count" in fnames: self._spin_drops.setValue(int(feat["drop_count"] or 0))
                self._btn_apply.setEnabled(True)
                self._status.setText(
                    f"<font color='blue'><b>Splitter FID {best_fid} loaded</b> — "
                    f"edit values above then click Apply Edit.</font>")
                # Return to previous tool after selection
                self.canvas().setMapTool(self._prev)
                self._btn.setChecked(False)

        _edit_prev = {"tool": None}

        def _toggle_edit(checked):
            if checked:
                # Ensure move mode is off
                if btn_move_sp.isChecked():
                    btn_move_sp.setChecked(False)
                _edit_prev["tool"] = self.iface.mapCanvas().mapTool()
                tool = _EditSplitterTool(
                    self.iface.mapCanvas(),
                    _edit_state,
                    splitter_layer,
                    status_lbl,
                    btn_edit_sp,
                    spin_ns_zone,
                    spin_ns_group,
                    spin_ns_drops,
                    btn_apply_edit_sp,
                    _edit_prev["tool"])
                self.iface.mapCanvas().setMapTool(tool)
                dlg._edit_tool = tool
                status_lbl.setText(
                    "<font color='blue'>Edit mode ON — click a splitter to load its attributes.</font>")
            else:
                if _edit_prev["tool"]:
                    self.iface.mapCanvas().setMapTool(_edit_prev["tool"])
                status_lbl.setText("Edit mode OFF.")

        btn_edit_sp.toggled.connect(_toggle_edit)

        # Cancel all modes when dialog closes
        _orig_close = dlg.closeEvent if hasattr(dlg, "closeEvent") else None
        def _dlg_close(ev):
            if btn_move_sp.isChecked():
                btn_move_sp.setChecked(False)
            if btn_edit_sp.isChecked():
                btn_edit_sp.setChecked(False)
            if _orig_close:
                _orig_close(ev)
            else:
                ev.accept()
        dlg.closeEvent = _dlg_close

        tab_widget.addTab(tab_ns, "Add Splitter")

        # ----------------------------------------------------------------
        # Shared status + close
        # ----------------------------------------------------------------
        sep = QFrame()
        sep.setFrameShape(QFrame.HLine)
        sep.setFrameShadow(QFrame.Sunken)
        layout.addWidget(sep)

        status_lbl = QLabel("Switch tabs to work with splitters or demand points.")
        status_lbl.setWordWrap(True)
        layout.addWidget(status_lbl)

        btn_close = QPushButton("Close")
        layout.addWidget(btn_close)

        # ================================================================
        # Undo stack
        # ================================================================
        _undo_stack = []   # max 10 entries; each is a snapshot dict

        def _enable_undo():
            btn_undo_sp.setEnabled(True)
            if btn_undo_dp:
                btn_undo_dp.setEnabled(True)

        def _disable_undo():
            btn_undo_sp.setEnabled(False)
            if btn_undo_dp:
                btn_undo_dp.setEnabled(False)

        def undo_last():
            if not _undo_stack:
                return
            snap = _undo_stack.pop()

            # 1. Restore attributes — group ops by layer to batch editing sessions
            _by_lyr = {}
            for (lyr, fid, fidx, oval) in snap.get('attr_ops', []):
                _lid = id(lyr)
                if _lid not in _by_lyr:
                    _by_lyr[_lid] = (lyr, [])
                _by_lyr[_lid][1].append((fid, fidx, oval))
            for _lid, (lyr, ops) in _by_lyr.items():
                lyr.startEditing()
                for fid, fidx, oval in ops:
                    lyr.changeAttributeValue(fid, fidx, oval)
                lyr.commitChanges()
                lyr.triggerRepaint()

            # 2. Restore geometries
            _by_lyr_g = {}
            for (lyr, fid, ogeom) in snap.get('geom_ops', []):
                _lid = id(lyr)
                if _lid not in _by_lyr_g:
                    _by_lyr_g[_lid] = (lyr, [])
                _by_lyr_g[_lid][1].append((fid, ogeom))
            for _lid, (lyr, ops) in _by_lyr_g.items():
                lyr.startEditing()
                for fid, ogeom in ops:
                    lyr.changeGeometry(fid, ogeom)
                lyr.commitChanges()
                lyr.triggerRepaint()

            # 3. Re-add features that were deleted by apply (e.g. empty PON zone polygons)
            for (lyr, feats) in snap.get('del_feats', []):
                lyr.startEditing()
                lyr.addFeatures(feats)
                lyr.commitChanges()
                lyr.triggerRepaint()

            # 4. Delete PON zone polygons that were newly created by apply
            _pon_lyr = snap.get('pon_lyr')
            for _nzid in snap.get('add_zone_ids', []):
                if _pon_lyr:
                    _fids_del = [_f.id() for _f in _pon_lyr.getFeatures()
                                 if _f['zone_id'] == _nzid]
                    if _fids_del:
                        _pon_lyr.startEditing()
                        _pon_lyr.deleteFeatures(_fids_del)
                        _pon_lyr.commitChanges()
                        _pon_lyr.triggerRepaint()

            # 5. Restore in-memory data dicts
            for (d, key, oval) in snap.get('mem_ops', []):
                d[key] = oval

            # 6. Restore list widget labels
            for (lw, idx, otxt) in snap.get('list_ops', []):
                lw.item(idx).setText(otxt)

            # 7. Restore combo labels
            for (cb, idx, otxt) in snap.get('combo_ops', []):
                cb.setItemText(idx, otxt)

            if not _undo_stack:
                _disable_undo()

            status_lbl.setText(
                f"<font color='orange'><b>Undone:</b> {snap['desc']}</font>")
            self.log_message(f"Undo: {snap['desc']}")

        # ================================================================
        # Splitter tab helpers
        # ================================================================
        def refresh_summary():
            sel_rows = [list_widget.row(it) for it in list_widget.selectedItems()]
            if not sel_rows:
                lbl_sel_count.setText("0")
                lbl_sel_zones.setText("—")
                lbl_sel_drops.setText("0")
                return
            zones = sorted({splitter_data[i]['zone_id'] for i in sel_rows})
            total_drops = sum(splitter_data[i]['drop_count'] for i in sel_rows)
            lbl_sel_count.setText(str(len(sel_rows)))
            lbl_sel_zones.setText(", ".join(str(z) for z in zones))
            lbl_sel_drops.setText(str(total_drops))
            if len(zones) == 1:
                spin.setValue(zones[0])

        list_widget.itemSelectionChanged.connect(refresh_summary)
        btn_select_all.clicked.connect(list_widget.selectAll)
        btn_clear_sel.clicked.connect(list_widget.clearSelection)

        def _zoom_to_selected_splitters():
            sel_rows = [list_widget.row(it) for it in list_widget.selectedItems()]
            if not sel_rows:
                return
            sel_fids = [splitter_data[i]['fid'] for i in sel_rows]
            from qgis.core import QgsRectangle, QgsCoordinateTransform, QgsProject, QgsFeatureRequest, QgsPointXY
            canvas = self.iface.mapCanvas()
            canvas_crs = canvas.mapSettings().destinationCrs()
            layer_crs = splitter_layer.crs()
            xform = QgsCoordinateTransform(layer_crs, canvas_crs, QgsProject.instance())

            # Collect splitter points + their group_ids
            sel_group_ids = []
            pts = []
            for feat in splitter_layer.getFeatures():
                if feat.id() not in sel_fids:
                    continue
                g = feat.geometry()
                if g and not g.isEmpty():
                    g_clone = QgsGeometry(g)
                    g_clone.transform(xform)
                    pts.append(g_clone.centroid().asPoint())
                gid = feat['group_id']
                if gid is not None:
                    sel_group_ids.append(int(gid))

            if not pts:
                return

            # Highlight splitter points
            splitter_layer.selectByIds(sel_fids)

            # Highlight matching drop cables in any drop layer
            for lyr in QgsProject.instance().mapLayers().values():
                from qgis.core import QgsVectorLayer
                if not isinstance(lyr, QgsVectorLayer):
                    continue
                lname = lyr.name().lower()
                if 'drop cable' not in lname and 'drop_cable' not in lname:
                    continue
                if 'group_id' not in [f.name() for f in lyr.fields()]:
                    continue
                drop_fids = [
                    f.id() for f in lyr.getFeatures()
                    if f['group_id'] is not None and int(f['group_id']) in sel_group_ids
                ]
                lyr.selectByIds(drop_fids)

            # Zoom to centroid of all selected points at a fixed 1:1000 scale
            cx = sum(p.x() for p in pts) / len(pts)
            cy = sum(p.y() for p in pts) / len(pts)
            canvas.zoomByFactor(1.0)  # no-op, just ensures renderer is ready
            # If multiple splitters span a wide area, fit them all; otherwise use 1:1000
            bbox = QgsRectangle(pts[0].x(), pts[0].y(), pts[0].x(), pts[0].y())
            for p in pts[1:]:
                bbox.combineExtentWith(QgsRectangle(p.x(), p.y(), p.x(), p.y()))
            span = max(bbox.width(), bbox.height())
            if span > 0:
                # Multiple spread-out points — fit with 30% margin
                bbox.grow(span * 0.3)
                canvas.setExtent(bbox)
            else:
                # Single point (or all same location) — centre and set 1:1000 scale
                canvas.setCenter(QgsPointXY(cx, cy))
                canvas.zoomScale(1000)
            canvas.refresh()

        btn_zoom_sel.clicked.connect(_zoom_to_selected_splitters)

        # ================================================================
        # Demand tab helpers
        # ================================================================
        if demand_data and dem_list:
            def refresh_dp_summary():
                sel_rows = [dem_list.row(it) for it in dem_list.selectedItems()]
                if not sel_rows:
                    lbl_dp_count.setText("0")
                    lbl_dp_groups.setText("—")
                    return
                groups = sorted({demand_data[i]['group_id'] for i in sel_rows})
                lbl_dp_count.setText(str(len(sel_rows)))
                lbl_dp_groups.setText(", ".join(str(g) for g in groups))

            dem_list.itemSelectionChanged.connect(refresh_dp_summary)
            btn_dp_select_all.clicked.connect(dem_list.selectAll)
            btn_dp_clear_sel.clicked.connect(dem_list.clearSelection)

        # ---- Apply change (batch over all selected splitters) ----
        def apply_change():
            sel_rows = [list_widget.row(it) for it in list_widget.selectedItems()]
            if not sel_rows:
                status_lbl.setText("No splitters selected.")
                return

            new_zone  = spin.value()
            to_change = [splitter_data[i] for i in sel_rows
                         if splitter_data[i]['zone_id'] != new_zone]
            if not to_change:
                status_lbl.setText("No change — all selected splitters are already in that zone.")
                return

            # Net drops leaving each old zone (may span multiple old zones)
            old_zones_delta = {}   # {old_zone_id: total drops moving out}
            for sd in to_change:
                oz = sd['zone_id']
                old_zones_delta[oz] = old_zones_delta.get(oz, 0) + sd['drop_count']
            new_zone_gain = sum(sd['drop_count'] for sd in to_change)
            changing_groups = {sd['group_id'] for sd in to_change}

            # ---- Snapshot for undo ----
            _snap = {
                'desc':         f"{len(to_change)} splitter(s) → Zone {new_zone}",
                'attr_ops':     [],
                'geom_ops':     [],
                'del_feats':    [],
                'add_zone_ids': [],
                'pon_lyr':      None,
                'mem_ops':      [],
                'list_ops':     [],
                'combo_ops':    [],
            }
            # Splitter attributes
            _zi_s = splitter_layer.fields().indexFromName('zone_id')
            for _sf in splitter_layer.getFeatures():
                if _sf['group_id'] in changing_groups:
                    _snap['attr_ops'].append((splitter_layer, _sf.id(), _zi_s, _sf['zone_id']))
            # In-memory splitter_data + list labels
            for sd in to_change:
                _si = splitter_data.index(sd)
                _snap['mem_ops'].append((sd, 'zone_id', sd['zone_id']))
                _snap['list_ops'].append((list_widget, _si, list_widget.item(_si).text()))
            # Limit stack depth
            if len(_undo_stack) >= 10:
                _undo_stack.pop(0)

            results = []
            _link = None   # group link field name on demand / grouped layer

            # 1. Update splitter points (one editing session for all)
            _zi = splitter_layer.fields().indexFromName('zone_id')
            splitter_layer.startEditing()
            for sd in to_change:
                splitter_layer.changeAttributeValue(sd['fid'], _zi, new_zone)
            splitter_layer.commitChanges()
            splitter_layer.triggerRepaint()
            results.append(f"Splitter Points — {len(to_change)} splitter(s)")

            # 2. Update demand points
            _dem_layer = None
            _zone_fld = None   # kept in outer scope for step 4
            try:
                if self.demand_points_layer and not sip.isdeleted(self.demand_points_layer):
                    _dem_layer = self.demand_points_layer
            except Exception:
                pass
            if not _dem_layer:
                for _lyr in QgsProject.instance().mapLayers().values():
                    if isinstance(_lyr, QgsVectorLayer):
                        _ln = _lyr.name().lower()
                        if 'demand points' in _ln or 'demand_points' in _ln:
                            _dem_layer = _lyr
                            break
            if _dem_layer:
                _dfnames = [f.name() for f in _dem_layer.fields()]
                _link = next((fn for fn in ['group_8', 'group_16', 'group_128', 'group_100', 'batch_id']
                               if fn in _dfnames), None)
                _zone_fld = next((fn for fn in ['zone_id', 'group_100']  # sets outer _zone_fld
                                   if fn in _dfnames and fn != _link), None)
                if _link and _zone_fld:
                    _dzi = _dem_layer.fields().indexFromName(_zone_fld)
                    _zni = _dem_layer.fields().indexFromName('zone_name') if 'zone_name' in _dfnames else -1
                    # Snapshot demand points before editing
                    for _f in _dem_layer.getFeatures():
                        if _f[_link] in changing_groups:
                            _snap['attr_ops'].append((_dem_layer, _f.id(), _dzi, _f[_zone_fld]))
                            if _zni >= 0:
                                _snap['attr_ops'].append((_dem_layer, _f.id(), _zni, _f['zone_name']))
                    _dem_layer.startEditing()
                    _upd = 0
                    for _f in _dem_layer.getFeatures():
                        if _f[_link] in changing_groups:
                            _dem_layer.changeAttributeValue(_f.id(), _dzi, new_zone)
                            if _zni >= 0:
                                _dem_layer.changeAttributeValue(_f.id(), _zni, f"Zone {new_zone}")
                            _upd += 1
                    _dem_layer.commitChanges()
                    _dem_layer.triggerRepaint()
                    results.append(f"Demand Points — {_upd} feature(s)")

            # 2b. Keep grouped_layer (parcels) in sync — it's a separate layer from demand_points_layer
            _grp_lyr = getattr(self, 'grouped_layer', None)
            try:
                _grp_deleted = sip.isdeleted(_grp_lyr) if _grp_lyr else True
            except Exception:
                _grp_deleted = True
            if _grp_lyr and not _grp_deleted and _grp_lyr != _dem_layer:
                _grp_fnames = [f.name() for f in _grp_lyr.fields()]
                _grp_link = next((fn for fn in ['group_8', 'group_16', 'group_128', 'group_100', 'batch_id']
                                   if fn in _grp_fnames), None)
                _grp_zi  = _grp_lyr.fields().indexFromName('zone_id')  if 'zone_id'   in _grp_fnames else -1
                _grp_zni = _grp_lyr.fields().indexFromName('zone_name') if 'zone_name' in _grp_fnames else -1
                if _grp_link and _grp_zi >= 0:
                    # Snapshot grouped layer before editing
                    for _f in _grp_lyr.getFeatures():
                        if _f[_grp_link] in changing_groups:
                            _snap['attr_ops'].append((_grp_lyr, _f.id(), _grp_zi, _f['zone_id']))
                            if _grp_zni >= 0:
                                _snap['attr_ops'].append((_grp_lyr, _f.id(), _grp_zni, _f['zone_name']))
                    _grp_lyr.startEditing()
                    _grp_upd = 0
                    for _f in _grp_lyr.getFeatures():
                        if _f[_grp_link] in changing_groups:
                            _grp_lyr.changeAttributeValue(_f.id(), _grp_zi, new_zone)
                            if _grp_zni >= 0:
                                _grp_lyr.changeAttributeValue(_f.id(), _grp_zni, f"Zone {new_zone}")
                            _grp_upd += 1
                    _grp_lyr.commitChanges()
                    _grp_lyr.triggerRepaint()
                    if _grp_upd:
                        results.append(f"Grouped Layer — {_grp_upd} feature(s)")

            # 3. Update drop cable layers
            for _dc_name in ("Drop Cables Lashed", "Drop Cables PTP"):
                for _lyr in QgsProject.instance().mapLayers().values():
                    if isinstance(_lyr, QgsVectorLayer) and _lyr.name() == _dc_name:
                        _dc_fnames = [f.name() for f in _lyr.fields()]
                        if 'zone_id' in _dc_fnames and 'group_id' in _dc_fnames:
                            _dczi = _lyr.fields().indexFromName('zone_id')
                            # Snapshot drop cables before editing
                            for _f in _lyr.getFeatures():
                                if _f['group_id'] in changing_groups:
                                    _snap['attr_ops'].append((_lyr, _f.id(), _dczi, _f['zone_id']))
                            _lyr.startEditing()
                            _upd_dc = 0
                            for _f in _lyr.getFeatures():
                                if _f['group_id'] in changing_groups:
                                    _lyr.changeAttributeValue(_f.id(), _dczi, new_zone)
                                    _upd_dc += 1
                            _lyr.commitChanges()
                            _lyr.triggerRepaint()
                            if _upd_dc:
                                results.append(f"{_dc_name} — {_upd_dc} cable(s)")
                        break

            # 4. Update PON Zone boundaries — unit_count + regenerate polygon geometry
            # Use group link field + splitter_data zone mapping to find demand features per zone.
            # This avoids relying on zone_id field being present or type-consistent on the demand layer.
            _src_lyr  = None   # source point layer for polygon building
            _src_link = None   # group link field name on _src_lyr
            if _dem_layer and _link:
                _src_lyr  = _dem_layer
                _src_link = _link
            else:
                _grp_cand = getattr(self, 'grouped_layer', None)
                try:
                    if _grp_cand and not sip.isdeleted(_grp_cand):
                        _gcnames = [f.name() for f in _grp_cand.fields()]
                        _src_link = next((fn for fn in ['group_8', 'group_16', 'group_128',
                                                        'group_100', 'batch_id']
                                          if fn in _gcnames), None)
                        if _src_link:
                            _src_lyr = _grp_cand
                except Exception:
                    pass

            # Zone → set-of-group_ids mapping from splitter_data (still has PRE-move values)
            _z2g = {}
            for _sd in splitter_data:
                _z2g.setdefault(int(_sd['zone_id']), set()).add(_sd['group_id'])

            for _lyr in QgsProject.instance().mapLayers().values():
                if isinstance(_lyr, QgsVectorLayer) and 'PON Zones' in _lyr.name():
                    _b_fnames = [f.name() for f in _lyr.fields()]
                    if 'zone_id' in _b_fnames and 'unit_count' in _b_fnames:
                        _snap['pon_lyr'] = _lyr
                        _uc_idx = _lyr.fields().indexFromName('unit_count')
                        # Snapshot PON zone features BEFORE editing
                        for _f in _lyr.getFeatures():
                            _fzid = int(_f['zone_id']) if _f['zone_id'] is not None else -1
                            if _fzid in old_zones_delta:
                                _n_out = old_zones_delta[_fzid]
                                _will_empty = max(0, (_f['unit_count'] or 0) - _n_out) == 0
                                if _will_empty:
                                    # Will be deleted — save full copy to restore on undo
                                    from qgis.core import QgsFeature as _QFsnap
                                    _snap['del_feats'].append((_lyr, [_QFsnap(_f)]))
                                else:
                                    _snap['attr_ops'].append((_lyr, _f.id(), _uc_idx, _f['unit_count']))
                                    _snap['geom_ops'].append((_lyr, _f.id(), QgsGeometry(_f.geometry())))
                            elif _fzid == new_zone:
                                _snap['attr_ops'].append((_lyr, _f.id(), _uc_idx, _f['unit_count']))
                                _snap['geom_ops'].append((_lyr, _f.id(), QgsGeometry(_f.geometry())))
                        _lyr.startEditing()
                        _b_upd = []
                        _new_zone_found = False
                        _fids_to_delete = []
                        for _f in _lyr.getFeatures():
                            _fzid = int(_f['zone_id']) if _f['zone_id'] is not None else -1
                            if _fzid in old_zones_delta:
                                _n_out = old_zones_delta[_fzid]
                                _new_uc = max(0, (_f['unit_count'] or 0) - _n_out)
                                _b_upd.append(f"Zone {_fzid}: {(_f['unit_count'] or 0)} → {_new_uc}")
                                if _new_uc == 0:
                                    # Zone is now empty — delete the polygon
                                    _fids_to_delete.append(_f.id())
                                else:
                                    _lyr.changeAttributeValue(_f.id(), _uc_idx, _new_uc)
                                    if _src_lyr and _src_link:
                                        # Remaining groups in old zone = zone's groups minus those moving out
                                        _rem_grps = _z2g.get(int(_fzid), set()) - changing_groups
                                        _oz_feats = [_ff for _ff in _src_lyr.getFeatures()
                                                     if _ff[_src_link] in _rem_grps]
                                        if _oz_feats:
                                            _oz_geom = self._build_zone_polygon(_src_lyr, _oz_feats)
                                            if not _oz_geom.isEmpty():
                                                _lyr.changeGeometry(_f.id(), _oz_geom)
                            elif int(_fzid) == new_zone:
                                _new_zone_found = True
                                _new_uc = (_f['unit_count'] or 0) + new_zone_gain
                                _lyr.changeAttributeValue(_f.id(), _uc_idx, _new_uc)
                                _b_upd.append(f"Zone {new_zone}: {(_f['unit_count'] or 0)} → {_new_uc}")
                                if _src_lyr and _src_link:
                                    # New zone groups = original new zone groups + moving groups
                                    _new_grps = _z2g.get(new_zone, set()) | changing_groups
                                    _nz_feats = [_ff for _ff in _src_lyr.getFeatures()
                                                 if _ff[_src_link] in _new_grps]
                                    if _nz_feats:
                                        _nz_geom = self._build_zone_polygon(_src_lyr, _nz_feats)
                                        if not _nz_geom.isEmpty():
                                            _lyr.changeGeometry(_f.id(), _nz_geom)
                        if _fids_to_delete:
                            _lyr.deleteFeatures(_fids_to_delete)
                            _b_upd.append(f"Removed {len(_fids_to_delete)} empty zone polygon(s)")
                        # Create a new boundary polygon if new_zone has no existing feature
                        if not _new_zone_found and _src_lyr and _src_link:
                            _new_grps = _z2g.get(new_zone, set()) | changing_groups
                            _nz_feats = [_ff for _ff in _src_lyr.getFeatures()
                                         if _ff[_src_link] in _new_grps]
                            if _nz_feats:
                                _nz_geom = self._build_zone_polygon(_src_lyr, _nz_feats)
                                if not _nz_geom.isEmpty():
                                    from qgis.core import QgsFeature as _QF
                                    _new_feat = _QF(_lyr.fields())
                                    _new_feat.setGeometry(_nz_geom)
                                    _new_feat['zone_id']    = new_zone
                                    _new_feat['zone_name']  = f"Zone {new_zone}"
                                    _new_feat['unit_count'] = new_zone_gain
                                    _lyr.addFeature(_new_feat)
                                    _snap['add_zone_ids'].append(new_zone)
                                    _b_upd.append(f"Zone {new_zone}: (new) {new_zone_gain}")
                        _lyr.commitChanges()
                        _lyr.triggerRepaint()
                        if _b_upd:
                            results.append(f"PON Zone Boundaries — {'; '.join(_b_upd)}")
                    break

            # Update local splitter_data and list item labels
            for sd in to_change:
                _i = splitter_data.index(sd)
                sd['zone_id'] = new_zone
                list_widget.item(_i).setText(
                    f"Group {sd['group_id']}   |   Zone {new_zone}   |   {sd['drop_count']} drops")
            # Auto-deselect after successful apply
            list_widget.clearSelection()
            refresh_summary()

            # Push snapshot to undo stack
            _undo_stack.append(_snap)
            _enable_undo()

            _old_str = ", ".join(f"Zone {z}" for z in sorted(old_zones_delta))
            _summary = "<br>".join(results)
            status_lbl.setText(
                f"<font color='green'><b>Done:</b> {len(to_change)} splitter(s): "
                f"{_old_str} → Zone {new_zone}<br>{_summary}</font>")
            self.log_message(f"Manual Override: {len(to_change)} splitter(s) → Zone {new_zone}")
            for _r in results:
                self.log_message(f"  {_r}")

        # ================================================================
        # Demand reassignment apply
        # ================================================================
        def apply_demand_change():
            if not (demand_data and dem_list and combo_target):
                return
            sel_rows = [dem_list.row(it) for it in dem_list.selectedItems()]
            if not sel_rows:
                status_lbl.setText("No demand points selected.")
                return

            # Resolve target: spin_grp takes priority if it matches a known splitter,
            # otherwise fall back to combo selection.
            _manual_gid = spin_grp.value()
            tgt_sd = next((sd for sd in splitter_data if sd['group_id'] == _manual_gid), None)
            if tgt_sd is None:
                tgt_sd = splitter_data[combo_target.currentIndex()]
            new_grp  = tgt_sd['group_id']
            new_zone = tgt_sd['zone_id']

            # Collect only those that actually change
            moves = [(demand_data[r], demand_data[r]['group_id'], demand_data[r]['zone_id'], r)
                     for r in sel_rows if demand_data[r]['group_id'] != new_grp]
            if not moves:
                status_lbl.setText("No change — all selected demand points are already in that group.")
                dem_list.clearSelection()
                return

            # ---- Snapshot for undo ----
            _snap_dp = {
                'desc':         f"{len(moves)} demand point(s) → Group {new_grp} / Zone {new_zone}",
                'attr_ops':     [],
                'geom_ops':     [],
                'del_feats':    [],
                'add_zone_ids': [],
                'pon_lyr':      None,
                'mem_ops':      [],
                'list_ops':     [],
                'combo_ops':    [],
            }
            # Demand point attributes
            _link_idx_s = _dem_layer.fields().indexFromName(_dp_link)
            for dd, old_g, old_z, row in moves:
                _snap_dp['attr_ops'].append((_dem_layer, dd['fid'], _link_idx_s, old_g))
                if _dp_zi >= 0:
                    _snap_dp['attr_ops'].append((_dem_layer, dd['fid'], _dp_zi, old_z))
                if _dp_zni >= 0:
                    _f_tmp = next((_ff for _ff in _dem_layer.getFeatures()
                                   if _ff.id() == dd['fid']), None)
                    if _f_tmp:
                        _snap_dp['attr_ops'].append((_dem_layer, dd['fid'], _dp_zni,
                                                     _f_tmp['zone_name']))
                _snap_dp['mem_ops'].append((dd, 'group_id', dd['group_id']))
                _snap_dp['mem_ops'].append((dd, 'zone_id',  dd['zone_id']))
                _snap_dp['list_ops'].append((dem_list, row, dem_list.item(row).text()))
            # Splitter drop_count
            _old_grps_dp = {dd['group_id'] for dd, _, _, _ in moves}
            _dc_idx_s = splitter_layer.fields().indexFromName('drop_count') \
                if 'drop_count' in sp_field_names else -1
            if _dc_idx_s >= 0:
                for _spf in splitter_layer.getFeatures():
                    _sgid = _spf['group_id']
                    if _sgid in _old_grps_dp or _sgid == new_grp:
                        _snap_dp['attr_ops'].append((splitter_layer, _spf.id(), _dc_idx_s,
                                                     _spf['drop_count'] or 0))
                        for sd in splitter_data:
                            if sd['group_id'] == _sgid:
                                _si = splitter_data.index(sd)
                                _snap_dp['mem_ops'].append((sd, 'drop_count', sd['drop_count']))
                                _snap_dp['list_ops'].append((list_widget, _si,
                                                             list_widget.item(_si).text()))
                                _snap_dp['combo_ops'].append((combo_target, _si,
                                                              combo_target.itemText(_si)))
            # Limit stack depth
            if len(_undo_stack) >= 10:
                _undo_stack.pop(0)

            results_dp = []

            # 1. Update demand point attributes
            if not _dem_layer:
                status_lbl.setText("ERROR: Demand Points layer not accessible.")
                return
            _link_idx = _dem_layer.fields().indexFromName(_dp_link)
            _dem_layer.startEditing()
            for dd, old_g, old_z, row in moves:
                _dem_layer.changeAttributeValue(dd['fid'], _link_idx, new_grp)
                if _dp_zi >= 0:
                    _dem_layer.changeAttributeValue(dd['fid'], _dp_zi, new_zone)
                if _dp_zni >= 0:
                    _dem_layer.changeAttributeValue(dd['fid'], _dp_zni, f"Zone {new_zone}")
            _dem_layer.commitChanges()
            _dem_layer.triggerRepaint()
            results_dp.append(f"Demand Points — {len(moves)} updated")

            # 2. Update splitter drop_counts
            old_grp_delta = {}   # {old_group: count of points leaving}
            for dd, old_g, old_z, row in moves:
                old_grp_delta[old_g] = old_grp_delta.get(old_g, 0) + 1
            _dc_idx = splitter_layer.fields().indexFromName('drop_count') if 'drop_count' in sp_field_names else -1
            if _dc_idx >= 0:
                splitter_layer.startEditing()
                for _spf in splitter_layer.getFeatures():
                    _sgid = _spf['group_id']
                    if _sgid in old_grp_delta:
                        _new_dc = max(0, (_spf['drop_count'] or 0) - old_grp_delta[_sgid])
                        splitter_layer.changeAttributeValue(_spf.id(), _dc_idx, _new_dc)
                        for sd in splitter_data:
                            if sd['group_id'] == _sgid:
                                sd['drop_count'] = _new_dc
                    elif _sgid == new_grp:
                        _new_dc = (_spf['drop_count'] or 0) + len(moves)
                        splitter_layer.changeAttributeValue(_spf.id(), _dc_idx, _new_dc)
                        for sd in splitter_data:
                            if sd['group_id'] == new_grp:
                                sd['drop_count'] = _new_dc
                splitter_layer.commitChanges()
                splitter_layer.triggerRepaint()
                results_dp.append(f"Splitter drop counts updated")
                # Refresh splitter list labels
                for i, sd in enumerate(splitter_data):
                    list_widget.item(i).setText(
                        f"Group {sd['group_id']}   |   Zone {sd['zone_id']}   |   {sd['drop_count']} drops")
                # Refresh target combo labels
                for i, sd in enumerate(splitter_data):
                    combo_target.setItemText(i,
                        f"Group {sd['group_id']}  |  Zone {sd['zone_id']}  |  {sd['drop_count']} drops")

            # 3. Update drop cable group_id + zone_id for moved demand points
            # demand_id field exists but is unpopulated; match by group_id only.
            _old_grps_moved = {dd['group_id'] for dd, _, _, _ in moves}
            for _dc_name in ("Drop Cables Lashed", "Drop Cables PTP"):
                for _lyr in QgsProject.instance().mapLayers().values():
                    if isinstance(_lyr, QgsVectorLayer) and _lyr.name() == _dc_name:
                        _dc_fnames = [f.name() for f in _lyr.fields()]
                        if 'zone_id' not in _dc_fnames or 'group_id' not in _dc_fnames:
                            break
                        _dczi2 = _lyr.fields().indexFromName('zone_id')
                        _dcgi2 = _lyr.fields().indexFromName('group_id')
                        _lyr.startEditing()
                        _upd_dc2 = 0
                        for _f in _lyr.getFeatures():
                            if _f['group_id'] in _old_grps_moved:
                                _lyr.changeAttributeValue(_f.id(), _dcgi2, new_grp)
                                _lyr.changeAttributeValue(_f.id(), _dczi2, new_zone)
                                _upd_dc2 += 1
                        _lyr.commitChanges()
                        _lyr.triggerRepaint()
                        if _upd_dc2:
                            results_dp.append(f"{_dc_name} — {_upd_dc2} cable(s) updated")
                        break

            # 4. Update PON Zone boundaries using group link field + splitter_data zone mapping.
            # Works even if demand points have no zone_id field.
            affected_old_zones = {int(old_z) for _, _, old_z, _ in moves
                                  if old_z is not None and int(old_z) != new_zone}
            moved_fids = {dd['fid'] for dd, _, _, _ in moves}
            # Build zone → group_ids mapping from splitter_data (zone assignments unchanged by this op)
            _z2g_dp = {}
            for _sd in splitter_data:
                _z2g_dp.setdefault(int(_sd['zone_id']), set()).add(_sd['group_id'])

            for _lyr in QgsProject.instance().mapLayers().values():
                if isinstance(_lyr, QgsVectorLayer) and 'PON Zones' in _lyr.name():
                    _b_fnames = [f.name() for f in _lyr.fields()]
                    if 'zone_id' in _b_fnames and 'unit_count' in _b_fnames:
                        _uc_idx2 = _lyr.fields().indexFromName('unit_count')
                        # Snapshot PON zones BEFORE editing
                        _snap_dp['pon_lyr'] = _lyr
                        for _f in _lyr.getFeatures():
                            _fzid2 = int(_f['zone_id']) if _f['zone_id'] is not None else -1
                            if _fzid2 in affected_old_zones:
                                # Check if zone will be empty after moves
                                _rem_grps2 = _z2g_dp.get(_fzid2, set())
                                _rem_feats_chk = [_ff for _ff in _dem_layer.getFeatures()
                                                  if _ff[_dp_link] in _rem_grps2
                                                  and _ff.id() not in moved_fids]
                                if len(_rem_feats_chk) == 0:
                                    from qgis.core import QgsFeature as _QFsnap2
                                    _snap_dp['del_feats'].append((_lyr, [_QFsnap2(_f)]))
                                else:
                                    _snap_dp['attr_ops'].append((_lyr, _f.id(), _uc_idx2,
                                                                 _f['unit_count'] or 0))
                                    _snap_dp['geom_ops'].append((_lyr, _f.id(),
                                                                 QgsGeometry(_f.geometry())))
                            elif _fzid2 == new_zone:
                                _snap_dp['attr_ops'].append((_lyr, _f.id(), _uc_idx2,
                                                             _f['unit_count'] or 0))
                                _snap_dp['geom_ops'].append((_lyr, _f.id(),
                                                             QgsGeometry(_f.geometry())))
                        _lyr.startEditing()
                        _new_zone_found2 = False
                        _fids_del2 = []
                        for _f in _lyr.getFeatures():
                            _fzid2 = int(_f['zone_id']) if _f['zone_id'] is not None else -1
                            if _fzid2 in affected_old_zones:
                                # Remaining demand: in this zone's groups, excluding moved fids
                                _rem_grps2 = _z2g_dp.get(_fzid2, set())
                                _rem_feats = [_ff for _ff in _dem_layer.getFeatures()
                                              if _ff[_dp_link] in _rem_grps2
                                              and _ff.id() not in moved_fids]
                                _new_uc = len(_rem_feats)
                                if _new_uc == 0:
                                    _fids_del2.append(_f.id())
                                else:
                                    _lyr.changeAttributeValue(_f.id(), _uc_idx2, _new_uc)
                                    _oz_geom = self._build_zone_polygon(_dem_layer, _rem_feats)
                                    if not _oz_geom.isEmpty():
                                        _lyr.changeGeometry(_f.id(), _oz_geom)
                            elif _fzid2 == new_zone:
                                _new_zone_found2 = True
                                # All demand in new zone's groups + moved demand points
                                _nz_grps2 = _z2g_dp.get(new_zone, set())
                                _nz_feats = [_ff for _ff in _dem_layer.getFeatures()
                                             if _ff[_dp_link] in _nz_grps2
                                             or _ff.id() in moved_fids]
                                _lyr.changeAttributeValue(_f.id(), _uc_idx2, len(_nz_feats))
                                _nz_geom = self._build_zone_polygon(_dem_layer, _nz_feats)
                                if not _nz_geom.isEmpty():
                                    _lyr.changeGeometry(_f.id(), _nz_geom)
                        if _fids_del2:
                            _lyr.deleteFeatures(_fids_del2)
                        if not _new_zone_found2:
                            _nz_grps2 = _z2g_dp.get(new_zone, set())
                            _nz_feats = [_ff for _ff in _dem_layer.getFeatures()
                                         if _ff[_dp_link] in _nz_grps2
                                         or _ff.id() in moved_fids]
                            if _nz_feats:
                                from qgis.core import QgsFeature as _QF2
                                _nf = _QF2(_lyr.fields())
                                _nf['zone_id']    = new_zone
                                _nf['zone_name']  = f"Zone {new_zone}"
                                _nf['unit_count'] = len(_nz_feats)
                                _nz_geom = self._build_zone_polygon(_dem_layer, _nz_feats)
                                if not _nz_geom.isEmpty():
                                    _nf.setGeometry(_nz_geom)
                                _lyr.addFeature(_nf)
                                _snap_dp['add_zone_ids'].append(new_zone)
                        _lyr.commitChanges()
                        _lyr.triggerRepaint()
                        results_dp.append("PON Zone Boundaries updated")
                    break

            # Update in-memory demand_data + list labels, then auto-deselect
            for dd, old_g, old_z, row in moves:
                dd['group_id'] = new_grp
                dd['zone_id']  = new_zone
                dem_list.item(row).setText(
                    f"DP {dd['fid']}   |   Group {new_grp}   |   Zone {new_zone}")
            dem_list.clearSelection()

            # Push snapshot to undo stack
            _undo_stack.append(_snap_dp)
            _enable_undo()

            status_lbl.setText(
                f"<font color='green'><b>Done:</b> {len(moves)} demand point(s) → "
                f"Group {new_grp} / Zone {new_zone}<br>"
                + "<br>".join(results_dp) + "</font>")
            self.log_message(f"Demand Override: {len(moves)} point(s) → Group {new_grp} / Zone {new_zone}")

        # ================================================================
        # Map tool — tab-aware picking
        # ================================================================
        from qgis.gui import QgsMapToolEmitPoint
        from qgis.core import QgsCoordinateTransform, QgsProject as _QP

        _canvas    = self.iface.mapCanvas()
        _prev_tool = _canvas.mapTool()
        _map_tool  = QgsMapToolEmitPoint(_canvas)
        _picking   = [True]

        def _on_canvas_click(point, _button):
            if not _picking[0]:
                return
            _xform = QgsCoordinateTransform(
                _QP.instance().crs(), splitter_layer.crs(), _QP.instance())
            try:
                _lp = _xform.transform(point)
            except Exception:
                _lp = point

            if tab_widget.currentIndex() == 0:
                # Splitter picking
                _best_idx, _best_d = 0, float('inf')
                for _i, _sd in enumerate(splitter_data):
                    _d = math.sqrt((_sd['x'] - _lp.x()) ** 2 + (_sd['y'] - _lp.y()) ** 2)
                    if _d < _best_d:
                        _best_d = _d
                        _best_idx = _i
                _item = list_widget.item(_best_idx)
                _item.setSelected(not _item.isSelected())
                _n = len(list_widget.selectedItems())
                _word = "selected" if _item.isSelected() else "deselected"
                status_lbl.setText(
                    f"<font color='blue'>Group {splitter_data[_best_idx]['group_id']} {_word} "
                    f"— {_n} splitter(s) selected.</font>")

            elif tab_widget.currentIndex() == 1:
                # Demand point picking
                if not (demand_data and dem_list):
                    return
                _best_idx, _best_d = 0, float('inf')
                for _i, _dd in enumerate(demand_data):
                    _d = math.sqrt((_dd['x'] - _lp.x()) ** 2 + (_dd['y'] - _lp.y()) ** 2)
                    if _d < _best_d:
                        _best_d = _d
                        _best_idx = _i
                _item = dem_list.item(_best_idx)
                _item.setSelected(not _item.isSelected())
                _n = len(dem_list.selectedItems())
                _word = "selected" if _item.isSelected() else "deselected"
                status_lbl.setText(
                    f"<font color='blue'>DP {demand_data[_best_idx]['fid']} {_word} "
                    f"— {_n} demand point(s) selected.</font>")

            else:
                # Tab 2 — capture coordinate for new splitter
                from qgis.core import QgsGeometry, QgsPointXY as _PXY, QgsVectorLayer as _VL
                _ns_point[0] = _lp
                lbl_ns_x.setText(f"{_lp.x():.4f}")
                lbl_ns_y.setText(f"{_lp.y():.4f}")
                btn_add_sp.setEnabled(True)

                # Auto-detect zone from PON Zone polygon layer
                _auto_zone = 0
                for _lyr in _QP.instance().mapLayers().values():
                    if not isinstance(_lyr, _VL) or _lyr.geometryType() != 2:
                        continue
                    _ln = _lyr.name().lower()
                    if ('pon' in _ln or 'zone' in _ln) and ('zone' in _ln or 'boundar' in _ln):
                        _pt_geom = QgsGeometry.fromPointXY(_PXY(_lp.x(), _lp.y()))
                        for _zf in _lyr.getFeatures():
                            if _zf.geometry() and _pt_geom.within(_zf.geometry()):
                                _zval = _zf['zone_id'] if 'zone_id' in [_fd.name() for _fd in _lyr.fields()] else None
                                if _zval is not None:
                                    try:
                                        _auto_zone = int(_zval)
                                    except (TypeError, ValueError):
                                        pass
                                break
                        break
                spin_ns_zone.setValue(_auto_zone)
                status_lbl.setText(
                    f"<font color='blue'>Point captured at ({_lp.x():.2f}, {_lp.y():.2f}) "
                    f"— Zone auto-detected: {_auto_zone}. "
                    f"Adjust attributes and click <b>Add Splitter Point</b>.</font>")

        def _on_tool_deactivate():
            if _picking[0]:
                _picking[0] = False
                btn_pick.setChecked(False)
                btn_pick.setText("Map Picking: OFF")
                status_lbl.setText(
                    "Map picking paused — another tool was activated. "
                    "Click 'Map Picking: OFF' to resume.")

        _map_tool.canvasClicked.connect(_on_canvas_click)
        _map_tool.deactivated.connect(_on_tool_deactivate)

        def _start_picking():
            _picking[0] = True
            _canvas.setMapTool(_map_tool)
            btn_pick.setChecked(True)
            btn_pick.setText("Map Picking: ON")

        def _stop_picking(restore_tool=True):
            _picking[0] = False
            if restore_tool:
                _canvas.setMapTool(_prev_tool)
            btn_pick.setChecked(False)
            btn_pick.setText("Map Picking: OFF")

        def _on_pick_toggle(checked):
            if checked:
                _start_picking()
                _idx = tab_widget.currentIndex()
                if _idx == 0:
                    status_lbl.setText("Map picking ON — click splitters on the map.")
                elif _idx == 1:
                    status_lbl.setText("Map picking ON — click demand points on the map.")
                else:
                    status_lbl.setText("Map picking ON — click the map to place a new splitter point.")
            else:
                _stop_picking()
                status_lbl.setText("Map picking paused — use the list for selection.")

        def _on_tab_changed(_idx):
            if _picking[0]:
                if _idx == 0:
                    status_lbl.setText("Map picking ON — click splitters on the map.")
                elif _idx == 1:
                    status_lbl.setText("Map picking ON — click demand points on the map.")
                else:
                    status_lbl.setText("Map picking ON — click the map to place a new splitter point.")

        def _on_dialog_close():
            _picking[0] = False
            try:
                _map_tool.canvasClicked.disconnect(_on_canvas_click)
            except Exception:
                pass
            try:
                _map_tool.deactivated.disconnect(_on_tool_deactivate)
            except Exception:
                pass
            _canvas.setMapTool(_prev_tool)

        btn_pick.toggled.connect(_on_pick_toggle)
        tab_widget.currentChanged.connect(_on_tab_changed)
        dlg.finished.connect(_on_dialog_close)
        btn_apply_sp.clicked.connect(apply_change)
        btn_undo_sp.clicked.connect(undo_last)
        if demand_data and btn_apply_dp:
            btn_apply_dp.clicked.connect(apply_demand_change)
        if btn_undo_dp:
            btn_undo_dp.clicked.connect(undo_last)
        if demand_data:
            btn_regen_drops.clicked.connect(lambda: self.on_generate_drop_ptp_clicked())
        btn_close.clicked.connect(dlg.close)

        _start_picking()
        status_lbl.setText("Map picking ON — click splitters on the map.")
        dlg.show()
        dlg.raise_()
        dlg.activateWindow()

    def on_generate_aggregation_points_clicked(self):
        """Generate one aggregation point per PON Zone, labelled with zone name and splitter count."""
        from qgis.core import (QgsVectorLayer, QgsFeature, QgsGeometry, QgsProject, QgsField,
                                QgsPointXY, QgsMarkerSymbol, QgsSingleSymbolRenderer,
                                QgsPalLayerSettings, QgsTextFormat, QgsTextBufferSettings,
                                QgsVectorLayerSimpleLabeling)
        from qgis.PyQt.QtCore import QVariant, QMetaType
        from qgis.PyQt.QtGui import QColor, QFont
        import math

        # ── 1. Locate the grouped PON layer (must have zone_name + zone_id) ────────
        grouped_layer = None
        zone_field = 'zone_id'
        zone_name_field = 'zone_name'

        candidate = getattr(self, 'grouped_layer', None)
        if candidate and candidate.isValid():
            flds = [f.name() for f in candidate.fields()]
            if zone_name_field in flds and zone_field in flds:
                grouped_layer = candidate

        if not grouped_layer:
            skip_kw = ('boundary', 'splitter', 'aggregation', 'poles', 'feeder', 'drop cable', 'route')
            for layer in QgsProject.instance().mapLayers().values():
                if not isinstance(layer, QgsVectorLayer):
                    continue
                if any(kw in layer.name().lower() for kw in skip_kw):
                    continue
                flds = [f.name() for f in layer.fields()]
                if zone_name_field in flds and zone_field in flds:
                    grouped_layer = layer
                    break

        if not grouped_layer:
            self.log_message("ERROR: No grouped PON layer found (needs 'zone_id' + 'zone_name').")
            self.log_message("Run 'Generate PON Groups' first.")
            return

        # ── 2. Locate the splitter points layer (optional — for count per zone) ───
        splitter_layer = None
        try:
            import sip
            if self.splitter_points_layer and not sip.isdeleted(self.splitter_points_layer):
                splitter_layer = self.splitter_points_layer
        except Exception:
            pass
        if not splitter_layer:
            for lyr in QgsProject.instance().mapLayers().values():
                if isinstance(lyr, QgsVectorLayer) and 'splitter' in lyr.name().lower():
                    splitter_layer = lyr
                    break

        # ── 3. Get span layer for snapping (optional) ────────────────────────────
        span_layer = self.comboBox_span_layer.currentLayer()

        self.log_message(f"\n=== Generating Aggregation Points (per Zone) ===")
        self.log_message(f"Source layer: '{grouped_layer.name()}'")
        if splitter_layer:
            self.log_message(f"Splitters:    '{splitter_layer.name()}'")
        else:
            self.log_message("Splitters:    not found — splitter_count will be 0")
        if span_layer:
            self.log_message(f"Snap to span: '{span_layer.name()}'")

        try:
            from qgis.PyQt.QtWidgets import QApplication as _QApp
            crs = grouped_layer.crs().authid()

            # ── 4. Collect demand-point centroids per zone ────────────────────────
            zone_points = {}     # zone_id -> list of QgsPointXY
            zone_names  = {}     # zone_id -> zone_name string

            for feat in grouped_layer.getFeatures():
                z_id   = feat[zone_field]
                z_name = feat[zone_name_field]
                if z_id is None:
                    continue
                if z_id not in zone_points:
                    zone_points[z_id]  = []
                    zone_names[z_id]   = z_name or f"Zone {z_id}"
                geom = feat.geometry()
                if geom and not geom.isEmpty():
                    zone_points[z_id].append(geom.centroid().asPoint())

            if not zone_points:
                self.log_message("ERROR: No zone features found in grouped layer.")
                return

            # ── 5. Count splitter points per zone ────────────────────────────────
            splitter_count_by_zone = {z_id: 0 for z_id in zone_points}
            if splitter_layer:
                sp_flds = [f.name() for f in splitter_layer.fields()]
                sp_zone_field = 'zone_id' if 'zone_id' in sp_flds else None
                if sp_zone_field:
                    for sp in splitter_layer.getFeatures():
                        sp_z = sp[sp_zone_field]
                        if sp_z in splitter_count_by_zone:
                            splitter_count_by_zone[sp_z] += 1
                else:
                    self.log_message("  Note: splitter layer has no 'zone_id' field — counts will be 0")

            # ── 6. Build output layer ─────────────────────────────────────────────
            agg_layer = QgsVectorLayer(f"Point?crs={crs}", "Aggregation Points", "memory")
            provider  = agg_layer.dataProvider()
            provider.addAttributes([
                QgsField('zone_id', QMetaType.Type.Int),
                QgsField('zone_name', QMetaType.Type.QString),
                QgsField('demand_count', QMetaType.Type.Int),
                QgsField('splitter_count', QMetaType.Type.Int),
                QgsField('label', QMetaType.Type.QString),
            ])
            agg_layer.updateFields()

            agg_features = []
            total_zones = len(zone_points)
            self._start_timer()
            _QApp.processEvents()

            for idx, z_id in enumerate(sorted(zone_points.keys())):
                self._progress(idx + 1, total_zones, 'Agg pts')
                pts = zone_points[z_id]
                if not pts:
                    continue

                # Zone centroid
                avg_x = sum(p.x() for p in pts) / len(pts)
                avg_y = sum(p.y() for p in pts) / len(pts)
                agg_pt = QgsPointXY(avg_x, avg_y)

                # Snap to nearest span line point if available
                if span_layer:
                    min_d = float('inf')
                    nearest = None
                    for sf in span_layer.getFeatures():
                        sg = sf.geometry()
                        if not sg or sg.isEmpty():
                            continue
                        np_ = sg.nearestPoint(QgsGeometry.fromPointXY(agg_pt))
                        if np_.isEmpty():
                            continue
                        npt = np_.asPoint()
                        d = math.hypot(agg_pt.x() - npt.x(), agg_pt.y() - npt.y())
                        if d < min_d:
                            min_d = d
                            nearest = npt
                    if nearest:
                        agg_pt = nearest

                z_name    = zone_names[z_id]
                sp_count  = splitter_count_by_zone.get(z_id, 0)
                d_count   = len(pts)
                lbl_text  = f"{z_name}\n{sp_count} splitter{'s' if sp_count != 1 else ''}"

                feat = QgsFeature(agg_layer.fields())
                feat.setGeometry(QgsGeometry.fromPointXY(agg_pt))
                feat.setAttributes([z_id, z_name, d_count, sp_count, lbl_text])
                agg_features.append(feat)

            provider.addFeatures(agg_features)
            agg_layer.updateExtents()

            # ── 7. Symbology — bold orange diamond ───────────────────────────────
            symbol = QgsMarkerSymbol.createSimple({
                'name':          'diamond',
                'color':         '255,140,0,255',
                'outline_color': '160,80,0,255',
                'outline_width': '0.6',
                'size':          '5',
            })
            agg_layer.setRenderer(QgsSingleSymbolRenderer(symbol))

            # ── 8. Labels — zone name + splitter count ────────────────────────────
            lbl_settings = QgsPalLayerSettings()
            lbl_settings.fieldName  = 'label'
            lbl_settings.isExpression = False
            lbl_settings.enabled    = True
            lbl_settings.placement  = QgsPalLayerSettings.Placement.OverPoint

            txt = QgsTextFormat()
            txt.setFont(QFont('Arial', 8, QFont.Bold))
            txt.setSize(8)
            txt.setColor(QColor('#3a1a00'))
            buf = QgsTextBufferSettings()
            buf.setEnabled(True)
            buf.setSize(0.8)
            buf.setColor(QColor('white'))
            txt.setBuffer(buf)
            lbl_settings.setFormat(txt)
            agg_layer.setLabeling(QgsVectorLayerSimpleLabeling(lbl_settings))
            agg_layer.setLabelsEnabled(True)

            QgsProject.instance().addMapLayer(agg_layer)

            self._elapsed("Total time")
            self.log_message(f"Created {len(agg_features)} aggregation points  ({total_zones} zones)")
            self.log_message(f"Fields: zone_id, zone_name, demand_count, splitter_count, label")
            if span_layer:
                self.log_message("Points snapped to nearest span location")
            for af in agg_features:
                self.log_message(
                    f"  {af['zone_name']}: {af['demand_count']} demand pts, "
                    f"{af['splitter_count']} splitter{'s' if af['splitter_count'] != 1 else ''}"
                )

        except Exception as e:
            self.log_message(f"ERROR generating aggregation points: {str(e)}")
            import traceback
            self.log_message(traceback.format_exc())

    def on_validate_span_network_clicked(self):
        """Validate span network topology and identify connectivity issues."""
        from qgis.core import QgsVectorLayer, QgsProject, QgsGeometry, QgsPointXY, QgsFeature
        from qgis.core import QgsMarkerSymbol, QgsSingleSymbolRenderer
        from qgis.PyQt.QtCore import QVariant, QMetaType
        from qgis.PyQt.QtGui import QColor
        import math
        
        self.log_message("="*60)
        self.log_message("VALIDATING SPAN NETWORK TOPOLOGY")
        self.log_message("="*60)
        self._start_timer()
        span_layer = self.comboBox_span_layer.currentLayer()
        if not span_layer:
            self.log_message("ERROR: No span layer selected")
            return
        
        # Validate geometry type
        geom_type = span_layer.geometryType()
        if geom_type != 1:  # LineString
            self.log_message(f"ERROR: Span layer must contain LineString geometry (found type {geom_type})")
            return
        
        self.log_message(f"Analyzing span layer: {span_layer.name()}")
        self.log_message(f"Total features: {span_layer.featureCount()}")
        
        # Build endpoint catalog
        endpoints = {}  # {(x, y): [feature_ids]}
        segment_endpoints = {}  # {feature_id: [(x1, y1), (x2, y2)]}
        valid_segments = 0
        
        for feat in span_layer.getFeatures():
            geom = feat.geometry()
            if geom and not geom.isNull():
                if geom.wkbType() in [2, 5]:  # LineString or MultiLineString
                    if geom.isMultipart():
                        lines = geom.asMultiPolyline()
                        if lines:
                            points = lines[0]
                        else:
                            continue
                    else:
                        points = geom.asPolyline()
                    
                    if len(points) >= 2:
                        valid_segments += 1
                        start = (round(points[0].x(), 4), round(points[0].y(), 4))
                        end = (round(points[-1].x(), 4), round(points[-1].y(), 4))
                        
                        segment_endpoints[feat.id()] = (start, end)
                        
                        # Track which segments connect to each endpoint
                        if start not in endpoints:
                            endpoints[start] = []
                        endpoints[start].append(feat.id())
                        
                        if end not in endpoints:
                            endpoints[end] = []
                        endpoints[end].append(feat.id())
        
        self.log_message(f"Valid line segments: {valid_segments}")
        self.log_message(f"Unique endpoints: {len(endpoints)}")
        
        # Analyze connectivity
        dead_ends = []  # Endpoints with only 1 connection
        junctions = []  # Endpoints with 3+ connections
        
        for coord, feature_ids in endpoints.items():
            connection_count = len(feature_ids)
            if connection_count == 1:
                dead_ends.append((coord, feature_ids[0]))
            elif connection_count >= 3:
                junctions.append((coord, connection_count))
        
        self.log_message(f"\nCONNECTIVITY ANALYSIS:")
        self.log_message(f"  Dead ends (dangling nodes): {len(dead_ends)}")
        self.log_message(f"  Junctions (3+ connections): {len(junctions)}")
        self.log_message(f"  Normal connections (2 segments): {len(endpoints) - len(dead_ends) - len(junctions)}")
        
        # Find disconnected components using flood-fill
        visited = set()
        components = []
        
        def flood_fill(start_coord):
            """Find all connected endpoints from starting point."""
            component = set()
            stack = [start_coord]
            
            while stack:
                coord = stack.pop()
                if coord in visited:
                    continue
                
                visited.add(coord)
                component.add(coord)
                
                # Find all segments connected to this endpoint
                if coord in endpoints:
                    for fid in endpoints[coord]:
                        if fid in segment_endpoints:
                            start, end = segment_endpoints[fid]
                            if start not in visited:
                                stack.append(start)
                            if end not in visited:
                                stack.append(end)
            
            return component
        
        # Find all connected components
        for coord in endpoints:
            if coord not in visited:
                component = flood_fill(coord)
                if component:
                    components.append(component)
        
        self.log_message(f"\nCOMPONENT ANALYSIS:")
        self.log_message(f"  Number of disconnected components: {len(components)}")
        
        for i, component in enumerate(components, 1):
            segment_count = sum(1 for fid, (s, e) in segment_endpoints.items() if s in component or e in component)
            self.log_message(f"  Component {i}: {len(component)} endpoints, {segment_count} segments")
        
        # Check aggregation points connectivity (if they exist)
        agg_layer = None
        for layer in QgsProject.instance().mapLayers().values():
            if isinstance(layer, QgsVectorLayer):
                if 'aggregation' in layer.name().lower() and 'point' in layer.name().lower():
                    agg_layer = layer
                    break
        
        if agg_layer and len(components) > 1:
            self.log_message(f"\nAGGREGATION POINTS ANALYSIS:")
            
            # Map each agg point to nearest component
            agg_to_component = {}
            
            for agg_feat in agg_layer.getFeatures():
                agg_geom = agg_feat.geometry()
                if agg_geom:
                    agg_point = agg_geom.asPoint()
                    agg_coord = (agg_point.x(), agg_point.y())
                    
                    # Find nearest endpoint in any component
                    min_dist = float('inf')
                    nearest_component = None
                    
                    for comp_idx, component in enumerate(components):
                        for endpoint in component:
                            dist = math.sqrt((agg_coord[0] - endpoint[0])**2 + 
                                           (agg_coord[1] - endpoint[1])**2)
                            if dist < min_dist:
                                min_dist = dist
                                nearest_component = comp_idx
                    
                    if nearest_component is not None:
                        if nearest_component not in agg_to_component:
                            agg_to_component[nearest_component] = []
                        agg_to_component[nearest_component].append(agg_feat['group_100'])
            
            # Report distribution
            for comp_idx in range(len(components)):
                agg_groups = agg_to_component.get(comp_idx, [])
                self.log_message(f"  Component {comp_idx + 1} has {len(agg_groups)} aggregation points")
                if agg_groups and len(agg_groups) <= 5:
                    self.log_message(f"    Groups: {', '.join(map(str, agg_groups))}")
        
        # Create visualization layer for problem areas
        if dead_ends or len(components) > 1:
            self.log_message("\nCREATING VISUALIZATION LAYER...")
            
            # Create problem points layer
            problem_layer = QgsVectorLayer(
                "Point?crs=" + span_layer.crs().authid(),
                "Span Network Issues",
                "memory"
            )
            
            provider = problem_layer.dataProvider()
            provider.addAttributes([
                QgsField("issue_type", QMetaType.Type.QString),
                QgsField("description", QMetaType.Type.QString),
                QgsField("component", QMetaType.Type.Int)
            ])
            problem_layer.updateFields()
            
            features = []
            
            # Add dead ends
            for coord, fid in dead_ends:
                feat = QgsFeature(problem_layer.fields())
                feat.setGeometry(QgsGeometry.fromPointXY(QgsPointXY(coord[0], coord[1])))
                feat['issue_type'] = 'Dead End'
                feat['description'] = f'Segment {fid} has dangling endpoint'
                feat['component'] = -1
                features.append(feat)
            
            # Add component markers (first endpoint of each component)
            for comp_idx, component in enumerate(components):
                if component:
                    coord = next(iter(component))
                    feat = QgsFeature(problem_layer.fields())
                    feat.setGeometry(QgsGeometry.fromPointXY(QgsPointXY(coord[0], coord[1])))
                    feat['issue_type'] = 'Component'
                    feat['description'] = f'Component {comp_idx + 1} ({len(component)} endpoints)'
                    feat['component'] = comp_idx + 1
                    features.append(feat)
            
            provider.addFeatures(features)
            
            # Style the layer
            symbol = QgsMarkerSymbol.createSimple({
                'name': 'triangle',
                'color': 'red',
                'size': '4',
                'outline_color': 'black',
                'outline_width': '0.5'
            })
            problem_layer.setRenderer(QgsSingleSymbolRenderer(symbol))
            
            QgsProject.instance().addMapLayer(problem_layer)
            self.log_message(f"Created layer 'Span Network Issues' with {len(features)} problem points")
        
        # Provide recommendations
        self.log_message("\n" + "="*60)
        self.log_message("RECOMMENDATIONS:")
        
        if len(components) > 1:
            self.log_message(f"  ⚠ CRITICAL: Network has {len(components)} disconnected components")
            self.log_message("  → Use Vector → Geometry Tools → Snap Geometries (tolerance: 0.0001)")
            self.log_message("  → Or use Processing → GRASS → v.clean (tools: break,snap,rmdupl)")
        
        if len(dead_ends) > 10:
            self.log_message(f"  ⚠ WARNING: {len(dead_ends)} dead ends found")
            self.log_message("  → Check if these are intentional network endpoints")
            self.log_message("  → Use Topology Checker to find gaps")
        
        if len(components) == 1 and len(dead_ends) <= 10:
            self.log_message("  ✓ Network appears well-connected!")
            self.log_message("  ✓ Ready for feeder route generation")
        
        self.log_message("="*60)
        self._elapsed("Validation")
        """Generate feeder cable routes from OLT to aggregation points."""
        from qgis.core import QgsVectorLayer, QgsFeature, QgsGeometry, QgsProject, QgsField, QgsPointXY
        from qgis.core import QgsLineSymbol, QgsCategorizedSymbolRenderer, QgsRendererCategory
        from qgis.PyQt.QtCore import QVariant, QMetaType
        from qgis.PyQt.QtGui import QColor
        import math
        
        # Get layers from combo boxes
        olt_layer = self.comboBox_olt_layer.currentLayer()
        if not olt_layer:
            self.log_message("ERROR: Please select an OLT layer (Start Point).")
            return
        
        agg_layer = self.comboBox_aggregation_layer.currentLayer()
        if not agg_layer:
            self.log_message("ERROR: Please select an Aggregation Points layer (End Points).")
            return
        
        span_layer = self.comboBox_routing_layer.currentLayer()
        if not span_layer:
            self.log_message("ERROR: Please select a Routing Layer (Path).")
            return
        
        # Validate layer types
        if olt_layer.geometryType() != 0:  # Point
            self.log_message("ERROR: OLT layer must be a Point layer.")
            return
        
        if agg_layer.geometryType() != 0:  # Point
            self.log_message("ERROR: Aggregation Points layer must be a Point layer.")
            return
        
        if span_layer.geometryType() != 1:  # LineString
            geom_types = {0: "Point", 1: "Line", 2: "Polygon"}
            actual_type = geom_types.get(span_layer.geometryType(), "Unknown")
            self.log_message(f"ERROR: Routing Layer must be a LineString layer!")
            self.log_message(f"  Selected layer '{span_layer.name()}' is {actual_type} geometry")
            return
        
        self.log_message(f"\n=== Generating Feeder Routes ===")
        self.log_message(f"OLT layer: '{olt_layer.name()}'")
        self.log_message(f"Aggregation points: '{agg_layer.name()}'")
        self.log_message(f"Routing layer: '{span_layer.name()}'")
        self._start_timer()
        try:
            # Get OLT point (use first one if multiple)
            olt_features = list(olt_layer.getFeatures())
            if len(olt_features) == 0:
                self.log_message("ERROR: OLT layer has no features.")
                return
            
            olt_point = olt_features[0].geometry().asPoint()
            self.log_message(f"OLT location: ({olt_point.x():.2f}, {olt_point.y():.2f})")
            
            # Get all aggregation points
            agg_points = []
            for feat in agg_layer.getFeatures():
                geom = feat.geometry()
                if geom and not geom.isEmpty():
                    point = geom.asPoint()
                    # Try to get group ID from various possible field names
                    group_id = None
                    for field_name in ['group_id', 'group_100', 'group', 'id']:
                        if field_name in feat.fields().names():
                            group_id = feat[field_name]
                            break
                    if group_id is None:
                        group_id = feat.id()
                    
                    agg_points.append({
                        'id': feat.id(),
                        'group_id': group_id,
                        'point': point,
                        'feature': feat
                    })
            
            if len(agg_points) == 0:
                self.log_message("ERROR: No aggregation points found.")
                return
            
            self.log_message(f"Found {len(agg_points)} aggregation points")
            
            # Build span network graph with tolerance-based endpoint clustering
            span_features = list(span_layer.getFeatures())
            
            self.log_message(f"Processing {len(span_features)} span segments...")
            
            # First pass: collect all raw endpoints
            raw_endpoints = []  # List of (x, y, segment_geom, is_start)
            segments_processed = 0
            
            for span_feat in span_features:
                geom = span_feat.geometry()
                if not geom or geom.isEmpty():
                    continue
                
                if geom.type() == 1:  # LineString
                    try:
                        if geom.isMultipart():
                            lines = geom.asMultiPolyline()
                            if lines:
                                vertices = lines[0]
                            else:
                                continue
                        else:
                            vertices = geom.asPolyline()
                        
                        if len(vertices) >= 2:
                            start = vertices[0]
                            end = vertices[-1]
                            raw_endpoints.append((start.x(), start.y(), geom, True))
                            raw_endpoints.append((end.x(), end.y(), geom, False))
                            segments_processed += 1
                    except Exception as e:
                        self.log_message(f"  Error processing segment: {str(e)}")
                        continue
            
            self.log_message(f"Processed {segments_processed} valid line segments")
            self.log_message(f"Found {len(raw_endpoints)} raw endpoints")
            
            # Second pass: cluster nearby endpoints
            # Auto-detect appropriate tolerance based on coordinate system
            # If coordinates are in degrees (lat/lon), use smaller tolerance
            # If in meters (projected), use larger tolerance
            sample_coords = [abs(x) for x, y, g, s in raw_endpoints[:10]]
            avg_coord = sum(sample_coords) / len(sample_coords) if sample_coords else 0
            
            if avg_coord < 360:  # Likely degrees (lat/lon)
                snap_tolerance = 0.0005  # ~50 meters in degrees - generous to connect nearby segments
                self.log_message(f"Detected geographic coordinates (degrees), using tolerance: {snap_tolerance} (~50m)")
            else:  # Likely meters (projected)
                snap_tolerance = 50.0  # 50 meters
                self.log_message(f"Detected projected coordinates (meters), using tolerance: {snap_tolerance}m")
            
            endpoint_clusters = []  # Each cluster = list of (x, y, geom, is_start)
            used = [False] * len(raw_endpoints)
            
            for i, (x1, y1, geom1, is_start1) in enumerate(raw_endpoints):
                if used[i]:
                    continue
                
                cluster = [(x1, y1, geom1, is_start1)]
                used[i] = True
                
                # Find all endpoints within tolerance
                for j, (x2, y2, geom2, is_start2) in enumerate(raw_endpoints):
                    if used[j]:
                        continue
                    
                    dist = math.sqrt((x1 - x2)**2 + (y1 - y2)**2)
                    if dist <= snap_tolerance:
                        cluster.append((x2, y2, geom2, is_start2))
                        used[j] = True
                
                endpoint_clusters.append(cluster)
            
            self.log_message(f"Clustered into {len(endpoint_clusters)} network nodes (tolerance: {snap_tolerance})")
            
            # Determine rounding precision based on coordinate system
            if avg_coord < 360:  # Geographic coordinates (degrees)
                round_precision = 6  # 6 decimal places = ~0.1m precision
            else:  # Projected coordinates (meters)
                round_precision = 2  # 2 decimal places = 1cm precision
            
            # Third pass: build network graph using clustered nodes
            network_graph = {}  # node_key -> [(connected_node_key, segment_geom)]
            node_to_cluster = {}  # Maps approximate coordinate to cluster centroid
            
            for cluster in endpoint_clusters:
                # Calculate cluster centroid
                avg_x = sum(x for x, y, g, s in cluster) / len(cluster)
                avg_y = sum(y for x, y, g, s in cluster) / len(cluster)
                centroid = (round(avg_x, round_precision), round(avg_y, round_precision))
                
                # Map all endpoints in cluster to the centroid
                for x, y, geom, is_start in cluster:
                    node_to_cluster[(round(x, round_precision), round(y, round_precision))] = centroid
                
                if centroid not in network_graph:
                    network_graph[centroid] = []
            
            # Connect nodes based on segment connectivity
            for span_feat in span_features:
                geom = span_feat.geometry()
                if not geom or geom.isEmpty() or geom.type() != 1:
                    continue
                
                try:
                    if geom.isMultipart():
                        lines = geom.asMultiPolyline()
                        if lines:
                            vertices = lines[0]
                        else:
                            continue
                    else:
                        vertices = geom.asPolyline()
                    
                    if len(vertices) >= 2:
                        start = vertices[0]
                        end = vertices[-1]
                        
                        start_approx = (round(start.x(), round_precision), round(start.y(), round_precision))
                        end_approx = (round(end.x(), round_precision), round(end.y(), round_precision))
                        
                        if start_approx in node_to_cluster and end_approx in node_to_cluster:
                            start_node = node_to_cluster[start_approx]
                            end_node = node_to_cluster[end_approx]
                            
                            if start_node != end_node:  # Avoid self-loops
                                network_graph[start_node].append((end_node, geom))
                                network_graph[end_node].append((start_node, geom))
                except:
                    continue
            
            self.log_message(f"Built network graph with {len(network_graph)} nodes")
            
            # Analyze network connectivity - find connected components
            def find_connected_components(graph):
                """Find all connected components using flood-fill."""
                visited = set()
                components = []
                
                for start_node in graph.keys():
                    if start_node in visited:
                        continue
                    
                    # BFS from this node
                    component = []
                    queue = [start_node]
                    while queue:
                        node = queue.pop(0)
                        if node in visited:
                            continue
                        visited.add(node)
                        component.append(node)
                        
                        for neighbor, _ in graph.get(node, []):
                            if neighbor not in visited:
                                queue.append(neighbor)
                    
                    components.append(component)
                
                return components
            
            components = find_connected_components(network_graph)
            self.log_message(f"Network has {len(components)} connected component(s)")
            if len(components) > 1:
                component_sizes = sorted([len(c) for c in components], reverse=True)
                self.log_message(f"  Component sizes: {component_sizes[:5]}{'...' if len(components) > 5 else ''}")
            
            # Snap points to nearest network node using tolerance
            def snap_to_network_node(point, max_snap_dist=1000.0):
                """Find nearest network node to a point."""
                min_dist = float('inf')
                nearest_node = None
                
                for node in network_graph.keys():
                    dist = math.sqrt(
                        (point.x() - node[0])**2 + 
                        (point.y() - node[1])**2
                    )
                    if dist < min_dist:
                        min_dist = dist
                        nearest_node = node
                
                if min_dist > max_snap_dist:
                    return None, float('inf')
                
                return nearest_node, min_dist
            
            olt_node, olt_dist = snap_to_network_node(olt_point)
            if olt_node is None:
                self.log_message(f"ERROR: OLT is too far from span network (distance: {olt_dist:.2f})")
                self.log_message("Please move OLT closer to the span layer or check span layer coverage.")
                return
            
            self.log_message(f"OLT snapped to network node (distance: {olt_dist:.2f})")
            self.log_message(f"OLT node: ({olt_node[0]:.4f}, {olt_node[1]:.4f})")
            
            # Snap all aggregation points
            self.log_message("\nSnapping aggregation points to network...")
            snapped_count = 0
            for agg in agg_points:
                agg['network_node'], agg['snap_dist'] = snap_to_network_node(agg['point'])
                if agg['network_node'] is not None:
                    snapped_count += 1
                else:
                    self.log_message(f"  WARNING: Agg {agg['group_id']} too far from network (dist: {agg['snap_dist']:.2f})")
            
            self.log_message(f"Successfully snapped {snapped_count}/{len(agg_points)} aggregation points to network")
            
            if snapped_count == 0:
                self.log_message("ERROR: No aggregation points could be snapped to span network.")
                self.log_message("Aggregation points may be too far from span layer.")
                return
            
            # Find furthest aggregation point from OLT (this defines main route)
            def network_distance(start_node, end_node):
                """Calculate shortest path through network using Dijkstra.
                Returns distance, path of nodes, and list of segment geometries."""
                if start_node not in network_graph or end_node not in network_graph:
                    return float('inf'), [], []
                
                import heapq
                distances = {start_node: 0}
                previous = {start_node: (None, None)}  # (previous_node, segment_geom)
                pq = [(0, start_node)]
                visited = set()
                
                while pq:
                    current_dist, current_node = heapq.heappop(pq)
                    
                    if current_node in visited:
                        continue
                    
                    visited.add(current_node)
                    
                    if current_node == end_node:
                        # Reconstruct path and segments
                        path = []
                        segments = []
                        node = end_node
                        while node is not None:
                            path.append(node)
                            prev_node, segment = previous.get(node, (None, None))
                            if segment is not None:
                                segments.append(segment)
                            node = prev_node
                        path.reverse()
                        segments.reverse()
                        return current_dist, path, segments
                    
                    for neighbor, segment_geom in network_graph.get(current_node, []):
                        if neighbor in visited:
                            continue
                        
                        edge_dist = segment_geom.length()
                        new_dist = current_dist + edge_dist
                        
                        if neighbor not in distances or new_dist < distances[neighbor]:
                            distances[neighbor] = new_dist
                            previous[neighbor] = (current_node, segment_geom)
                            heapq.heappush(pq, (new_dist, neighbor))
                
                return float('inf'), [], []
            
            # Calculate distances to all aggregation points
            self.log_message("\nCalculating routes to aggregation points...")
            for agg in agg_points:
                dist, path, segments = network_distance(olt_node, agg['network_node'])
                agg['network_distance'] = dist
                agg['path'] = path
                agg['segments'] = segments
                self.log_message(f"  Agg {agg['group_id']}: distance={dist:.2f}, path nodes={len(path)}, segments={len(segments)}")
            
            # Filter out only truly unreachable points (infinite distance or same node as OLT)
            reachable_agg_points = [agg for agg in agg_points if agg['network_distance'] < float('inf')]
            unreachable_agg_points = [agg for agg in agg_points if agg['network_distance'] == float('inf')]
            
            if len(reachable_agg_points) == 0:
                self.log_message("ERROR: No aggregation points are reachable from OLT via the span network.")
                self.log_message("Please check that:")
                self.log_message("  1. OLT and aggregation points are near the span layer")
                self.log_message("  2. Span segments are connected (endpoints touch)")
                return
            
            if len(unreachable_agg_points) > 0:
                self.log_message(f"\nWARNING: {len(unreachable_agg_points)} aggregation points are not reachable:")
                # Analyze why they're unreachable
                for agg in unreachable_agg_points:
                    if agg['network_node'] is None:
                        self.log_message(f"  Agg {agg['group_id']}: Too far from span network")
                    else:
                        # Check if this node is in a different connected component
                        node = agg['network_node']
                        if node in network_graph:
                            neighbor_count = len(network_graph[node])
                            self.log_message(f"  Agg {agg['group_id']}: On disconnected component ({neighbor_count} neighbors at node)")
                        else:
                            self.log_message(f"  Agg {agg['group_id']}: Snapped to invalid node")
            
            # Use Prim's algorithm to build Minimum Spanning Tree from OLT to all aggregation points
            # This creates a single connected network (main trunk + branches)
            
            def prim_mst(start_node, terminal_nodes, graph):
                """
                Build Minimum Spanning Tree using Prim's algorithm.
                Returns tree as dict of parent relationships and edge geometries.
                """
                import heapq
                
                # MST edges: {node: (parent_node, edge_geom, distance)}
                mst = {start_node: (None, None, 0)}
                in_tree = {start_node}
                terminals_needed = set(terminal_nodes)
                
                # Priority queue: (distance, current_node, next_node, edge_geom)
                pq = []
                
                # Add all edges from start node
                for neighbor, edge_geom in graph.get(start_node, []):
                    dist = edge_geom.length()
                    heapq.heappush(pq, (dist, start_node, neighbor, edge_geom))
                
                while pq and terminals_needed:
                    dist, from_node, to_node, edge_geom = heapq.heappop(pq)
                    
                    if to_node in in_tree:
                        continue
                    
                    # Add to tree
                    mst[to_node] = (from_node, edge_geom, dist)
                    in_tree.add(to_node)
                    terminals_needed.discard(to_node)
                    
                    # Add edges from newly added node
                    for neighbor, neighbor_edge in graph.get(to_node, []):
                        if neighbor not in in_tree:
                            neighbor_dist = neighbor_edge.length()
                            heapq.heappush(pq, (neighbor_dist, to_node, neighbor, neighbor_edge))
                
                return mst
            
            # Get aggregation node locations
            agg_nodes = set(agg['network_node'] for agg in reachable_agg_points if agg['network_node'])
            
            self.log_message(f"\nBuilding Minimum Spanning Tree from OLT to {len(agg_nodes)} aggregation points...")
            
            # Build MST
            mst_tree = prim_mst(olt_node, agg_nodes, network_graph)
            
            # Create unique edges from MST - ONLY include edges needed to reach aggregation points
            # Each path stops at an aggregation point (no pass-through beyond agg points)
            mst_edges = {}  # {edge_key: {'from': node, 'to': node, 'geom': geom}}
            
            # For each aggregation point, trace back to OLT and collect needed edges
            needed_edges = set()
            for agg_node in agg_nodes:
                current = agg_node
                while current in mst_tree:
                    parent, edge_geom, dist = mst_tree[current]
                    if parent is None:
                        break
                    edge_key = tuple(sorted([current, parent]))
                    needed_edges.add(edge_key)
                    current = parent
            
            # Only include edges that are needed to reach aggregation points
            for node, (parent, edge_geom, dist) in mst_tree.items():
                if parent is None or edge_geom is None:
                    continue
                
                edge_key = tuple(sorted([node, parent]))
                
                # Only include if this edge is needed
                if edge_key in needed_edges and edge_key not in mst_edges:
                    mst_edges[edge_key] = {
                        'from': parent,
                        'to': node,
                        'geom': edge_geom,
                        'distance': dist
                    }
            
            self.log_message(f"MST has {len(mst_edges)} unique edges (pruned to reach agg points only)")
            
            # Find the path from OLT to each aggregation point
            def get_path_to_olt(node):
                """Get list of nodes from given node back to OLT."""
                path = []
                current = node
                while current in mst_tree:
                    path.append(current)
                    parent, _, _ = mst_tree[current]
                    if parent is None:
                        break
                    current = parent
                return path
            
            # Calculate geographic direction and distance for each aggregation point
            import math
            
            def get_direction(from_point, to_point):
                """Get compass direction in degrees (0=North, 90=East, 180=South, 270=West)."""
                dx = to_point[0] - from_point[0]
                dy = to_point[1] - from_point[1]
                angle = math.degrees(math.atan2(dx, dy))  # atan2(x,y) gives angle from North
                if angle < 0:
                    angle += 360
                return angle
            
            def get_quadrant(angle):
                """Get quadrant: 0=North, 1=East, 2=South, 3=West."""
                return int((angle + 45) % 360 / 90)
            
            # Analyze each aggregation point
            agg_analysis = []
            for agg in reachable_agg_points:
                if agg['network_node']:
                    path = get_path_to_olt(agg['network_node'])
                    # Calculate total path distance (network distance)
                    total_dist = 0
                    for node in path[:-1]:
                        if node in mst_tree:
                            _, edge_geom, _ = mst_tree[node]
                            if edge_geom:
                                total_dist += edge_geom.length()
                    
                    # Calculate direct geographic distance and direction from OLT
                    agg_node = agg['network_node']
                    direct_dist = math.sqrt((agg_node[0] - olt_node[0])**2 + (agg_node[1] - olt_node[1])**2)
                    direction = get_direction(olt_node, agg_node)
                    quadrant = get_quadrant(direction)
                    
                    agg_analysis.append({
                        'agg': agg,
                        'path': path,
                        'network_dist': total_dist,
                        'direct_dist': direct_dist,
                        'direction': direction,
                        'quadrant': quadrant
                    })
            
            # Group aggregation points by quadrant
            quadrants = {0: [], 1: [], 2: [], 3: []}  # N, E, S, W
            for analysis in agg_analysis:
                quadrants[analysis['quadrant']].append(analysis)
            
            # Sort each quadrant by direct distance (furthest first)
            for q in quadrants:
                quadrants[q].sort(key=lambda x: x['direct_dist'], reverse=True)
            
            # Select main trunk endpoints: furthest point in opposite directions
            main_trunk_endpoints = []
            main_trunk_paths = []
            
            # Find quadrants with aggregation points
            populated_quadrants = [q for q in range(4) if quadrants[q]]
            
            self.log_message(f"\nQuadrant analysis (from OLT):")
            quadrant_names = ['North', 'East', 'South', 'West']
            for q in range(4):
                count = len(quadrants[q])
                if count > 0:
                    furthest = quadrants[q][0]['agg']['group_id']
                    self.log_message(f"  {quadrant_names[q]}: {count} points, furthest: Agg {furthest}")
                else:
                    self.log_message(f"  {quadrant_names[q]}: 0 points")
            
            # Select main trunks from opposite quadrants (N-S or E-W preference)
            if populated_quadrants:
                # Try to get opposite quadrants first
                opposite_pairs = [(0, 2), (1, 3), (2, 0), (3, 1)]  # N-S, E-W pairs
                
                for q1, q2 in opposite_pairs:
                    if quadrants[q1] and quadrants[q2]:
                        # Found opposite quadrants with points
                        main_trunk_endpoints.append(quadrants[q1][0]['agg'])
                        main_trunk_paths.append(set(quadrants[q1][0]['path']))
                        main_trunk_endpoints.append(quadrants[q2][0]['agg'])
                        main_trunk_paths.append(set(quadrants[q2][0]['path']))
                        break
                
                # If no opposite pair found, just use the 2 most populated quadrants
                if not main_trunk_endpoints:
                    sorted_quadrants = sorted(populated_quadrants, key=lambda q: len(quadrants[q]), reverse=True)
                    for q in sorted_quadrants[:2]:
                        if quadrants[q]:
                            main_trunk_endpoints.append(quadrants[q][0]['agg'])
                            main_trunk_paths.append(set(quadrants[q][0]['path']))
            
            self.log_message(f"\nMain trunk endpoints: {len(main_trunk_endpoints)}")
            for i, agg in enumerate(main_trunk_endpoints):
                self.log_message(f"  Main {i+1}: Agg {agg['group_id']}")
            
            # Collect all edges that are part of main trunk paths
            main_trunk_edges = set()
            for path_set in main_trunk_paths:
                path_list = list(path_set)
                for node in path_list:
                    if node in mst_tree:
                        parent, _, _ = mst_tree[node]
                        if parent is not None:
                            edge_key = tuple(sorted([node, parent]))
                            main_trunk_edges.add(edge_key)
            
            self.log_message(f"Main trunk has {len(main_trunk_edges)} edges")
            
            # Determine edge hierarchy level (distance from main trunk)
            def get_edge_level(edge_key, visited=None):
                """
                Get hierarchy level of an edge:
                0 = Main trunk (144F)
                1 = Direct branch from main (96F)
                2+ = Branch from branch (72F)
                """
                if edge_key in main_trunk_edges:
                    return 0
                
                if visited is None:
                    visited = set()
                
                if edge_key in visited:
                    return 999  # Avoid infinite loops
                visited.add(edge_key)
                
                edge_data = mst_edges.get(edge_key)
                if not edge_data:
                    return 999
                
                # Find the parent edge (edge that connects 'from' node to its parent)
                from_node = edge_data['from']
                if from_node in mst_tree:
                    parent_of_from, _, _ = mst_tree[from_node]
                    if parent_of_from is not None:
                        parent_edge_key = tuple(sorted([from_node, parent_of_from]))
                        parent_level = get_edge_level(parent_edge_key, visited)
                        return parent_level + 1
                
                # If from_node is OLT, this is level 1 (direct from OLT but not main)
                if from_node == olt_node:
                    return 1
                
                return 1  # Default to level 1
            
            # Calculate total demand at each aggregation point
            # This is used to determine cable sizing based on actual demand
            total_demand = len(reachable_agg_points)  # Count of aggregation points
            
            # Use cable profile system to determine appropriate fiber sizes
            # Main trunk carries all demand, spurs carry partial demand
            main_fiber_count = get_cable_profile(total_demand * 8, PROFILE_TYPE_POPC)  # 8 fibers per agg point estimate
            spur_fiber_count = get_cable_profile(total_demand * 4, PROFILE_TYPE_POPC)
            sub_spur_fiber_count = get_cable_profile(8, PROFILE_TYPE_DEFAULT)  # Minimum for single group
            
            self.log_message(f"\nCable Profile Calculation (using POPC 30% reserve):")
            self.log_message(f"  Estimated demand: {total_demand} aggregation points")
            self.log_message(f"  Main trunk: {format_cable_profile(main_fiber_count)} (for {total_demand * 8} est. fibers)")
            self.log_message(f"  Spur: {format_cable_profile(spur_fiber_count)}")
            self.log_message(f"  Sub-Spur: {format_cable_profile(sub_spur_fiber_count)}")
            
            # Assign fiber sizes based on hierarchy level
            for edge_key, edge_data in mst_edges.items():
                level = get_edge_level(edge_key)
                edge_data['level'] = level
                
                if level == 0:
                    edge_data['fiber_size'] = format_cable_profile(main_fiber_count)
                    edge_data['fiber_count'] = main_fiber_count
                    edge_data['route_type'] = 'Main'
                elif level == 1:
                    edge_data['fiber_size'] = format_cable_profile(spur_fiber_count)
                    edge_data['fiber_count'] = spur_fiber_count
                    edge_data['route_type'] = 'Spur'
                else:  # level >= 2
                    edge_data['fiber_size'] = format_cable_profile(sub_spur_fiber_count)
                    edge_data['fiber_count'] = sub_spur_fiber_count
                    edge_data['route_type'] = 'Sub-Spur'
            
            self.log_message(f"\nNetwork Structure:")
            fiber_counts = {}
            for edge_data in mst_edges.values():
                fs = edge_data['fiber_size']
                fiber_counts[fs] = fiber_counts.get(fs, 0) + 1
            for fs, count in sorted(fiber_counts.items()):
                self.log_message(f"  {fs}: {count} segments")
            
            # Create feeder routes layer
            crs = span_layer.crs().authid()
            feeder_layer = QgsVectorLayer(f"LineString?crs={crs}", 
                                         "Feeder Routes", 
                                         "memory")
            provider = feeder_layer.dataProvider()
            
            # Add fields
            provider.addAttributes([
                QgsField('route_id', QMetaType.Type.Int),
                QgsField('route_type', QMetaType.Type.QString),  # 'Main', 'Spur', 'Sub-Spur'
                QgsField('fiber_size', QMetaType.Type.QString),  # e.g., '144F', '96F', '72F'
                QgsField('fiber_count', QMetaType.Type.Int),    # Numeric fiber count
                QgsField('level', QMetaType.Type.Int),          # Hierarchy level (0=Main, 1=Spur, 2+=Sub-Spur)
                QgsField('length', QMetaType.Type.Double)
            ])
            feeder_layer.updateFields()
            
            route_features = []
            route_id = 1
            
            self.log_message("\nCreating route geometries...")
            
            # Determine dedup tolerance
            if avg_coord < 360:  # Degrees
                dedup_tolerance = 0.000001
            else:  # Meters
                dedup_tolerance = 0.001
            
            # Create a feature for each unique MST edge
            for edge_key, edge_data in mst_edges.items():
                segment = edge_data['geom']
                
                try:
                    if segment.isMultipart():
                        lines = segment.asMultiPolyline()
                        if lines:
                            vertices = lines[0]
                        else:
                            continue
                    else:
                        vertices = segment.asPolyline()
                    
                    if len(vertices) >= 2:
                        route_geom = QgsGeometry.fromPolylineXY(vertices)
                        route_feat = QgsFeature(feeder_layer.fields())
                        route_feat.setGeometry(route_geom)
                        route_feat.setAttributes([
                            route_id,
                            edge_data['route_type'],
                            edge_data['fiber_size'],
                            edge_data['fiber_count'],
                            edge_data['level'],
                            route_geom.length()
                        ])
                        route_features.append(route_feat)
                        route_id += 1
                except Exception as e:
                    self.log_message(f"  Error creating edge geometry: {str(e)}")
                    continue
            
            if len(route_features) == 0:
                self.log_message("ERROR: No route features were created!")
                self.log_message("Check that aggregation points can be reached from OLT via span network.")
                return
            
            # Add features to layer
            self.log_message(f"\nAdding {len(route_features)} route segments to layer...")
            provider.addFeatures(route_features)
            feeder_layer.updateExtents()
            
            # Apply categorized symbology by fiber size
            categories = []
            # Dynamic fiber colors based on calculated profiles
            fiber_colors = {
                format_cable_profile(main_fiber_count): ('255,0,0', '3.0'),      # Red, thick - Main
                format_cable_profile(spur_fiber_count): ('255,128,0', '2.0'),    # Orange, medium - Spur
                format_cable_profile(sub_spur_fiber_count): ('255,255,0', '1.5') # Yellow, thin - Sub-Spur
            }
            
            for fiber_size, (color, width) in fiber_colors.items():
                symbol = QgsLineSymbol.createSimple({
                    'color': color,
                    'width': width,
                    'capstyle': 'round'
                })
                category = QgsRendererCategory(
                    fiber_size,
                    symbol,
                    f"{fiber_size} Fiber"
                )
                categories.append(category)
            
            renderer = QgsCategorizedSymbolRenderer('fiber_size', categories)
            feeder_layer.setRenderer(renderer)
            
            # Add layer to project
            QgsProject.instance().addMapLayer(feeder_layer)
            
            # Calculate statistics
            total_length = sum(feat['length'] for feat in route_features)
            main_count = sum(1 for f in route_features if f['route_type'] == 'Main')
            spur_count = sum(1 for f in route_features if f['route_type'] == 'Spur')
            sub_spur_count = sum(1 for f in route_features if f['route_type'] == 'Sub-Spur')
            
            self.log_message(f"\nCreated {len(route_features)} feeder route segments (no overlaps)")
            self.log_message(f"  Main trunk: {main_count} segments ({format_cable_profile(main_fiber_count)}) - to furthest aggregation points")
            self.log_message(f"  Spurs: {spur_count} segments ({format_cable_profile(spur_fiber_count)}) - branches from main trunk")
            self.log_message(f"  Sub-Spurs: {sub_spur_count} segments ({format_cable_profile(sub_spur_fiber_count)}) - branches from spurs")
            self.log_message(f"Total route length: {total_length:.4f} units")
            self.log_message(f"Layer: '{feeder_layer.name()}'")
            self.log_message("\nHierarchy (Cable Profiles - POPC 30% Reserve):")
            self.log_message(f"  {format_cable_profile(main_fiber_count)} (Red) - Main trunk from OLT to furthest points")
            self.log_message(f"  {format_cable_profile(spur_fiber_count)} (Orange) - Spur cables branching from main")
            self.log_message(f"  {format_cable_profile(sub_spur_fiber_count)} (Yellow) - Sub-spurs branching from spurs")
            self.log_message(f"\nAvailable cable profiles: {', '.join(format_cable_profile(p) for p in CABLE_PROFILES)}")
            self._elapsed("Total time")
        except Exception as e:
            self.log_message(f"ERROR generating feeder routes: {str(e)}")
            import traceback
            self.log_message(traceback.format_exc())

    def on_pole_distance_changed(self, index):
        """Enable/disable custom distance input based on selection."""
        # "Custom..." is the last item (index 10)
        is_custom = self.comboBox_pole_distance.currentText() == "Custom..."
        self.spinBox_custom_distance.setEnabled(is_custom)

    def on_generate_poles_clicked(self):
        """Generate pole points along span layer at specified intervals."""
        span_layer = self.comboBox_pole_span_layer.currentLayer()
        
        if not span_layer:
            self.log_message("ERROR: Please select a span layer for pole generation.")
            return
        
        # Check if layer has line geometry
        if span_layer.geometryType() != QgsWkbTypes.LineGeometry:
            self.log_message("ERROR: Span layer must be a line layer.")
            return
        
        # Get distance
        distance_text = self.comboBox_pole_distance.currentText()
        if distance_text == "Custom...":
            distance_meters = self.spinBox_custom_distance.value()
        else:
            distance_meters = int(distance_text)
        
        self.log_message(f"\n=== Generating Poles ===")
        self.log_message(f"Span layer: '{span_layer.name()}'")
        self.log_message(f"Distance between poles: {distance_meters}m")
        
        try:
            # Import required modules
            from qgis.core import QgsVectorLayer, QgsFeature, QgsGeometry, QgsProject, QgsField
            from qgis.PyQt.QtCore import QVariant, QMetaType
            self._start_timer()
            # Check CRS and convert distance if necessary
            crs = span_layer.crs()
            is_geographic = crs.isGeographic()
            
            if is_geographic:
                # Convert meters to approximate degrees (at equator ~111320m per degree)
                # For more accuracy, we'll use the layer's center latitude
                extent = span_layer.extent()
                center_lat = (extent.yMinimum() + extent.yMaximum()) / 2
                import math
                meters_per_degree = 111320 * math.cos(math.radians(center_lat))
                distance_units = distance_meters / meters_per_degree
                self.log_message(f"Geographic CRS detected. Converting {distance_meters}m to ~{distance_units:.6f} degrees")
            else:
                # Assume meters
                distance_units = distance_meters
                self.log_message(f"Projected CRS detected. Using {distance_units}m directly")
            
            # Create output pole layer
            pole_layer = QgsVectorLayer(f"Point?crs={crs.authid()}", 
                                       f"Poles_{distance_meters}m", 
                                       "memory")
            provider = pole_layer.dataProvider()
            
            # Add fields
            provider.addAttributes([
                QgsField('pole_id', QMetaType.Type.Int),
                QgsField('span_id', QMetaType.Type.Int),
                QgsField('distance_along', QMetaType.Type.Double),
                QgsField('pole_type', QMetaType.Type.QString)  # 'start', 'intermediate', 'end'
            ])
            pole_layer.updateFields()
            
            pole_features = []
            pole_id = 1
            total_poles = 0
            
            # Global deduplication: one pole per unique coordinate across ALL spans.
            # Shared junction points (where 2+ lines meet) get exactly one pole.
            global_placed_coords = set()
            
            # Process each span segment
            for span_feat in span_layer.getFeatures():
                geom = span_feat.geometry()
                if not geom or geom.isEmpty():
                    continue
                
                span_id = span_feat.id()
                
                # Get line geometry
                if geom.isMultipart():
                    lines = geom.asMultiPolyline()
                else:
                    lines = [geom.asPolyline()]
                
                for line in lines:
                    if len(line) < 2:
                        continue
                    
                    cumulative = 0.0

                    for i, vertex in enumerate(line):
                        # Every vertex gets a pole — type reflects its role in the polyline
                        if i == 0:
                            vtype = 'start'
                        elif i == len(line) - 1:
                            vtype = 'end'
                        else:
                            vtype = 'kink'  # Direction-change vertex

                        key = (round(vertex.x(), 4), round(vertex.y(), 4))
                        if key not in global_placed_coords:
                            global_placed_coords.add(key)
                            dist_out = cumulative if not is_geographic else cumulative * meters_per_degree
                            pole_feat = QgsFeature(pole_layer.fields())
                            pole_feat.setGeometry(QgsGeometry.fromPointXY(vertex))
                            pole_feat.setAttributes([pole_id, span_id, round(dist_out, 2), vtype])
                            pole_features.append(pole_feat)
                            pole_id += 1
                            total_poles += 1

                        # Fill the segment to the NEXT vertex with intermediate poles
                        # if it is longer than the requested spacing.
                        if i < len(line) - 1:
                            nv = line[i + 1]
                            dx = nv.x() - vertex.x()
                            dy = nv.y() - vertex.y()
                            seg_len = math.sqrt(dx * dx + dy * dy)

                            if seg_len > distance_units:
                                n_steps = int(seg_len / distance_units)
                                for k in range(1, n_steps + 1):
                                    frac = (k * distance_units) / seg_len
                                    if frac >= 0.999:
                                        break  # Next vertex will place its own pole
                                    ix = vertex.x() + frac * dx
                                    iy = vertex.y() + frac * dy
                                    ikey = (round(ix, 4), round(iy, 4))
                                    if ikey not in global_placed_coords:
                                        global_placed_coords.add(ikey)
                                        int_dist = cumulative + k * distance_units
                                        dist_out = int_dist if not is_geographic else int_dist * meters_per_degree
                                        pole_feat = QgsFeature(pole_layer.fields())
                                        pole_feat.setGeometry(QgsGeometry.fromPointXY(QgsPointXY(ix, iy)))
                                        pole_feat.setAttributes([pole_id, span_id, round(dist_out, 2), 'intermediate'])
                                        pole_features.append(pole_feat)
                                        pole_id += 1
                                        total_poles += 1

                            cumulative += seg_len
            
            if len(pole_features) == 0:
                self.log_message("WARNING: No poles were generated. Check span layer geometry.")
                return
            
            # Add features to layer
            provider.addFeatures(pole_features)
            pole_layer.updateExtents()
            
            # Apply symbology - different colors for pole types
            from qgis.core import QgsMarkerSymbol, QgsCategorizedSymbolRenderer, QgsRendererCategory
            categories = []
            pole_styles = {
                'start': ('0,128,0', 3.5),        # Green, larger
                'intermediate': ('0,0,255', 2.5), # Blue, medium
                'kink': ('255,165,0', 3.5),       # Orange, larger (direction-change vertices)
                'end': ('255,0,0', 3.5)           # Red, larger
            }
            
            for pole_type, (color, size) in pole_styles.items():
                symbol = QgsMarkerSymbol.createSimple({
                    'name': 'circle',
                    'color': color,
                    'size': str(size),
                    'outline_color': 'black',
                    'outline_width': '0.5'
                })
                category = QgsRendererCategory(
                    pole_type,
                    symbol,
                    pole_type.capitalize()
                )
                categories.append(category)
            
            renderer = QgsCategorizedSymbolRenderer('pole_type', categories)
            pole_layer.setRenderer(renderer)
            
            # Add layer to project
            QgsProject.instance().addMapLayer(pole_layer)
            
            # Count poles by type
            start_count = sum(1 for f in pole_features if f['pole_type'] == 'start')
            intermediate_count = sum(1 for f in pole_features if f['pole_type'] == 'intermediate')
            kink_count = sum(1 for f in pole_features if f['pole_type'] == 'kink')
            end_count = sum(1 for f in pole_features if f['pole_type'] == 'end')
            
            self.log_message(f"\nGenerated {total_poles} poles")
            self.log_message(f"  Start poles: {start_count} (Green)")
            self.log_message(f"  Intermediate poles: {intermediate_count} (Blue)")
            self.log_message(f"  Kink poles (direction changes): {kink_count} (Orange)")
            self.log_message(f"  End poles: {end_count} (Red)")
            self.log_message(f"Layer: '{pole_layer.name()}'")
            self._elapsed("Total time")
        except Exception as e:
            self.log_message(f"ERROR generating poles: {str(e)}")
            import traceback
            self.log_message(traceback.format_exc())

    def on_generate_feeder_routes_clicked(self):
        """Generate fiber feeder routes from OLT to aggregation points along routing layer."""
        from qgis.core import (
            QgsVectorLayer, QgsFeature, QgsGeometry, QgsPointXY,
            QgsProject, QgsWkbTypes, QgsField, QgsSpatialIndex,
            QgsLineString, QgsMultiLineString
        )
        from qgis.PyQt.QtCore import QVariant, QMetaType
        from qgis.PyQt.QtGui import QColor

        olt_layer = self.comboBox_olt_layer.currentLayer()
        agg_layer = self.comboBox_aggregation_layer.currentLayer()
        routing_layer = self.comboBox_routing_layer.currentLayer()

        if not olt_layer:
            self.log_message("ERROR: Please select an OLT layer.")
            return
        if not agg_layer:
            self.log_message("ERROR: Please select an Aggregation Points layer.")
            return

        self.log_message("\n=== Generating Feeder Routes ===")
        self._start_timer("Feeder Routes")
        from qgis.PyQt.QtWidgets import QApplication
        QApplication.processEvents()

        try:
            # Get OLT point (use first feature)
            olt_features = list(olt_layer.getFeatures())
            if not olt_features:
                self.log_message("ERROR: OLT layer has no features.")
                return
            olt_geom = olt_features[0].geometry()
            olt_point = olt_geom.asPoint() if olt_geom.type() == QgsWkbTypes.PointGeometry else olt_geom.centroid().asPoint()

            # Collect aggregation points
            agg_points = []
            for feat in agg_layer.getFeatures():
                geom = feat.geometry()
                if geom and not geom.isEmpty():
                    pt = geom.asPoint() if geom.type() == QgsWkbTypes.PointGeometry else geom.centroid().asPoint()
                    zone_name = feat['zone_name'] if 'zone_name' in [f.name() for f in agg_layer.fields()] else str(feat.id())
                    agg_points.append((pt, zone_name, feat.id()))

            if not agg_points:
                self.log_message("ERROR: No aggregation points found.")
                return

            self.log_message(f"OLT point: ({olt_point.x():.1f}, {olt_point.y():.1f})")
            self.log_message(f"Aggregation points: {len(agg_points)}")

            # Build routing graph from span layer if available
            route_segments = []
            if routing_layer and routing_layer.geometryType() == QgsWkbTypes.LineGeometry:
                self.log_message(f"Routing layer: '{routing_layer.name()}'")
                for feat in routing_layer.getFeatures():
                    geom = feat.geometry()
                    if geom and not geom.isEmpty():
                        route_segments.append(geom)

            # Create feeder routes layer
            crs_str = agg_layer.crs().authid()
            feeder_layer = QgsVectorLayer(f"LineString?crs={crs_str}", "Feeder Routes", "memory")
            provider = feeder_layer.dataProvider()
            provider.addAttributes([
                QgsField('route_id', QMetaType.Type.Int),
                QgsField('zone_name', QMetaType.Type.QString),
                QgsField('agg_point_id', QMetaType.Type.Int),
                QgsField('length_m', QMetaType.Type.Double),
            ])
            feeder_layer.updateFields()

            route_id = 1
            feeder_layer.startEditing()

            for pt, zone_name, agg_id in agg_points:
                self._progress(route_id - 1, len(agg_points), f"Routing to {zone_name}")
                QApplication.processEvents()

                if route_segments:
                    # Snap OLT and target to nearest point on routing network, then connect via straight line
                    # Simple approach: find nearest route segment endpoints and connect
                    best_line = self._route_along_network(olt_point, pt, route_segments)
                else:
                    # Straight-line feeder
                    best_line = QgsGeometry.fromPolylineXY([olt_point, pt])

                feat = QgsFeature(feeder_layer.fields())
                feat.setGeometry(best_line)
                feat['route_id'] = route_id
                feat['zone_name'] = zone_name
                feat['agg_point_id'] = agg_id
                feat['length_m'] = round(best_line.length(), 2)
                feeder_layer.addFeature(feat)
                route_id += 1

            feeder_layer.commitChanges()

            # Style: dark blue line, width 0.8
            from qgis.core import QgsSimpleLineSymbolLayer, QgsSingleSymbolRenderer, QgsSymbol
            symbol = QgsSymbol.defaultSymbol(QgsWkbTypes.LineGeometry)
            sym_layer = QgsSimpleLineSymbolLayer()
            sym_layer.setColor(QColor('#003399'))
            sym_layer.setWidth(0.8)
            symbol.changeSymbolLayer(0, sym_layer)
            feeder_layer.setRenderer(QgsSingleSymbolRenderer(symbol))

            QgsProject.instance().addMapLayer(feeder_layer)
            self.log_message(f"Generated {route_id - 1} feeder routes.")
            self._elapsed("Total time")

        except Exception as e:
            self.log_message(f"ERROR generating feeder routes: {str(e)}")
            import traceback
            self.log_message(traceback.format_exc())

    def _route_along_network(self, start_pt, end_pt, route_segments):
        """Find a path along route segments from start to end using nearest-segment snapping.
        Falls back to straight line if no path found."""
        from qgis.core import QgsGeometry, QgsPointXY, QgsSpatialIndex, QgsFeature, QgsWkbTypes
        import math

        def dist(p1, p2):
            return math.sqrt((p1.x() - p2.x()) ** 2 + (p1.y() - p2.y()) ** 2)

        def nearest_point_on_segment(px, py, ax, ay, bx, by):
            dx, dy = bx - ax, by - ay
            if dx == 0 and dy == 0:
                return QgsPointXY(ax, ay)
            t = max(0, min(1, ((px - ax) * dx + (py - ay) * dy) / (dx * dx + dy * dy)))
            return QgsPointXY(ax + t * dx, ay + t * dy)

        # Find closest point on network to start and end
        best_start, best_end = None, None
        best_sd, best_ed = float('inf'), float('inf')

        for seg_geom in route_segments:
            pts = seg_geom.asPolyline() if seg_geom.isMultipart() is False else []
            if not pts:
                try:
                    for part in seg_geom.asMultiPolyline():
                        pts.extend(part)
                except Exception:
                    continue
            for i in range(len(pts) - 1):
                snap_s = nearest_point_on_segment(start_pt.x(), start_pt.y(), pts[i].x(), pts[i].y(), pts[i+1].x(), pts[i+1].y())
                snap_e = nearest_point_on_segment(end_pt.x(), end_pt.y(), pts[i].x(), pts[i].y(), pts[i+1].x(), pts[i+1].y())
                ds = dist(start_pt, snap_s)
                de = dist(end_pt, snap_e)
                if ds < best_sd:
                    best_sd, best_start = ds, snap_s
                if de < best_ed:
                    best_ed, best_end = de, snap_e

        if best_start and best_end:
            return QgsGeometry.fromPolylineXY([start_pt, best_start, best_end, end_pt])
        return QgsGeometry.fromPolylineXY([start_pt, end_pt])

    def on_clear_output_clicked(self):
        """Clear the output text."""
        self.log_message("Output cleared.")

    def closeEvent(self, event):
        """Handle the close event."""
        self.closingPlugin.emit()
        event.accept()
