"""Example script demonstrating ERF parcel grouping."""

import sys
import os

# Add parent directory to path
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))


def example_spatial_sorting():
    """Example showing how parcels are sorted spatially."""
    print("=" * 60)
    print("ERF Parcel Grouping - Spatial Sorting Example")
    print("=" * 60)
    
    # Simulate parcel centroids (x, y coordinates)
    parcels = [
        ("Erf 1", 10, 50),   # Top left
        ("Erf 2", 20, 50),   # Top middle
        ("Erf 3", 30, 50),   # Top right
        ("Erf 4", 10, 40),   # Middle left
        ("Erf 5", 20, 40),   # Middle middle
        ("Erf 6", 30, 40),   # Middle right
        ("Erf 7", 10, 30),   # Bottom left
        ("Erf 8", 20, 30),   # Bottom middle
        ("Erf 9", 30, 30),   # Bottom right
    ]
    
    print("\nOriginal parcels (name, x, y):")
    for name, x, y in parcels:
        print(f"  {name}: ({x}, {y})")
    
    # Sort by Y (descending - top to bottom), then X (ascending - left to right)
    sorted_parcels = sorted(parcels, key=lambda p: (-p[2], p[1]))
    
    print("\nSorted order (top to bottom, left to right):")
    for idx, (name, x, y) in enumerate(sorted_parcels, 1):
        print(f"  {idx}. {name}: ({x}, {y})")
    
    # Group into batches of 3
    batch_size = 3
    print(f"\nGrouped into batches of {batch_size}:")
    for idx, (name, x, y) in enumerate(sorted_parcels):
        batch_number = (idx // batch_size) + 1
        print(f"  {name} -> Batch {batch_number}")


def example_batch_grouping():
    """Example showing batch grouping with 100 parcels."""
    print("\n" + "=" * 60)
    print("Batch Grouping with 100 Parcel Batches")
    print("=" * 60)
    
    # Simulate 250 parcels in a grid
    parcels = []
    grid_size = 16  # 16x16 = 256 parcels
    
    for row in range(grid_size):
        for col in range(grid_size):
            erf_num = row * grid_size + col + 1
            x = col * 10
            y = (grid_size - row) * 10  # Invert Y so top has higher values
            parcels.append((f"Erf {erf_num}", x, y))
    
    print(f"\nTotal parcels: {len(parcels)}")
    
    # Sort spatially
    sorted_parcels = sorted(parcels, key=lambda p: (-p[2], p[1]))
    
    # Group into batches of 100
    batch_size = 100
    batches = {}
    
    for idx, parcel in enumerate(sorted_parcels):
        batch_number = (idx // batch_size) + 1
        if batch_number not in batches:
            batches[batch_number] = []
        batches[batch_number].append(parcel)
    
    print(f"Batch size: {batch_size}")
    print(f"Total batches: {len(batches)}")
    
    print("\nBatch summary:")
    for batch_num in sorted(batches.keys()):
        batch_parcels = batches[batch_num]
        print(f"  Batch {batch_num}: {len(batch_parcels)} parcels")
        
        # Show first and last in batch
        if batch_parcels:
            first = batch_parcels[0]
            last = batch_parcels[-1]
            print(f"    First: {first[0]} at ({first[1]}, {first[2]})")
            print(f"    Last:  {last[0]} at ({last[1]}, {last[2]})")


def example_usage_workflow():
    """Example showing the typical workflow."""
    print("\n" + "=" * 60)
    print("Typical Usage Workflow")
    print("=" * 60)
    
    print("""
1. Load ERF parcel layer in QGIS
   - Layer should contain polygon features
   - Can be named 'erven', 'erf', 'parcels', etc.

2. Select the ERF layer in the plugin dock widget

3. Set batch size (default: 100)

4. Click 'Group ERF Parcels'
   - Plugin will:
     a) Calculate centroid for each parcel
     b) Sort by Y coordinate (top to bottom)
     c) Then sort by X coordinate (left to right)
     d) Assign batch numbers in groups of 100
     e) Add 'batch_id' field to the layer
     f) Apply color-coded symbology

5. Click 'Show Batch Statistics' to see:
   - Total number of batches
   - Parcels per batch
   - Spatial extent of each batch

6. Use batch_id for:
   - Filtering specific batches
   - Exporting batches separately
   - Planning work schedules
   - Assigning teams to areas
    """)


if __name__ == '__main__':
    example_spatial_sorting()
    example_batch_grouping()
    example_usage_workflow()
    
    print("\n" + "=" * 60)
    print("Examples completed!")
    print("=" * 60)
