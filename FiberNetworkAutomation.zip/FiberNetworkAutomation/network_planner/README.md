# FTTH Plan Tool

A QGIS plugin for Fiber To The Home (FTTH) network planning and routing.

## Features

- **Network Routing**: Shortest path routing for fiber network planning
- **ERF Parcel Grouping**: Batch ERF/parcel polygons in groups of 100 (or custom size)
  - Spatial sorting from top to bottom, left to right
  - Automatic batch ID assignment
  - Color-coded visualization by batch
  - Batch statistics and analysis
- **Layer Operations**: Comprehensive QGIS layer interaction utilities
- **Interactive UI**: Dock widget interface with real-time feedback

## Installation

### Option 1: Direct Installation to QGIS

1. Copy this entire `FTTHPlanTool` folder to your QGIS plugins directory:
   - **Windows**: `C:\Users\<username>\AppData\Roaming\QGIS\QGIS3\profiles\default\python\plugins\`
   - **Linux**: `~/.local/share/QGIS/QGIS3/profiles/default/python/plugins/`
   - **Mac**: `~/Library/Application Support/QGIS/QGIS3/profiles/default/python/plugins/`

2. Install required dependencies in QGIS Python environment:
   - Open OSGeo4W Shell (Windows) or terminal (Linux/Mac)
   - Run: `python -m pip install networkx shapely`

3. Restart QGIS and enable the plugin from **Plugins > Manage and Install Plugins**

### Option 2: Development Setup

1. Keep the plugin in this directory for development
2. Create a symbolic link from QGIS plugins folder to this directory
3. Install dependencies as above

## Usage

1. **Load Layers**: Load your FTTH network layers (nodes and ducts) into QGIS
   - Nodes should be Point features
   - Ducts should be LineString features

2. **Open Plugin**: 
   - Click the FTTH Plan Tool icon in the toolbar, or
   - Go to **Vector > FTTH Plan Tool**

3. **Select Layers**: In the dock widget:
   - Choose your nodes layer
   - Choose your ducts layer

4. **Calculate Routes**: Click "Calculate Route" to compute paths between nodes

## Requirements

- **QGIS**: 3.44 or higher
- **Python**: 3.9+
- **Dependencies**:
  - networkx >= 3.0
  - shapely >= 2.0

## Project Structure

```
FTTHPlanTool/
├── __init__.py              # Plugin loader
├── ftth_plan_tool.py        # Main plugin class
├── dock_widget.py           # UI dock widget
├── core.py                  # Network graph and routing logic
├── metadata.txt             # Plugin metadata
├── requirements.txt         # Python dependencies
├── resources.py             # Qt resources
├── resources.qrc            # Qt resource file
├── icon.png                 # Plugin icon (placeholder)
└── forms/
    └── dockwidget_base.ui   # Qt Designer UI file
```

## How to Use

### Quick Start with Sample Data

1. **Load Sample Data**: The plugin includes sample GeoJSON files in the `sample_data/` folder
   - Load `nodes.geojson` as a vector layer
   - Load `ducts.geojson` as a vector layer

2. **Build Network Graph**:
   - Select the layers in the dock widget
   - Click "Build Network Graph" to construct the routing network

3. **Analyze Layers**:
   - Click "Analyze Layers" to see statistics about your data

4. **Calculate Routes**:
   - Click "Calculate Route" to find the shortest path
   - A new layer "FTTH Route Result" will be added showing the route

### ERF Parcel Grouping

1. **Load ERF Layer**: Load your ERF/parcel polygon layer
   - Sample file available: `sample_data/erven_sample.geojson`

2. **Configure Grouping**:
   - Select the ERF layer in the dock widget
   - Set batch size (default: 100 parcels per batch)

3. **Group Parcels**:
   - Click "Group ERF Parcels"
   - Parcels will be sorted from top to bottom, left to right
   - A `batch_id` field is added to the layer
   - Color-coded symbology is applied automatically

4. **View Statistics**:
   - Click "Show Batch Statistics" to see batch details
   - View parcel counts and spatial extents per batch

**How It Works:**
- Calculates centroid for each parcel polygon
- Sorts by Y-coordinate (descending - top to bottom)
- Then sorts by X-coordinate (ascending - left to right)
- Assigns sequential batch numbers in groups of specified size
- Useful for planning work schedules, team assignments, or staged rollouts

### Working with Your Own Data

Your layers should have:
- **Nodes layer**: Point geometry (optional but recommended)
- **Ducts layer**: LineString geometry (required)

The plugin will automatically:
- Extract coordinates from geometries
- Build a network graph
- Calculate shortest paths using NetworkX

## Development

### Core Components

- **ftth_plan_tool.py**: Main QGIS plugin integration
- **dock_widget.py**: UI widget with layer interaction examples
- **core.py**: NetworkGraph class for routing algorithms
- **layer_utils.py**: Utility functions for QGIS layer operations
- **forms/dockwidget_base.ui**: Qt Designer UI definition
- **examples.py**: Standalone examples for testing core functionality
- **tests/test_plugin.py**: Unit tests

### Key Features Demonstrated

The plugin demonstrates:
- **Layer Selection**: Using QgsMapLayerComboBox for layer selection
- **Feature Iteration**: Reading features from vector layers
- **Geometry Extraction**: Getting coordinates from Point and LineString geometries
- **Attribute Access**: Reading feature attributes
- **Memory Layers**: Creating temporary result layers
- **Layer Management**: Adding/removing layers from the project
- **Network Analysis**: Building graphs and calculating shortest paths

### Running Examples

```bash
# Run network routing examples (no QGIS required)
python examples.py

# Run ERF grouping examples (demonstrates spatial sorting)
python examples_erf_grouping.py

# Run unit tests
python -m unittest tests.test_plugin
```

### Adding Features

The plugin uses NetworkX for graph operations and Shapely for geometry handling. Key extension points:

- Extend `NetworkGraph` in [core.py](core.py) for new routing algorithms
- Add functions to [layer_utils.py](layer_utils.py) for new layer operations
- Modify [dock_widget.py](dock_widget.py) to add UI functionality

## Notes

- Replace [icon.png](icon.png) with an actual icon (currently a placeholder)
- Update metadata.txt with your contact information
- The plugin is marked as experimental during development

## License

This plugin is provided as-is for FTTH network planning purposes.
