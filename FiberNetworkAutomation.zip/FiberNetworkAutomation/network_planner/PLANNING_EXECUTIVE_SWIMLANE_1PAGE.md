# FTTH Planning Workflow — Executive 1-Page Swimlane

**Purpose:** Department alignment from HLD to As-Built with clear gate ownership and handoffs.

---

## Swimlane (Stage × Department)

| Stage | Planning | GIS / Design | Wayleave | Finance | Build | QA / Commissioning | Ops / NOC | Gate Output |
|---|---|---|---|---|---|---|---|---|
| **Stage 0: Intake & Setup** | Define design basis and engineering assumptions | Validate base data quality and CRS | Flag access and legal constraints | Confirm budget envelope and cost assumptions | Provide early constructibility constraints | Define acceptance criteria baseline | Provide operational standards and labeling rules | **G0:** Design basis approved; baseline accepted |
| **Stage 1: HLD** | Define PON architecture, service areas, macro capacity | Produce HLD maps and corridor alternatives | Validate corridor feasibility risk | Validate cost range vs business case | Review high-level route practicality | Confirm measurable quality criteria for next stage | Review maintainability principles | **G1:** HLD approved and frozen; cost envelope accepted |
| **Stage 2: LLD** | Enforce splitter, capacity, and distance rules | Produce detailed route, node, and cable design | Confirm route-level permit readiness | Update BoQ cost confidence | Confirm constructibility and access sequence | Run design compliance checks | Validate asset metadata and support readiness | **G2:** LLD constructible; checks passed or waived |
| **Stage 3: Splice Plan** | Confirm end-to-end architecture consistency | Link logical and physical continuity records | Track permit impacts from closure placement | Track material and labor delta | Validate install sequence and closure access | Validate continuity and conflict-free assignments | Confirm labeling and fault-traceability standards | **G3:** Splice pack approved; continuity validated |
| **Stage 4: Build & Redlines** | Approve or decline design deviations | Issue controlled revisions from field redlines | Resolve emergent access and legal conflicts | Track change-order and budget impact | Submit redlines and completion evidence | Verify implemented changes meet acceptance | Prepare support model from latest revision | **G4:** Redlines resolved or deferred; revision acknowledged |
| **Stage 5: As-Built & Handover** | Sign off final design intent vs delivered outcome | Publish final authoritative As-Built records | Close permit obligations and records | Close cost reconciliation and variance reporting | Submit final completion dossier | Sign off acceptance and test compliance | Accept handover and activate lifecycle support | **G5:** As-Built accepted; handover signed; project closed |

---

## Executive Controls
1. No stage starts without prior gate sign-off.
2. One source of truth for drawings, schedules, and asset records.
3. Every revision has a stated reason, named approver, and effective date.
4. Escalate unresolved gate blockers within 48 hours.

## Executive KPI Dashboard
| KPI | Target |
|---|---|
| HLD approval cycle time | To be set by organisation |
| LLD right-first-time rate | > 90% |
| Splice defect rate during build | < 5% |
| Redline closure turnaround | ≤ 5 business days |
| Planned vs As-Built variance | < 10% on length |
| Handover acceptance lead time | To be set by organisation |

## Governance Cadence
- **Weekly:** Cross-functional design and build control review
- **Gate events:** Formal sign-off meeting with named approvers
- **Monthly:** KPI and lessons-learned review

---
*Document Owner: Planning Department | Status: Active*
